from __future__ import annotations
from itertools import product
from pathlib import Path
import nibabel as nib
import numpy as np
from scipy.ndimage import affine_transform
TARGET_SPACING_XYZ_MM = (1.0, 1.0, 2.0)

def box_corners(box_xyzxyz: np.ndarray) -> np.ndarray:
    box = np.asarray(box_xyzxyz, dtype=np.float64)
    low = box[:3] - 0.5
    high = box[3:] - 0.5
    return np.array([(*point, 1.0) for point in product(*zip(low, high))], dtype=np.float64)

def transform_box(box_xyzxyz: np.ndarray, from_affine: np.ndarray, to_affine: np.ndarray) -> np.ndarray:
    points = (np.linalg.inv(to_affine) @ from_affine @ box_corners(box_xyzxyz).T).T[:, :3]
    return np.r_[points.min(axis=0) + 0.5, points.max(axis=0) + 0.5].astype(np.float32)

def normalize_valid_intensity(volume: np.ndarray) -> np.ndarray:
    valid = np.isfinite(volume) & (volume != 0)
    if not valid.any():
        raise ValueError('Image has no nonzero finite voxels')
    low, high = np.percentile(volume[valid], [0.5, 99.5])
    if high <= low:
        raise ValueError('Image has no usable intensity range')
    result = np.zeros_like(volume, dtype=np.float32)
    result[valid] = np.clip((volume[valid] - low) / (high - low), 0.0, 1.0)
    return result

def load_preprocessed_t2(path: str | Path, box_xyzxyz: np.ndarray | None=None, target_spacing_xyz_mm: tuple[float, float, float]=TARGET_SPACING_XYZ_MM) -> tuple[np.ndarray, np.ndarray | None, dict]:
    image = nib.load(str(path))
    if len(image.shape) != 3:
        raise ValueError(f'Expected 3D NIfTI, got {image.shape}')
    original_affine = np.asarray(image.affine, dtype=np.float64)
    canonical = nib.as_closest_canonical(image)
    canonical_affine = np.asarray(canonical.affine, dtype=np.float64)
    old_spacing = np.linalg.norm(canonical_affine[:3, :3], axis=0)
    if not np.isfinite(original_affine).all() or not np.isfinite(canonical_affine).all() or min(old_spacing) <= 0:
        raise ValueError('Invalid image affine')
    scale = np.asarray(target_spacing_xyz_mm) / old_spacing
    new_affine = canonical_affine @ np.diag([*scale, 1.0])
    new_shape = tuple((int(np.ceil(n / s)) for n, s in zip(canonical.shape, scale)))
    output_to_input = np.linalg.inv(canonical_affine) @ new_affine
    original = canonical.get_fdata(dtype=np.float32)
    resampled = affine_transform(original, matrix=output_to_input[:3, :3], offset=output_to_input[:3, 3], output_shape=new_shape, order=1, mode='constant', cval=0.0, prefilter=False)
    normalized = normalize_valid_intensity(resampled)[None]
    mapped_box = None
    if box_xyzxyz is not None:
        mapped_box = transform_box(np.asarray(box_xyzxyz), original_affine, new_affine)
        if any((mapped_box[i] < -0.001 or mapped_box[i + 3] > new_shape[i] + 0.001 or mapped_box[i] >= mapped_box[i + 3] for i in range(3))):
            raise ValueError(f'Resampled box outside image: {mapped_box}, shape={new_shape}')
        mapped_box[:3] = np.maximum(mapped_box[:3], 0)
        mapped_box[3:] = np.minimum(mapped_box[3:], new_shape)
    geometry = {'original_shape_xyz': tuple(map(int, image.shape)), 'original_affine': original_affine, 'work_shape_xyz': new_shape, 'work_affine': new_affine}
    return (normalized, mapped_box, geometry)

def box_to_original(box_work_xyzxyz: np.ndarray, geometry: dict) -> np.ndarray:
    box = transform_box(box_work_xyzxyz, geometry['work_affine'], geometry['original_affine'])
    shape = geometry['original_shape_xyz']
    return np.r_[np.maximum(box[:3], 0), np.minimum(box[3:], shape)].astype(np.float32)
