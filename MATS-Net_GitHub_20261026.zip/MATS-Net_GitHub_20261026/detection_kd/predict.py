from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import torch
import nibabel as nib
from qc_t2 import render_slice
from model import INFERENCE_ROI, PROTOCOL, configure_inference, make_detector
from preprocess import box_to_original, load_preprocessed_t2

def load_detector(checkpoint_path: str | Path, device: torch.device, allow_legacy: bool=False):
    checkpoint = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
    if checkpoint.get('protocol') != PROTOCOL and (not allow_legacy):
        raise ValueError('Checkpoint uses the superseded detection protocol; legacy weights require explicit diagnostic use')
    detector = make_detector(checkpoint['anchor_shapes_xyz']).to(device)
    detector.network.load_state_dict(checkpoint['network'])
    configure_inference(detector, device)
    detector.eval()
    return (detector, checkpoint)

@torch.no_grad()
def predict_work(detector, volume: np.ndarray, device: torch.device) -> tuple[np.ndarray, np.ndarray]:
    original_shape = np.asarray(volume.shape[1:])
    if detector.inferer is None or tuple(detector.inferer.roi_size) != INFERENCE_ROI:
        configure_inference(detector, device)
    padding = [(0, 0), *[(0, max(roi - int(n), 0)) for roi, n in zip(INFERENCE_ROI, original_shape)]]
    if any((high for _, high in padding)):
        volume = np.pad(volume, padding, mode='constant')
    image = torch.from_numpy(np.ascontiguousarray(volume)).to(device)
    result = detector([image], use_inferer=True)[0]
    boxes = result[detector.target_box_key].detach().cpu().numpy()
    scores = result[detector.pred_score_key].detach().cpu().numpy()
    boxes[:, :3] = np.maximum(boxes[:, :3], 0)
    boxes[:, 3:] = np.minimum(boxes[:, 3:], original_shape)
    valid = (boxes[:, 3:] > boxes[:, :3]).all(axis=1)
    return (boxes[valid], scores[valid])

def predict_file(detector, image_path: str | Path, device: torch.device, threshold: float) -> dict:
    volume, _, geometry = load_preprocessed_t2(image_path)
    boxes, scores = predict_work(detector, volume, device)
    selected = scores >= threshold
    detections = [{'box_xyzxyz_half_open': box_to_original(box, geometry).tolist(), 'confidence': float(score)} for box, score in zip(boxes[selected], scores[selected])]
    return {'image_path': str(image_path), 'original_shape_xyz': list(geometry['original_shape_xyz']), 'original_affine_xyz_to_ras_mm': geometry['original_affine'].tolist(), 'confidence_threshold': threshold, 'raw_candidate_count': int(len(scores)), 'detections': detections, 'review_flag': 'no_reliable_detection' if not detections else 'multiple_candidates' if len(detections) > 1 else None}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--image', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--overlay', type=Path, help='Optional original-slice PNG with the top box')
    parser.add_argument('--threshold', type=float)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    if args.overlay and args.overlay.exists():
        raise FileExistsError(args.overlay)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    detector, checkpoint = load_detector(args.checkpoint, device)
    threshold = args.threshold if args.threshold is not None else checkpoint.get('threshold')
    if threshold is None:
        raise ValueError('No frozen internal-validation threshold in checkpoint; specify --threshold')
    result = predict_file(detector, args.image, device, float(threshold))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    if args.overlay:
        original = nib.load(str(args.image)).get_fdata(dtype=np.float32)
        if result['detections']:
            best = result['detections'][0]
            box = best['box_xyzxyz_half_open']
            z = int(np.clip((box[2] + box[5]) / 2, 0, original.shape[2] - 1))
            caption = f"confidence={best['confidence']:.3f}, z={z}"
        else:
            box = [0, 0, 0, 0, 0, 0]
            z = original.shape[2] // 2
            caption = f'no reliable detection, z={z}'
        args.overlay.parent.mkdir(parents=True, exist_ok=True)
        render_slice(original, z, box, caption).save(args.overlay)
    print(json.dumps({'detections': len(result['detections']), 'review_flag': result['review_flag']}))
if __name__ == '__main__':
    main()
