from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import nibabel as nib
import numpy as np
import torch
from derive_anchors import kmeans_log_shapes
from metrics import ap50, select_f2_threshold
from model import PROTOCOL, configure_inference, make_detector
from predict import predict_work
from preprocess import TARGET_SPACING_XYZ_MM, transform_box
from training_data import AUGMENTATION_CONFIG, augment_intensity, load_record, read_manifest, sample_patch

def cosine_warmup(epoch_index: int, total_epochs: int, warmup_epochs: int=5) -> float:
    if epoch_index < warmup_epochs:
        return (epoch_index + 1) / warmup_epochs
    progress = (epoch_index - warmup_epochs) / max(total_epochs - warmup_epochs, 1)
    return 0.5 * (1 + math.cos(math.pi * progress))

def anchor_shapes(rows) -> list[list[float]]:
    shapes = []
    for _, row in rows.iterrows():
        box = np.asarray(json.loads(row.box_xyzxyz_half_open), dtype=float)
        image = nib.load(row.image_path)
        orientation = nib.orientations.ornt_transform(nib.orientations.io_orientation(image.affine), nib.orientations.axcodes2ornt(('R', 'A', 'S')))
        canonical_affine = image.affine @ nib.orientations.inv_ornt_aff(orientation, image.shape)
        spacing = np.linalg.norm(canonical_affine[:3, :3], axis=0)
        target_spacing = np.asarray(TARGET_SPACING_XYZ_MM if row.modality == 'T2W' else (1.0, 1.0, spacing[2]))
        work_affine = canonical_affine @ np.diag([*target_spacing / spacing, 1.0])
        mapped_box = transform_box(box, image.affine, work_affine)
        shapes.append(mapped_box[3:] - mapped_box[:3])
    return kmeans_log_shapes(np.asarray(shapes)).tolist()

def cached_record(row, cache: dict):
    patient_id = row.patient_id
    if patient_id not in cache:
        cache[patient_id] = load_record(row)
    return cache[patient_id]

def validate(detector, rows, device, cache: dict | None=None):
    cache = {} if cache is None else cache
    predictions, references = ({}, {})
    for _, row in rows.iterrows():
        volume, box, _ = cached_record(row, cache)
        predictions[row.patient_id] = predict_work(detector, volume, device)
        references[row.patient_id] = box
    return (ap50(predictions, references), select_f2_threshold(predictions, references))

def train(args) -> None:
    if args.output.exists() and (not args.resume):
        raise FileExistsError(f'Experiment directory already exists: {args.output}')
    if args.resume and args.resume.parent.resolve() != args.output.resolve():
        raise ValueError('Resume checkpoint must belong to the specified output directory')
    table = read_manifest(args.manifest)
    train_rows = table[(table.split == 'train') & (table.modality == args.modality)]
    val_rows = table[(table.split == 'val') & (table.modality == args.modality)]
    if len(train_rows) < 6 or val_rows.empty:
        raise ValueError('Insufficient accepted train/validation patients')
    config = vars(args).copy()
    config.update({'protocol': PROTOCOL, 'manifest_sha256': hashlib.sha256(args.manifest.read_bytes()).hexdigest(), 'augmentation': AUGMENTATION_CONFIG, 'train_patients': len(train_rows), 'val_patients': len(val_rows)})
    resume_state = None
    if args.resume:
        saved_config = json.loads((args.output / 'config.json').read_text(encoding='utf-8'))
        for key in ('protocol', 'manifest_sha256', 'modality', 'epochs', 'patience', 'lr', 'accumulate', 'seed'):
            if saved_config[key] != config[key]:
                raise ValueError(f'Resume configuration mismatch: {key}')
        resume_state = torch.load(args.resume, map_location='cpu', weights_only=False)
    else:
        args.output.mkdir(parents=True)
        (args.output / 'config.json').write_text(json.dumps(config, indent=2, default=str), encoding='utf-8')
    torch.manual_seed(args.seed)
    rng = np.random.default_rng(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    anchors = resume_state['anchor_shapes_xyz'] if resume_state else anchor_shapes(train_rows)
    original = None
    if args.initialize:
        original = torch.load(args.initialize, map_location='cpu', weights_only=False)
        if original.get('protocol') != PROTOCOL:
            raise ValueError('Initialization checkpoint uses a different detection protocol')
        if original['modality'] != args.modality:
            raise ValueError('Initialization modality mismatch')
        if original['manifest_sha256'] != config['manifest_sha256']:
            raise ValueError('Initialization checkpoint used a different patient manifest')
        anchors = original['anchor_shapes_xyz']
    detector = make_detector(anchors).to(device)
    if original is not None:
        detector.network.load_state_dict(original['network'])
    configure_inference(detector, device)
    optimizer = torch.optim.AdamW(detector.network.parameters(), lr=args.lr, weight_decay=0.0001)
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda i: cosine_warmup(i, args.epochs))
    best_ap, best_epoch, best_threshold = (-1.0, 0, None)
    history = []
    start_epoch = 1
    if resume_state:
        detector.network.load_state_dict(resume_state['network'])
        optimizer.load_state_dict(resume_state['optimizer'])
        scheduler.load_state_dict(resume_state['scheduler'])
        rng.bit_generator.state = resume_state['numpy_rng_state']
        torch.set_rng_state(resume_state['torch_rng_state'])
        if device.type == 'cuda':
            torch.cuda.set_rng_state_all(resume_state['cuda_rng_states'])
        best_ap, best_epoch, best_threshold = (resume_state['best_ap'], resume_state['best_epoch'], resume_state['best_threshold'])
        history = resume_state['history']
        start_epoch = resume_state['epoch'] + 1
    image_cache = {}
    for epoch in range(start_epoch, args.epochs + 1):
        detector.train()
        if device.type == 'cuda':
            torch.cuda.reset_peak_memory_stats()
        order = rng.permutation(len(train_rows))
        losses_epoch = []
        component_losses = []
        optimizer.zero_grad(set_to_none=True)
        for step, index in enumerate(order, 1):
            row = train_rows.iloc[index]
            volume, box, _ = cached_record(row, image_cache)
            patch, local_box, _ = sample_patch(volume, box, rng, positive=step % 2 == 1)
            patch = augment_intensity(patch, rng, strong=args.modality == 'T2W')
            image = torch.from_numpy(patch).to(device)
            boxes = np.empty((0, 6), dtype=np.float32) if local_box is None else local_box[None]
            target = {'boxes': torch.as_tensor(boxes, device=device), 'labels': torch.zeros(len(boxes), dtype=torch.int64, device=device)}
            losses = detector([image], [target])
            loss = sum(losses.values())
            if not torch.isfinite(loss):
                raise RuntimeError(f'Nonfinite loss at epoch {epoch}, patient {row.patient_id}: {losses}')
            (loss / args.accumulate).backward()
            if step % args.accumulate == 0 or step == len(order):
                torch.nn.utils.clip_grad_norm_(detector.network.parameters(), 5.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
            losses_epoch.append(float(loss.detach().cpu()))
            component_losses.append((float(losses[detector.cls_key].detach().cpu()), float(losses[detector.box_reg_key].detach().cpu())))
        detector.eval()
        val_ap, (threshold, f2) = validate(detector, val_rows, device, image_cache)
        record = {'epoch': epoch, 'training_loss': float(np.mean(losses_epoch)), 'classification_loss': float(np.mean(component_losses, axis=0)[0]), 'box_regression_loss': float(np.mean(component_losses, axis=0)[1]), 'val_ap50': val_ap, 'val_f2': f2, 'val_threshold': threshold, 'learning_rate': optimizer.param_groups[0]['lr'], 'gpu_peak_gib': torch.cuda.max_memory_allocated() / 2 ** 30 if device.type == 'cuda' else None}
        history.append(record)
        (args.output / 'history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
        print(json.dumps(record), flush=True)
        if val_ap > best_ap:
            best_ap, best_epoch, best_threshold = (val_ap, epoch, threshold)
            torch.save({'network': detector.network.state_dict(), 'anchor_shapes_xyz': anchors, 'modality': args.modality, 'epoch': epoch, 'val_ap50': val_ap, 'threshold': threshold, 'protocol': PROTOCOL, 'manifest_sha256': config['manifest_sha256']}, args.output / 'best.pt')
        scheduler.step()
        state = {'epoch': epoch, 'protocol': PROTOCOL, 'network': detector.network.state_dict(), 'anchor_shapes_xyz': anchors, 'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(), 'numpy_rng_state': rng.bit_generator.state, 'torch_rng_state': torch.get_rng_state(), 'cuda_rng_states': torch.cuda.get_rng_state_all() if device.type == 'cuda' else [], 'best_ap': best_ap, 'best_epoch': best_epoch, 'best_threshold': best_threshold, 'history': history}
        temporary = args.output / 'last.pt.tmp'
        torch.save(state, temporary)
        os.replace(temporary, args.output / 'last.pt')
        if epoch - best_epoch >= args.patience:
            break
    print(json.dumps({'best_epoch': best_epoch, 'best_val_ap50': best_ap, 'threshold': best_threshold}))

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, default=Path('detection_kd/mapped_208/manifest.csv'))
    parser.add_argument('--modality', choices=['T1W', 'T2W', 'T1C', 'DWI'], required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--epochs', type=int, default=200)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--lr', type=float, default=0.0002)
    parser.add_argument('--accumulate', type=int, default=2)
    parser.add_argument('--seed', type=int, default=20260925)
    parser.add_argument('--initialize', type=Path)
    parser.add_argument('--resume', type=Path, help="Resume from this run's last.pt with optimizer and RNG state")
    train(parser.parse_args())
if __name__ == '__main__':
    main()
