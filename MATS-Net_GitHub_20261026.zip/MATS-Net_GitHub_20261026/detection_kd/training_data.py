from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
import nibabel as nib
from scipy.ndimage import affine_transform, gaussian_filter
from preprocess import load_preprocessed_t2
PATCH_SIZE = (160, 160, 64)
AUGMENTATION_CONFIG = {'strong_gain': [0.8, 1.2], 'strong_bias': [-0.08, 0.08], 'strong_noise_std': 0.02, 'bias_field_probability': 0.3, 'bias_field_log_coefficient': 0.08, 'blur_probability': 0.2, 'blur_sigma_voxels': [0.4, 0.8], 'resolution_probability': 0.2, 'resolution_factor': [1.2, 1.6], 'interpolation_order': 1, 'weak_gain': [0.95, 1.05], 'weak_bias': [-0.02, 0.02], 'weak_noise_std': 0.005}

def read_manifest(path: str | Path, require_four: bool=True) -> pd.DataFrame:
    table = pd.read_csv(path, dtype={'patient_id': str})
    table['accepted'] = table['accepted'].astype(str).str.lower().eq('true')
    if require_four:
        valid = table.groupby('patient_id').filter(lambda rows: len(rows) == 4 and rows['accepted'].all())
        return valid.reset_index(drop=True)
    return table[table.accepted].reset_index(drop=True)

def load_record(row: pd.Series) -> tuple[np.ndarray, np.ndarray, dict]:
    box = np.asarray(json.loads(row.box_xyzxyz_half_open), dtype=np.float32)
    return load_preprocessed_record(row.image_path, box, row.modality)

def load_preprocessed_record(path: str | Path, box: np.ndarray, modality: str):
    z_spacing = 2.0 if modality == 'T2W' else float(nib.load(str(path)).header.get_zooms()[2])
    return load_preprocessed_t2(path, box, target_spacing_xyz_mm=(1.0, 1.0, z_spacing))

def sample_patch(volume: np.ndarray, box: np.ndarray, rng: np.random.Generator, positive: bool, patch_size: tuple[int, int, int]=PATCH_SIZE) -> tuple[np.ndarray, np.ndarray | None, np.ndarray]:
    shape = np.asarray(volume.shape[1:], dtype=int)
    lo, hi = (box[:3], box[3:])
    center = (lo + hi) / 2
    context_lo = np.maximum(center - (hi - lo) * 0.625, 0)
    context_hi = np.minimum(center + (hi - lo) * 0.625, shape)
    size = np.maximum(np.asarray(patch_size, dtype=int), np.ceil(context_hi - context_lo).astype(int) + 2)
    size = np.minimum(np.ceil(size / np.array([32, 32, 16])).astype(int) * [32, 32, 16], np.maximum(shape, size))
    max_start = np.maximum(shape - size, 0)
    start = None
    if not positive:
        for negative_size in (size, np.minimum(size, [96, 96, 32]), np.minimum(size, [64, 64, 32])):
            limits = np.maximum(shape - negative_size, 0)
            for _ in range(100):
                candidate = np.array([rng.integers(0, limit + 1) for limit in limits], dtype=int)
                end = candidate + negative_size
                if np.any(end <= lo) or np.any(candidate >= hi):
                    start, size = (candidate, negative_size)
                    break
            if start is not None:
                break
    if start is None:
        low_start = np.maximum(np.ceil(context_hi - size).astype(int), 0)
        high_start = np.minimum(np.floor(context_lo).astype(int), max_start)
        if np.any(low_start > high_start):
            low_start = np.maximum(np.ceil(hi - size).astype(int), 0)
            high_start = np.minimum(np.floor(lo).astype(int), max_start)
        if np.any(low_start > high_start):
            raise ValueError(f'Cannot contain box {box} with image {shape} and patch {size}')
        start = np.array([rng.integers(a, b + 1) for a, b in zip(low_start, high_start)], dtype=int)
        positive = True
    end = np.minimum(start + size, shape)
    patch = volume[:, start[0]:end[0], start[1]:end[1], start[2]:end[2]]
    target = (box - np.r_[start, start]).astype(np.float32) if positive else None
    return (np.ascontiguousarray(patch), target, start)

def bias_field(shape, rng):
    coefficients = rng.uniform(-AUGMENTATION_CONFIG['bias_field_log_coefficient'], AUGMENTATION_CONFIG['bias_field_log_coefficient'], 6)
    log_field = np.zeros(shape, dtype=np.float32)
    for axis, count in enumerate(shape):
        view = [1, 1, 1]
        view[axis] = count
        coordinates = np.linspace(-1, 1, count, dtype=np.float32).reshape(view)
        log_field += coefficients[axis] * coordinates + coefficients[axis + 3] * coordinates ** 2
    return np.clip(np.exp(log_field), 0.8, 1.2).astype(np.float32)

def degrade_resolution(patch, factor):
    shape = np.asarray(patch.shape[1:])
    coarse_shape = np.maximum(np.ceil(shape / factor).astype(int), 2)
    downscale = np.maximum(shape - 1, 0) / np.maximum(coarse_shape - 1, 1)
    upscale = np.maximum(coarse_shape - 1, 0) / np.maximum(shape - 1, 1)
    filtered = gaussian_filter(patch, sigma=(0, *[0.5 * np.sqrt(factor ** 2 - 1)] * 3), mode='nearest')
    result = np.empty_like(patch)
    for channel in range(len(patch)):
        coarse = affine_transform(filtered[channel], np.diag(downscale), output_shape=tuple(coarse_shape), order=1, mode='nearest', prefilter=False)
        result[channel] = affine_transform(coarse, np.diag(upscale), output_shape=tuple(shape), order=1, mode='nearest', prefilter=False)
    return result

def augment_intensity(patch: np.ndarray, rng: np.random.Generator, strong: bool) -> np.ndarray:
    prefix = 'strong' if strong else 'weak'
    gain = rng.uniform(*AUGMENTATION_CONFIG[f'{prefix}_gain'])
    bias = rng.uniform(*AUGMENTATION_CONFIG[f'{prefix}_bias'])
    noise = rng.normal(0, AUGMENTATION_CONFIG[f'{prefix}_noise_std'], size=patch.shape)
    source = patch
    if strong and rng.random() < AUGMENTATION_CONFIG['bias_field_probability']:
        source = source * bias_field(patch.shape[1:], rng)[None]
    transformed = np.clip(source * gain + bias + noise, 0, 1).astype(np.float32)
    if strong and rng.random() < AUGMENTATION_CONFIG['blur_probability']:
        sigma = rng.uniform(*AUGMENTATION_CONFIG['blur_sigma_voxels'])
        transformed = gaussian_filter(transformed, sigma=(0, sigma, sigma, sigma), mode='nearest')
    if strong and rng.random() < AUGMENTATION_CONFIG['resolution_probability']:
        transformed = degrade_resolution(transformed, rng.uniform(*AUGMENTATION_CONFIG['resolution_factor']))
    transformed = np.clip(transformed, 0, 1).astype(np.float32)
    transformed[patch == 0] = 0
    return transformed
