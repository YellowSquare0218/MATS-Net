from __future__ import annotations
from collections.abc import Mapping
import torch
import torch.nn.functional as F
from torch import nn
MODALITIES = ('T1W', 'T2W', 'T1C', 'DWI')

def padded_shape(shape: tuple[int, int, int], size_divisible: tuple[int, int, int]=(32, 32, 16)) -> tuple[int, int, int]:
    return tuple(((n + divisor - 1) // divisor * divisor for n, divisor in zip(shape, size_divisible)))

class FeatureCapture:

    def __init__(self, feature_extractor: nn.Module) -> None:
        self.features = None
        self.handle = feature_extractor.register_forward_hook(self._save)

    def _save(self, _module, _args, output) -> None:
        self.features = list(output.values()) if isinstance(output, Mapping) else list(output)

    def close(self) -> None:
        self.handle.remove()

def roi_vector(features: list[torch.Tensor], box: torch.Tensor, input_shape: tuple[int, int, int], context_scale: float=1.0, grid_size: tuple[int, int, int]=(4, 4, 4)) -> torch.Tensor:
    if len(features) < 3:
        raise ValueError('At least three FPN levels are required')
    center = (box[:3] + box[3:]) / 2
    half = (box[3:] - box[:3]) * (context_scale / 2)
    low = torch.maximum(center - half, torch.zeros_like(center))
    high = torch.minimum(center + half, torch.as_tensor(input_shape, device=box.device, dtype=box.dtype))
    fractions = [torch.linspace(0.1, 0.9, steps, device=box.device) for steps in grid_size]
    positions = torch.meshgrid(*fractions, indexing='ij')
    locations = torch.stack([low[i] + (high[i] - low[i]) * positions[i] for i in range(3)], dim=-1)
    pooled = []
    for fmap in features[:3]:
        size = fmap.shape[-3:]
        coords = locations * torch.as_tensor(size, device=box.device) / torch.as_tensor(input_shape, device=box.device)
        normalized = 2 * (coords - 0.5) / torch.as_tensor(size, device=box.device).clamp_min(2).sub(1) - 1
        grid = normalized[..., [2, 1, 0]].unsqueeze(0)
        sampled = F.grid_sample(fmap[:1], grid, mode='bilinear', padding_mode='border', align_corners=True)
        pooled.append(sampled.mean(dim=(2, 3, 4)).squeeze(0))
    return torch.cat(pooled)

def lesion_features(features: list[torch.Tensor], box: torch.Tensor, input_shape: tuple[int, int, int]) -> torch.Tensor:
    return torch.stack([roi_vector(features, box, input_shape, scale) for scale in (1.0, 1.25)])

def global_features(features: list[torch.Tensor]) -> torch.Tensor:
    return torch.cat([feature[:1].mean(dim=(2, 3, 4)).squeeze(0) for feature in features[:3]])

class DistillationHeads(nn.Module):

    def __init__(self, feature_dim: int=384) -> None:
        super().__init__()
        self.projections = nn.ModuleDict({name: nn.Linear(feature_dim, feature_dim) for name in MODALITIES})

    def forward(self, student: torch.Tensor, targets: dict[str, torch.Tensor], reliability: dict[str, float]) -> torch.Tensor:
        terms = []
        for name in MODALITIES:
            if name in targets:
                teacher = targets[name].detach().to(student.device)
                projected = self.projections[name](student)
                distance = 1 - F.cosine_similarity(projected.float(), teacher.float(), dim=-1)
                terms.append(distance.sum() * float(reliability.get(name, 0.0)))
        if not terms:
            return student.sum() * 0
        return torch.stack(terms).sum() / (len(terms) * 2)

def box_iou3d(a: torch.Tensor, b: torch.Tensor) -> torch.Tensor:
    intersection = (torch.minimum(a[3:], b[3:]) - torch.maximum(a[:3], b[:3])).clamp_min(0).prod()
    volume_a = (a[3:] - a[:3]).clamp_min(0).prod()
    volume_b = (b[3:] - b[:3]).clamp_min(0).prod()
    return intersection / (volume_a + volume_b - intersection).clamp_min(1e-08)
