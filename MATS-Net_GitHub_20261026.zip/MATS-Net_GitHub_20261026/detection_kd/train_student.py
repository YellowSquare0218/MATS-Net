from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import numpy as np
import torch
from model import PROTOCOL, configure_inference, make_detector
from region_kd import DistillationHeads, FeatureCapture, global_features, lesion_features, padded_shape
from train_detector import cached_record, cosine_warmup, validate
from training_data import AUGMENTATION_CONFIG, augment_intensity, read_manifest, sample_patch

def train(args) -> None:
    if args.output.exists() and (not args.resume):
        raise FileExistsError(args.output)
    if args.resume and args.resume.parent.resolve() != args.output.resolve():
        raise ValueError('Resume checkpoint must belong to the specified output directory')
    table = read_manifest(args.manifest)
    train_rows = table[(table.split == 'train') & (table.modality == 'T2W')]
    if args.limit:
        train_rows = train_rows.iloc[:args.limit]
    val_rows = table[(table.split == 'val') & (table.modality == 'T2W')]
    source = torch.load(args.t2_teacher, map_location='cpu', weights_only=False)
    if source.get('protocol') != PROTOCOL:
        raise ValueError('T2 teacher uses a different detection protocol')
    if source['modality'] != 'T2W':
        raise ValueError('Student must initialize from T2 teacher')
    if source['manifest_sha256'] != hashlib.sha256(args.manifest.read_bytes()).hexdigest():
        raise ValueError('T2 teacher was trained with a different manifest')
    selected = ['T2W'] if args.method == 'B' else [m for m in ('T1W', 'T2W', 'T1C', 'DWI') if m != args.drop_modality]
    cache_files = {}
    cache_metadata = {}
    for modality in selected:
        metadata_path = args.cache_root / modality / 'metadata.json'
        metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
        if metadata['manifest_sha256'] != source['manifest_sha256'] or metadata['modality'] != modality or metadata.get('protocol') != PROTOCOL:
            raise ValueError(f'Teacher cache provenance mismatch: {metadata_path}')
        cache_metadata[modality] = metadata
        if modality == 'T2W' and metadata['checkpoint_sha256'] != hashlib.sha256(args.t2_teacher.read_bytes()).hexdigest():
            raise ValueError('T2 cache does not match student initialization checkpoint')
    for row in train_rows.itertuples():
        cache_files[row.patient_id] = {}
        for modality in selected:
            path = args.cache_root / modality / f'{row.patient_id}.npz'
            if not path.is_file():
                raise FileNotFoundError(path)
            cache_files[row.patient_id][modality] = path
    config = vars(args).copy()
    config['manifest_sha256'] = source['manifest_sha256']
    config['protocol'] = PROTOCOL
    config['augmentation'] = AUGMENTATION_CONFIG
    config['cache_metadata'] = cache_metadata
    config['t2_teacher_sha256'] = hashlib.sha256(args.t2_teacher.read_bytes()).hexdigest()
    resume_state = None
    if args.resume:
        saved_config = json.loads((args.output / 'config.json').read_text(encoding='utf-8'))
        for key in ('protocol', 'cache_metadata', 't2_teacher_sha256', 'manifest_sha256', 'method', 'drop_modality', 'epochs', 'patience', 'lr', 'lambda_kd', 'accumulate', 'seed', 'limit'):
            if saved_config[key] != config[key]:
                raise ValueError(f'Resume configuration mismatch: {key}')
        resume_state = torch.load(args.resume, map_location='cpu', weights_only=False)
    else:
        args.output.mkdir(parents=True)
        (args.output / 'config.json').write_text(json.dumps(config, indent=2, default=str), encoding='utf-8')
    torch.manual_seed(args.seed)
    rng = np.random.default_rng(args.seed)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    detector = make_detector(source['anchor_shapes_xyz']).to(device)
    detector.network.load_state_dict(source['network'])
    configure_inference(detector, device)
    capture = FeatureCapture(detector.network.feature_extractor)
    heads = DistillationHeads().to(device)
    optimizer = torch.optim.AdamW([*detector.network.parameters(), *heads.parameters()], lr=args.lr, weight_decay=0.0001)
    scheduler = torch.optim.lr_scheduler.LambdaLR(optimizer, lambda i: cosine_warmup(i, args.epochs))
    best_ap, best_epoch, best_threshold = (-1.0, 0, None)
    history = []
    start_epoch = 1
    if resume_state:
        detector.network.load_state_dict(resume_state['network'])
        heads.load_state_dict(resume_state['heads'])
        optimizer.load_state_dict(resume_state['optimizer'])
        scheduler.load_state_dict(resume_state['scheduler'])
        rng.bit_generator.state = resume_state['numpy_rng_state']
        torch.set_rng_state(resume_state['torch_rng_state'])
        if device.type == 'cuda':
            torch.cuda.set_rng_state_all(resume_state['cuda_rng_states'])
        best_ap, best_epoch, best_threshold = (resume_state['best_ap'], resume_state['best_epoch'], resume_state['best_threshold'])
        history = resume_state['history']
        start_epoch = resume_state['epoch'] + 1
    image_cache = {}
    for epoch in range(start_epoch, args.epochs + 1):
        detector.train()
        heads.train()
        if device.type == 'cuda':
            torch.cuda.reset_peak_memory_stats()
        order = rng.permutation(len(train_rows))
        losses_epoch = []
        optimizer.zero_grad(set_to_none=True)
        for step, index in enumerate(order, 1):
            row = train_rows.iloc[index]
            volume, box, _ = cached_record(row, image_cache)
            patch, local_box, _ = sample_patch(volume, box, rng, positive=step % 2 == 1)
            patch = augment_intensity(patch, rng, strong=True)
            image = torch.from_numpy(patch).to(device)
            boxes = np.empty((0, 6), dtype=np.float32) if local_box is None else local_box[None]
            target = {'boxes': torch.as_tensor(boxes, device=device), 'labels': torch.zeros(len(boxes), dtype=torch.int64, device=device)}
            detection_loss = sum(detector([image], [target]).values())
            kd = detection_loss * 0
            if local_box is not None:
                if args.method == 'C':
                    vector = global_features(capture.features)
                    student = torch.stack((vector, vector))
                else:
                    student = lesion_features(capture.features, torch.as_tensor(local_box, device=device), padded_shape(patch.shape[1:]))
                teacher_vectors, quality = ({}, {})
                for modality, path in cache_files[row.patient_id].items():
                    with np.load(path) as saved:
                        cached = saved['global_features'] if args.method == 'C' else saved['features']
                        teacher_vectors[modality] = torch.as_tensor(np.stack((cached, cached)) if args.method == 'C' else cached, device=device)
                        quality[modality] = float(saved['reliability']) if args.method == 'E' else 1.0
                kd = heads(student, teacher_vectors, quality)
            kd_weight = args.lambda_kd * min(1.0, epoch / 10)
            total = detection_loss + kd_weight * kd
            if not torch.isfinite(total):
                raise RuntimeError(f'Nonfinite student loss at epoch {epoch}, patient {row.patient_id}')
            (total / args.accumulate).backward()
            if step % args.accumulate == 0 or step == len(order):
                torch.nn.utils.clip_grad_norm_([*detector.network.parameters(), *heads.parameters()], 5.0)
                optimizer.step()
                optimizer.zero_grad(set_to_none=True)
            losses_epoch.append((float(detection_loss.detach().cpu()), float(kd.detach().cpu())))
        detector.eval()
        val_ap, (threshold, f2) = validate(detector, val_rows, device, image_cache)
        record = {'epoch': epoch, 'detection_loss': float(np.mean(losses_epoch, axis=0)[0]), 'kd_loss': float(np.mean(losses_epoch, axis=0)[1]), 'val_ap50': val_ap, 'val_f2': f2, 'val_threshold': threshold, 'learning_rate': optimizer.param_groups[0]['lr'], 'gpu_peak_gib': torch.cuda.max_memory_allocated() / 2 ** 30 if device.type == 'cuda' else None}
        history.append(record)
        (args.output / 'history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
        print(json.dumps(record), flush=True)
        if val_ap > best_ap:
            best_ap, best_epoch, best_threshold = (val_ap, epoch, threshold)
            torch.save({'network': detector.network.state_dict(), 'heads': heads.state_dict(), 'anchor_shapes_xyz': source['anchor_shapes_xyz'], 'modality': 'T2W', 'method': args.method, 'drop_modality': args.drop_modality, 'epoch': epoch, 'val_ap50': val_ap, 'threshold': threshold, 'protocol': PROTOCOL, 'manifest_sha256': config['manifest_sha256']}, args.output / 'best.pt')
        scheduler.step()
        state = {'epoch': epoch, 'protocol': PROTOCOL, 'network': detector.network.state_dict(), 'heads': heads.state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(), 'numpy_rng_state': rng.bit_generator.state, 'torch_rng_state': torch.get_rng_state(), 'cuda_rng_states': torch.cuda.get_rng_state_all() if device.type == 'cuda' else [], 'best_ap': best_ap, 'best_epoch': best_epoch, 'best_threshold': best_threshold, 'history': history}
        temporary = args.output / 'last.pt.tmp'
        torch.save(state, temporary)
        os.replace(temporary, args.output / 'last.pt')
        if epoch - best_epoch >= args.patience:
            break
    capture.close()
    print(json.dumps({'best_epoch': best_epoch, 'best_val_ap50': best_ap, 'threshold': best_threshold}))

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, default=Path('detection_kd/mapped_208/manifest.csv'))
    parser.add_argument('--t2-teacher', type=Path, required=True)
    parser.add_argument('--cache-root', type=Path, required=True)
    parser.add_argument('--method', choices=['B', 'C', 'D', 'E'], required=True)
    parser.add_argument('--drop-modality', choices=['T1W', 'T1C', 'DWI'])
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--lr', type=float, default=5e-05)
    parser.add_argument('--lambda-kd', type=float, default=0.2)
    parser.add_argument('--accumulate', type=int, default=2)
    parser.add_argument('--seed', type=int, default=20260925)
    parser.add_argument('--limit', type=int, help='Small deterministic smoke subset; use a separate output directory')
    parser.add_argument('--resume', type=Path, help="Resume from this run's last.pt with optimizer and RNG state")
    args = parser.parse_args()
    if args.drop_modality and args.method != 'E':
        parser.error('--drop-modality is only for final-method ablation E')
    train(args)
if __name__ == '__main__':
    main()
