from __future__ import annotations
import json
from pathlib import Path
import numpy as np
import pandas as pd
from preprocess import TARGET_SPACING_XYZ_MM

def kmeans_log_shapes(shapes: np.ndarray, count: int=6, seed: int=20260925) -> np.ndarray:
    if len(shapes) < count:
        raise ValueError('Too few training boxes for anchor fitting')
    points = np.log(shapes)
    rng = np.random.default_rng(seed)
    centers = [points[rng.integers(len(points))]]
    while len(centers) < count:
        distances = np.min(np.stack([np.sum((points - c) ** 2, axis=1) for c in centers]), axis=0)
        probabilities = distances / distances.sum()
        centers.append(points[rng.choice(len(points), p=probabilities)])
    centers = np.stack(centers)
    for _ in range(100):
        labels = np.argmin(((points[:, None, :] - centers[None, :, :]) ** 2).sum(axis=2), axis=1)
        updated = np.stack([points[labels == index].mean(axis=0) if np.any(labels == index) else centers[index] for index in range(count)])
        if np.max(np.abs(updated - centers)) < 1e-05:
            break
        centers = updated
    return np.exp(centers[np.argsort(np.prod(np.exp(centers), axis=1))])

def centered_iou(box_shapes: np.ndarray, anchor_shapes: np.ndarray) -> np.ndarray:
    overlap = np.prod(np.minimum(box_shapes[:, None, :], anchor_shapes[None, :, :]), axis=2)
    volume_gt = np.prod(box_shapes, axis=1)[:, None]
    volume_anchor = np.prod(anchor_shapes, axis=1)[None, :]
    return overlap / (volume_gt + volume_anchor - overlap)

def main() -> None:
    manifest = pd.read_csv(Path('detection_kd/prepared_t2/manifest.csv'), dtype={'patient_id': str})
    train = manifest[(manifest.split == 'train') & manifest.machine_valid]
    sizes = []
    for _, row in train.iterrows():
        box = np.asarray(json.loads(row.box_xyzxyz_half_open), dtype=np.float64)
        native_spacing = np.asarray(json.loads(row.spacing_xyz_mm), dtype=np.float64)
        sizes.append((box[3:] - box[:3]) * native_spacing / np.asarray(TARGET_SPACING_XYZ_MM))
    sizes = np.asarray(sizes)
    bases = kmeans_log_shapes(sizes)
    all_anchors = np.concatenate([bases * scale for scale in (0.5, 1.0, 2.0, 4.0)])
    best_ious = centered_iou(sizes, all_anchors).max(axis=1)
    output = {'source': 'machine-valid internal training T2 boxes only', 'train_box_count': len(sizes), 'target_spacing_xyz_mm': TARGET_SPACING_XYZ_MM, 'base_anchor_shapes_xyz_voxels': bases.round(3).tolist(), 'feature_map_scales': [0.5, 1.0, 2.0, 4.0], 'centered_shape_iou_median': float(np.median(best_ious)), 'centered_shape_iou_p10': float(np.percentile(best_ious, 10))}
    path = Path('detection_kd/prepared_t2/anchors.json')
    path.write_text(json.dumps(output, indent=2), encoding='utf-8')
    print(json.dumps(output, indent=2))
if __name__ == '__main__':
    main()
