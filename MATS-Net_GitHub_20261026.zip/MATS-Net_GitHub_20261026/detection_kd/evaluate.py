from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from metrics import ap50, iou3d, matched_box_statistics
from model import PROTOCOL
from predict import load_detector, predict_work
from training_data import load_record, read_manifest

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, default=Path('detection_kd/mapped_208/manifest.csv'))
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--split', choices=['val', 'test'], default='test')
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists():
        raise FileExistsError(args.output)
    table = read_manifest(args.manifest)
    rows = table[(table.split == args.split) & (table.modality == 'T2W')]
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    detector, checkpoint = load_detector(args.checkpoint, device)
    if checkpoint['manifest_sha256'] != hashlib.sha256(args.manifest.read_bytes()).hexdigest():
        raise ValueError('Evaluation manifest differs from the training manifest')
    threshold = checkpoint.get('threshold')
    if threshold is None:
        raise ValueError('Checkpoint has no frozen validation threshold')
    predictions, references, cases = ({}, {}, [])
    for _, row in rows.iterrows():
        volume, gt, geometry = load_record(row)
        boxes, scores = predict_work(detector, volume, device)
        predictions[row.patient_id] = (boxes, scores)
        references[row.patient_id] = gt
        kept = boxes[scores >= threshold]
        overlaps = [iou3d(box, gt) for box in kept]
        statistics = matched_box_statistics(boxes, scores, gt, threshold, geometry['work_affine'])
        cases.append({'patient_id': row.patient_id, 'image_path': row.image_path, 'reference_work_xyzxyz': gt.tolist(), 'predicted_work_xyzxyz': boxes.tolist(), 'scores': scores.tolist(), 'matched_at_0_5': bool(overlaps) and max(overlaps) >= 0.5, 'best_iou_at_frozen_threshold': max(overlaps, default=0.0), 'false_positive_count': len(kept) - int(bool(overlaps) and max(overlaps) >= 0.5), **statistics})
    tp = sum((case['matched_at_0_5'] for case in cases))
    fp = sum((case['false_positive_count'] for case in cases))
    center_errors = [case['center_error_mm'] for case in cases if case['center_error_mm'] is not None]
    boundary_errors = [case['boundary_abs_errors_mm'] for case in cases if case['boundary_abs_errors_mm'] is not None]
    result = {'split': args.split, 'patients': len(cases), 'checkpoint': str(args.checkpoint), 'protocol': PROTOCOL, 'manifest_sha256': checkpoint['manifest_sha256'], 'checkpoint_sha256': hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(), 'frozen_val_threshold': float(threshold), 'ap50': ap50(predictions, references), 'recall_at_frozen_threshold': tp / len(cases), 'false_positives_per_patient': fp / len(cases), 'mean_iou_missed_as_zero': float(np.mean([case['matched_iou_missed_as_zero'] for case in cases])), 'mean_center_error_mm_matched_only': float(np.mean(center_errors)) if center_errors else None, 'mean_boundary_abs_errors_mm_matched_only': np.mean(boundary_errors, axis=0).tolist() if boundary_errors else None, 'physical_error_match_count': len(center_errors), 'cases': cases}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({key: value for key, value in result.items() if key != 'cases'}, indent=2))
if __name__ == '__main__':
    main()
