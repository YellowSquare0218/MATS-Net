from __future__ import annotations
import argparse
import json
from pathlib import Path
import nibabel as nib
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw, ImageFont

def render_slice(volume: np.ndarray, z: int, box: list[int], caption: str) -> Image.Image:
    plane = volume[:, :, z].T
    finite = plane[np.isfinite(plane) & (plane != 0)]
    low, high = np.percentile(finite, [1, 99]) if finite.size else (0, 1)
    gray = np.uint8(np.clip((plane - low) / max(high - low, 1e-06), 0, 1) * 255)
    image = Image.fromarray(gray, 'L').convert('RGB')
    draw = ImageDraw.Draw(image)
    if box[2] <= z < box[5]:
        draw.rectangle((box[0], box[1], box[3] - 1, box[4] - 1), outline=(255, 64, 40), width=3)
    draw.rectangle((0, 0, image.width, 23), fill=(0, 0, 0))
    draw.text((6, 4), caption, fill=(255, 255, 255), font=ImageFont.load_default())
    return image

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, default=Path('detection_kd/prepared_t2/manifest.csv'))
    parser.add_argument('--output', type=Path, default=Path('detection_kd/prepared_t2/qc_contact_sheet.png'))
    parser.add_argument('--image-root', type=Path, help='Local copy of the full NIfTI cohort')
    parser.add_argument('--cases', type=int, default=6)
    args = parser.parse_args()
    frame = pd.read_csv(args.manifest, dtype={'patient_id': str})
    if 'modality' in frame:
        frame = frame[(frame.modality == 'T2W') & frame.accepted]
    else:
        frame = frame[frame.machine_valid]
    valid = frame.sample(n=min(args.cases, len(frame)), random_state=20260925)
    panels: list[Image.Image] = []
    for _, row in valid.iterrows():
        box = json.loads(row.box_xyzxyz_half_open)
        image_path = args.image_root / row.patient_id / f'{row.patient_id}_T2W.nii.gz' if args.image_root else row.image_path
        volume = nib.load(str(image_path)).get_fdata(dtype=np.float32)
        zs = (box[2], (box[2] + box[5] - 1) // 2, box[5] - 1)
        for name, z in zip(('first', 'middle', 'last'), zs):
            panels.append(render_slice(volume, z, box, f'{row.patient_id} {name} z={z}'))
    width, height = panels[0].size
    canvas = Image.new('RGB', (3 * width, len(valid) * height), (0, 0, 0))
    for index, panel in enumerate(panels):
        canvas.paste(panel, (index % 3 * width, index // 3 * height))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(args.output)
    print(f'Saved {len(valid)} cases to {args.output}')
if __name__ == '__main__':
    main()
