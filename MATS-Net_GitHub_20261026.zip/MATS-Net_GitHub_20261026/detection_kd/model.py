from __future__ import annotations
from collections.abc import Sequence
import torch
from monai.apps.detection.networks.retinanet_detector import RetinaNetDetector
from monai.apps.detection.networks.retinanet_network import RetinaNet
from monai.apps.detection.utils.anchor_utils import AnchorGeneratorWithAnchorShape
from monai.losses import FocalLoss
from monai.networks.blocks.backbone_fpn_utils import BackboneWithFPN
from monai.networks.nets import resnet
PROTOCOL = 'retinanet_fg_norm_aligned_sw_full_appearance_v4'
INFERENCE_ROI = (192, 192, 64)

class ForegroundNormalizedDetector(RetinaNetDetector):

    def compute_cls_loss(self, cls_logits, targets, matched_idxs):
        losses = []
        for logits, target, matches in zip(cls_logits, targets, matched_idxs):
            sampled_logits, truth = self.get_cls_train_sample_per_image(logits, target, matches)
            normalizer = (matches >= 0).sum().clamp_min(1)
            losses.append(self.cls_loss_func(sampled_logits, truth).sum() / normalizer)
        return torch.stack(losses).mean()

def configure_inference(detector, device):
    detector.set_sliding_window_inferer(roi_size=INFERENCE_ROI, sw_batch_size=1, overlap=0.5, sw_device=device, device=device)

def make_detector(anchor_shapes_xyz: Sequence[Sequence[float]]) -> RetinaNetDetector:
    if len(anchor_shapes_xyz) != 6 or any((len(shape) != 3 or min(shape) <= 0 for shape in anchor_shapes_xyz)):
        raise ValueError('Expected six positive 3D anchor shapes')
    backbone = resnet.ResNet(spatial_dims=3, block=resnet.ResNetBlock, layers=[2, 2, 2, 2], block_inplanes=resnet.get_inplanes(), n_input_channels=1, conv1_t_stride=(2, 2, 1), conv1_t_size=(7, 7, 3))
    extractor = BackboneWithFPN(backbone=backbone, return_layers={'layer1': '0', 'layer2': '1', 'layer3': '2'}, in_channels_list=[64, 128, 256], out_channels=128, spatial_dims=3)
    anchors = AnchorGeneratorWithAnchorShape(feature_map_scales=(0.5, 1.0, 2.0, 4.0), base_anchor_shapes=anchor_shapes_xyz, indexing='ij')
    network = RetinaNet(spatial_dims=3, num_classes=1, num_anchors=6, feature_extractor=extractor, size_divisible=(32, 32, 16))
    detector = ForegroundNormalizedDetector(network, anchors)
    detector.set_atss_matcher(num_candidates=4, center_in_gt=False)
    detector.set_cls_loss(FocalLoss(gamma=2.0, alpha=0.25, reduction='none'))
    detector.set_box_regression_loss(torch.nn.SmoothL1Loss(beta=1.0 / 9, reduction='mean'), encode_gt=True, decode_pred=False)
    detector.set_box_selector_parameters(score_thresh=0.05, topk_candidates_per_level=1000, nms_thresh=0.3, detections_per_img=100)
    return detector
