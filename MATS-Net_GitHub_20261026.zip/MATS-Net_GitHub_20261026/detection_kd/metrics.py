from __future__ import annotations
import numpy as np

def iou3d(a: np.ndarray, b: np.ndarray) -> float:
    overlap = np.maximum(np.minimum(a[3:], b[3:]) - np.maximum(a[:3], b[:3]), 0).prod()
    volumes = np.maximum(a[3:] - a[:3], 0).prod() + np.maximum(b[3:] - b[:3], 0).prod()
    return float(overlap / max(volumes - overlap, 1e-08))

def matched_box_statistics(boxes, scores, reference, threshold, work_affine):
    eligible = [i for i in np.argsort(-scores, kind='stable') if scores[i] >= threshold and iou3d(boxes[i], reference) >= 0.5]
    if not eligible:
        return {'matched_iou_missed_as_zero': 0.0, 'center_error_mm': None, 'boundary_abs_errors_mm': None}
    box = boxes[eligible[0]]
    center_delta = (box[:3] + box[3:] - reference[:3] - reference[3:]) / 2
    spacing = np.linalg.norm(work_affine[:3, :3], axis=0)
    return {'matched_iou_missed_as_zero': iou3d(box, reference), 'center_error_mm': float(np.linalg.norm(work_affine[:3, :3] @ center_delta)), 'boundary_abs_errors_mm': (np.abs(box - reference) * np.tile(spacing, 2)).tolist()}

def ap50(predictions: dict[str, tuple[np.ndarray, np.ndarray]], references: dict[str, np.ndarray]) -> float:
    items = sorted(((float(score), patient_id, box) for patient_id, (boxes, scores) in predictions.items() for box, score in zip(boxes, scores)), reverse=True, key=lambda row: row[0])
    if not references:
        raise ValueError('No reference lesions')
    matched = set()
    tp, fp = ([], [])
    for _, patient_id, box in items:
        correct = patient_id in references and patient_id not in matched and (iou3d(box, references[patient_id]) >= 0.5)
        tp.append(int(correct))
        fp.append(int(not correct))
        if correct:
            matched.add(patient_id)
    if not tp:
        return 0.0
    recall = np.cumsum(tp) / len(references)
    precision = np.cumsum(tp) / np.maximum(np.cumsum(tp) + np.cumsum(fp), 1)
    envelope = np.maximum.accumulate(precision[::-1])[::-1]
    previous = np.r_[0, recall[:-1]]
    return float(np.sum((recall - previous) * envelope))

def select_f2_threshold(predictions: dict[str, tuple[np.ndarray, np.ndarray]], references: dict[str, np.ndarray]) -> tuple[float, float]:
    scores = np.array([score for _, values in predictions.items() for score in values[1]], dtype=float)
    if not len(scores):
        return (1.0, 0.0)
    candidates = np.unique(np.r_[0.05, scores])
    best = (0.0, 0.0)
    for threshold in candidates:
        tp = fp = 0
        for patient_id, (boxes, values) in predictions.items():
            kept = boxes[values >= threshold]
            overlaps = [iou3d(box, references[patient_id]) for box in kept] if patient_id in references else []
            match = bool(overlaps) and max(overlaps) >= 0.5
            tp += int(match)
            fp += len(kept) - int(match)
        fn = len(references) - tp
        f2 = 5 * tp / max(5 * tp + 4 * fn + fp, 1)
        if f2 > best[1] or (f2 == best[1] and threshold > best[0]):
            best = (float(threshold), float(f2))
    return best
