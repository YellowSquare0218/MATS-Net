from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import torch
from metrics import iou3d
from model import PROTOCOL
from predict import load_detector, predict_work
from region_kd import FeatureCapture, global_features, lesion_features, padded_shape
from training_data import load_record, read_manifest, sample_patch

def cache(args) -> None:
    if args.output.exists():
        raise FileExistsError(args.output)
    table = read_manifest(args.manifest)
    rows = table[(table.split == 'train') & (table.modality == args.modality)]
    if args.limit:
        rows = rows.iloc[:args.limit]
    if rows.empty:
        raise ValueError('No accepted training patients')
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    detector, checkpoint = load_detector(args.checkpoint, device)
    if checkpoint['modality'] != args.modality:
        raise ValueError('Teacher checkpoint modality mismatch')
    if checkpoint['manifest_sha256'] != hashlib.sha256(args.manifest.read_bytes()).hexdigest():
        raise ValueError('Teacher checkpoint manifest mismatch')
    args.output.mkdir(parents=True)
    capture = FeatureCapture(detector.network.feature_extractor)
    rng = np.random.default_rng(args.seed)
    records = []
    for _, row in rows.iterrows():
        volume, box, _ = load_record(row)
        quality = []
        for gain, bias in ((1.0, 0.0), (1.05, 0.02), (0.95, -0.02)):
            perturbed = np.clip(volume * gain + bias, 0, 1).astype(np.float32)
            perturbed[volume == 0] = 0
            boxes, _ = predict_work(detector, perturbed, device)
            quality.append(max((iou3d(pred, box) for pred in boxes), default=0.0))
        patch, local_box, _ = sample_patch(volume, box, rng, positive=True)
        with torch.no_grad():
            detector([torch.from_numpy(patch).to(device)])
            vectors = lesion_features(capture.features, torch.as_tensor(local_box, device=device), padded_shape(patch.shape[1:]))
            global_vector = global_features(capture.features)
        reliability = float(np.mean(quality))
        np.savez_compressed(args.output / f'{row.patient_id}.npz', features=vectors.detach().cpu().numpy().astype(np.float32), global_features=global_vector.detach().cpu().numpy().astype(np.float32), reliability=np.float32(reliability))
        records.append({'patient_id': row.patient_id, 'reliability': reliability, 'three_ious': quality})
        print(json.dumps(records[-1]), flush=True)
    capture.close()
    metadata = {'modality': args.modality, 'protocol': PROTOCOL, 'manifest_sha256': hashlib.sha256(args.manifest.read_bytes()).hexdigest(), 'checkpoint_sha256': hashlib.sha256(args.checkpoint.read_bytes()).hexdigest(), 'seed': args.seed, 'patients': len(records), 'quality_definition': 'mean best 3D IoU over original and two fixed intensity perturbations'}
    (args.output / 'metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    (args.output / 'quality.json').write_text(json.dumps(records, indent=2), encoding='utf-8')

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest', type=Path, default=Path('detection_kd/mapped_208/manifest.csv'))
    parser.add_argument('--modality', choices=['T1W', 'T2W', 'T1C', 'DWI'], required=True)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=20260925)
    parser.add_argument('--limit', type=int, help='Small deterministic smoke subset; use a separate output directory')
    cache(parser.parse_args())
if __name__ == '__main__':
    main()
