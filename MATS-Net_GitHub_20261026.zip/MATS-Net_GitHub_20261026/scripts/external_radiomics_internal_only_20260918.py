from _paths import project_path as _project_path
from pathlib import Path
import json
import logging
import hashlib
import numpy as np
import pandas as pd
import nibabel as nib
import SimpleITK as sitk
from radiomics import featureextractor
import radiomics
import joblib
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import StratifiedGroupKFold, GridSearchCV
from sklearn.metrics import roc_auc_score, confusion_matrix, f1_score, brier_score_loss
R = Path(_project_path(''))
O = R / 'work/external_radiomics_internal_only_20260918'
SEED = 20260918

def save(name, obj):
    (O / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False), encoding='utf-8')

def extract(path, ex):
    n = nib.load(str(path))
    arr = n.get_fdata().astype(np.float32)
    assert np.isfinite(arr).all()
    mask = (np.abs(arr) > 1e-08).astype(np.uint8)
    assert mask.sum() >= 8
    im = sitk.GetImageFromArray(np.pad(arr.transpose(2, 1, 0), 1))
    ma = sitk.GetImageFromArray(np.pad(mask.transpose(2, 1, 0), 1))
    im.SetSpacing(tuple((float(x) for x in n.header.get_zooms()[:3])))
    ma.CopyInformation(im)
    f = ex.execute(im, ma)
    return {k: float(v) for k, v in f.items() if k.startswith('original_')}

def main():
    O.mkdir(exist_ok=True)
    sitk.ProcessObject.SetGlobalDefaultNumberOfThreads(4)
    logging.getLogger('radiomics').setLevel(logging.ERROR)
    labels = R / 'dataset/roi_v4/labels_clinical_expanded_262.csv'
    d = pd.read_csv(labels, dtype={'id': str, 'base_id': str})
    assert len(d) == 262 and d.id.is_unique and (set(d.label) == {0, 1})
    ex = featureextractor.RadiomicsFeatureExtractor(normalize=True, normalizeScale=100, binWidth=25, removeOutliers=3)
    ex.disableAllFeatures()
    for c in ['firstorder', 'glcm', 'glrlm', 'glszm']:
        ex.enableFeatureClassByName(c)
    save('protocol.json', {'train': 'internal262 only; original clinical labels, not synthetic reassignment', 'selection': '5-fold StratifiedGroupKFold by base_id, all preprocessing inside each CV fit', 'features': 'T2-only firstorder/glcm/glrlm/glszm; no shape, no clinical inputs', 'extractor_settings': dict(ex.settings), 'radiomics_version': radiomics.__version__, 'mask': 'nonzero crop, zero padded border; not lesion segmentation', 'spacing': 'NIfTI zooms', 'threshold': 0.5, 'seed': SEED, 'external_use': 'prediction only; labels accessed for metrics after model and predictions saved', 'labels_sha256': hashlib.sha256(labels.read_bytes()).hexdigest(), 'caveat': 'Retrospective evaluation of a previously examined external cohort, not a newly untouched prospective test.'})
    cache = O / 'internal_T2_features.csv'
    if not cache.exists():
        rows = []
        for i, pid in enumerate(d.id):
            f = extract(R / 'dataset/roi_v4' / pid / 'T2W.nii.gz', ex)
            assert len(f) > 30 and np.isfinite(list(f.values())).all()
            rows.append({'pid': pid, **f})
            if i % 20 == 0:
                print('INTERNAL_FEATURES', i + 1, 262, flush=True)
        pd.DataFrame(rows).to_csv(cache, index=False)
    features = pd.read_csv(cache, dtype={'pid': str}).set_index('pid').loc[d.id]
    cols = list(features.columns)
    x = features.to_numpy()
    y = d.label.to_numpy()
    assert np.isfinite(x).all()
    cv = list(StratifiedGroupKFold(5, shuffle=True, random_state=SEED).split(x, y, d.base_id))
    for tr, va in cv:
        assert not set(d.base_id.iloc[tr]) & set(d.base_id.iloc[va])
    save('internal_folds.json', [{'train_ids': d.id.iloc[tr].tolist(), 'validation_ids': d.id.iloc[va].tolist()} for tr, va in cv])
    pipeline = make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), LogisticRegression(penalty='elasticnet', solver='saga', class_weight='balanced', max_iter=10000, random_state=SEED))
    search = GridSearchCV(pipeline, {'logisticregression__C': [0.01, 0.1, 1.0], 'logisticregression__l1_ratio': [0.1, 0.5, 0.9]}, scoring='roc_auc', cv=cv, n_jobs=4, error_score='raise')
    search.fit(x, y)
    joblib.dump(search.best_estimator_, O / 'internal_only_model.joblib')
    pd.DataFrame(search.cv_results_).to_csv(O / 'internal_cv_search.csv', index=False)
    save('locked_model.json', {'params': search.best_params_, 'selected_internal_cv_auc': search.best_score_, 'columns': cols, 'warning': 'selected internal CV score, not unbiased internal test estimate'})
    print('MODEL_LOCKED', search.best_params_, flush=True)
    extpath = R / 'work/external_comparators_locked280_20260918/radiomics/crop_features.csv'
    ext = pd.read_csv(extpath, dtype={'pid': str}).set_index('pid')
    assert len(ext) == 352 and ext.index.is_unique and (set(ext.columns) == set(cols))
    roi = R / 'dataset/guangxi_external_roi_t2_center_crop_f0p45'
    for pid in ext.index[:2]:
        check = extract(roi / pid / 'T2W.nii.gz', ex)
        np.testing.assert_allclose([check[c] for c in cols], ext.loc[pid, cols].to_numpy(float), rtol=1e-05, atol=1e-07)
    assert np.isfinite(ext[cols].to_numpy()).all()
    pred = pd.DataFrame({'pid': ext.index, 'prob_pos': search.best_estimator_.predict_proba(ext[cols].to_numpy())[:, 1]})
    pred.to_csv(O / 'external_predictions_before_labels.csv', index=False)
    ref = pd.read_csv(R / 'work/external_t2_adapt_stratified280_20260824/ma_cmara_student/all_case_predictions.csv', dtype={'pid': str})
    aligned = pred.merge(ref[['pid', 'label', 'source_ensemble_prob']], on='pid', validate='one_to_one')
    assert len(aligned) == 352
    aligned.to_csv(O / 'external_predictions.csv', index=False)
    y = aligned.label.to_numpy()
    p = aligned.prob_pos.to_numpy()
    rp = aligned.source_ensemble_prob.to_numpy()
    tn, fp, fn, tp = confusion_matrix(y, p >= 0.5).ravel()
    rng = np.random.default_rng(SEED)
    neg = np.flatnonzero(y == 0)
    pos = np.flatnonzero(y == 1)
    auc_samples = []
    delta = []
    for _ in range(2000):
        ix = np.r_[rng.choice(neg, len(neg)), rng.choice(pos, len(pos))]
        a = roc_auc_score(y[ix], p[ix])
        auc_samples.append(a)
        delta.append(a - roc_auc_score(y[ix], rp[ix]))
    lo, hi = np.quantile(auc_samples, [0.025, 0.975])
    dl, dh = np.quantile(delta, [0.025, 0.975])
    ece = 0.0
    for k in range(10):
        b = (p >= k / 10) & (p < (k + 1) / 10 if k < 9 else p <= 1)
        if b.any():
            ece += b.mean() * abs(p[b].mean() - y[b].mean())
    metrics = {'model': 'T2WI crop-radiomics internal-only elastic-net', 'n': len(y), 'auc': roc_auc_score(y, p), 'auc_ci_low': lo, 'auc_ci_high': hi, 'delta_auc_vs_unadapted_student': roc_auc_score(y, p) - roc_auc_score(y, rp), 'delta_ci_low': dl, 'delta_ci_high': dh, 'accuracy': (tn + tp) / len(y), 'sensitivity': tp / (tp + fn), 'specificity': tn / (tn + fp), 'f1': f1_score(y, p >= 0.5), 'brier': brier_score_loss(y, p), 'ece': ece, 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp), 'threshold': 0.5}
    save('metrics.json', metrics)
    pd.DataFrame([metrics]).to_csv(O / 'metrics.csv', index=False)
    save('complete.json', {'finished': True, 'internal_training_n': 262, 'external_prediction_n': 352, 'external_training_n': 0, 'external_feature_cache_two_cases_verified': True})
    print(json.dumps(metrics, indent=2), flush=True)
if __name__ == '__main__':
    main()
