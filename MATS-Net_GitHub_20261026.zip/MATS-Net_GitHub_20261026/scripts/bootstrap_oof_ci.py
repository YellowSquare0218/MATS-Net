import argparse
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score
CORE_MODELS = {'single_T2W': 'single_T2W', 'single_DWI': 'single_DWI', 'single_T1C': 'single_T1C', 'single_T1W': 'single_T1W', 'G-MARA geometry only': 'gmara_geometry_only', 'G-MARA clinical only': 'gmara_clinical_only', 'Clinical-geometry G-MARA no perturbation': 'gmara_clingeo_nocausal', 'Clinical-geometry G-MARA': 'gmara_clingeo', 'LN-burden G-MARA balanced': 'gmara_clingeo_node_burden_mtl', 'LN-burden G-MARA AUC-selected': 'gmara_clingeo_node_burden_auc', 'LN-burden weight 0.04': 'gmara_burden_w004'}

def fixed_metrics(y, score, threshold=0.5):
    pred = (score >= threshold).astype(int)
    neg = y == 0
    pos = y == 1
    tn = int(np.sum((pred == 0) & neg))
    fp = int(np.sum((pred == 1) & neg))
    fn = int(np.sum((pred == 0) & pos))
    tp = int(np.sum((pred == 1) & pos))
    return {'auc': roc_auc_score(y, score), 'acc': accuracy_score(y, pred), 'f1': f1_score(y, pred, zero_division=0), 'precision': precision_score(y, pred, zero_division=0), 'recall': recall_score(y, pred, zero_division=0), 'sensitivity': tp / (tp + fn) if tp + fn else np.nan, 'specificity': tn / (tn + fp) if tn + fp else np.nan}

def bootstrap_ci(y, score, n_boot=2000, seed=42, threshold=0.5):
    rng = np.random.default_rng(seed)
    n = len(y)
    estimates = {k: [] for k in ['auc', 'acc', 'f1', 'precision', 'recall', 'sensitivity', 'specificity']}
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        y_b = y[idx]
        if len(np.unique(y_b)) < 2:
            continue
        m = fixed_metrics(y_b, score[idx], threshold=threshold)
        for key, value in m.items():
            estimates[key].append(value)
    out = {}
    point = fixed_metrics(y, score, threshold=threshold)
    for key, values in estimates.items():
        arr = np.asarray(values, dtype=float)
        out[key] = point[key]
        out[f'{key}_ci_low'] = float(np.nanpercentile(arr, 2.5))
        out[f'{key}_ci_high'] = float(np.nanpercentile(arr, 97.5))
    return out

def paired_auc_bootstrap(y, score_a, score_b, n_boot=2000, seed=123):
    rng = np.random.default_rng(seed)
    n = len(y)
    diffs = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, size=n)
        y_b = y[idx]
        if len(np.unique(y_b)) < 2:
            continue
        diffs.append(roc_auc_score(y_b, score_a[idx]) - roc_auc_score(y_b, score_b[idx]))
    diffs = np.asarray(diffs, dtype=float)
    point = roc_auc_score(y, score_a) - roc_auc_score(y, score_b)
    p_two_sided = 2 * min(np.mean(diffs <= 0), np.mean(diffs >= 0))
    return {'auc_diff': point, 'auc_diff_ci_low': float(np.percentile(diffs, 2.5)), 'auc_diff_ci_high': float(np.percentile(diffs, 97.5)), 'bootstrap_p_two_sided': min(float(p_two_sided), 1.0)}

def add_fusion_scores(df):
    df = df.copy()
    df['Best fusion AUC selected'] = df[['single_T2W', 'single_DWI', 'mara', 'gmara_auc', 'gmara_burden_w004']].mean(axis=1)
    w = 0.2 * df['mara'] + 0.15 * df['early'] + 0.15 * df['cif'] + 0.2 * df['gmara_clingeo'] + 0.3 * df['gmara_clingeo_node_burden_mtl']
    df['Best threshold-accuracy fusion selected'] = 0.9 * w + 0.1 * df['geo_lr_c0_3']
    return df

def write_markdown(metrics_df, pairs_df, out_md):
    metric_cols = ['model', 'auc', 'auc_ci_low', 'auc_ci_high', 'acc', 'acc_ci_low', 'acc_ci_high', 'f1', 'f1_ci_low', 'f1_ci_high', 'sensitivity', 'sensitivity_ci_low', 'sensitivity_ci_high', 'specificity', 'specificity_ci_low', 'specificity_ci_high']
    lines = ['# Bootstrap OOF Confidence Intervals - 2026-06-03', '', 'Bootstrap used patient-row resampling with replacement on existing out-of-fold predictions. These intervals quantify internal OOF uncertainty and do not solve external validation or fusion model-selection bias.', '', '## Core Model Metrics', '', metrics_df[metric_cols].to_markdown(index=False, floatfmt='.3f'), '', '## Paired Bootstrap AUC Differences', '', pairs_df.to_markdown(index=False, floatfmt='.3f'), '', 'Interpretation: intervals that cross 0 and large bootstrap p values indicate that the current OOF predictions do not support a firm ranking claim for that contrast.']
    out_md.write_text('\n'.join(lines) + '\n', encoding='utf-8')

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--aligned', default='training_results/fast_evidence_fusion_aug262_supplementary_2cls/aligned_predictions.csv')
    parser.add_argument('--out_dir', default='training_results/statistical_ci_aug262')
    parser.add_argument('--n_boot', type=int, default=2000)
    parser.add_argument('--seed', type=int, default=42)
    args = parser.parse_args()
    root = Path.cwd()
    aligned = root / args.aligned
    out_dir = root / args.out_dir
    out_dir.mkdir(parents=True, exist_ok=True)
    df = pd.read_csv(aligned)
    df = add_fusion_scores(df)
    y = df['label'].to_numpy(dtype=int)
    model_scores = dict(CORE_MODELS)
    model_scores['Best fusion AUC selected'] = 'Best fusion AUC selected'
    model_scores['Best threshold-accuracy fusion selected'] = 'Best threshold-accuracy fusion selected'
    rows = []
    for name, col in model_scores.items():
        m = bootstrap_ci(y, df[col].to_numpy(dtype=float), n_boot=args.n_boot, seed=args.seed)
        rows.append({'model': name, 'score_column': col, **m})
    metrics_df = pd.DataFrame(rows)
    metrics_df.to_csv(out_dir / 'bootstrap_oof_ci_core_models.csv', index=False)
    pairs = [('geometry_only minus clinical_only', 'gmara_geometry_only', 'gmara_clinical_only'), ('full clinical-geometry minus no-perturbation', 'gmara_clingeo', 'gmara_clingeo_nocausal'), ('LN-burden balanced minus clinical-geometry', 'gmara_clingeo_node_burden_mtl', 'gmara_clingeo'), ('Best fusion AUC minus LN-burden balanced', 'Best fusion AUC selected', 'gmara_clingeo_node_burden_mtl'), ('Best fusion AUC minus T1C', 'Best fusion AUC selected', 'single_T1C')]
    pair_rows = []
    for name, a, b in pairs:
        pair_rows.append({'contrast': name, **paired_auc_bootstrap(y, df[a].to_numpy(dtype=float), df[b].to_numpy(dtype=float), n_boot=args.n_boot, seed=args.seed + 7)})
    pairs_df = pd.DataFrame(pair_rows)
    pairs_df.to_csv(out_dir / 'paired_bootstrap_auc_differences.csv', index=False)
    write_markdown(metrics_df, pairs_df, out_dir / 'bootstrap_oof_ci_report.md')
    print(out_dir / 'bootstrap_oof_ci_report.md')
if __name__ == '__main__':
    main()
