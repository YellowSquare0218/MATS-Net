from __future__ import annotations
import argparse
import csv
import json
import os
import re
import struct
import sys
import time
import zipfile
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Optional, Tuple
TARGET_TAGS = {(8, 32): 'StudyDate', (8, 33): 'SeriesDate', (8, 48): 'StudyTime', (8, 49): 'SeriesTime', (8, 96): 'Modality', (8, 112): 'Manufacturer', (8, 4158): 'SeriesDescription', (8, 4240): 'ManufacturerModelName', (16, 16): 'PatientName', (16, 32): 'PatientID', (24, 32): 'ScanningSequence', (24, 33): 'SequenceVariant', (24, 34): 'ScanOptions', (24, 35): 'MRAcquisitionType', (24, 80): 'SliceThickness', (24, 129): 'EchoTime', (24, 135): 'MagneticFieldStrength', (24, 136): 'SpacingBetweenSlices', (24, 4144): 'ProtocolName', (24, 4884): 'FlipAngle', (32, 13): 'StudyInstanceUID', (32, 14): 'SeriesInstanceUID', (32, 17): 'SeriesNumber', (32, 19): 'InstanceNumber', (40, 8): 'NumberOfFrames', (40, 16): 'Rows', (40, 17): 'Columns', (40, 48): 'PixelSpacing'}
STRING_VRS = {'AE', 'AS', 'CS', 'DA', 'DS', 'DT', 'IS', 'LO', 'LT', 'PN', 'SH', 'ST', 'TM', 'UI', 'UT'}
NUMERIC_2_VRS = {'US', 'SS'}
NUMERIC_4_VRS = {'UL', 'SL', 'FL'}
NUMERIC_8_VRS = {'FD'}
LONG_VRS = {'OB', 'OD', 'OF', 'OL', 'OV', 'OW', 'SQ', 'UC', 'UR', 'UT', 'UN'}

@dataclass
class SeriesSummary:
    patient_id: str
    series_key: str
    fields: Dict[str, str] = field(default_factory=dict)
    image_count: int = 0
    total_bytes: int = 0
    first_file: str = ''
    last_file: str = ''
    parse_errors: int = 0

    def add_file(self, decoded_path: str, file_size: int, tags: Dict[str, str], parse_error: bool) -> None:
        self.image_count += 1
        self.total_bytes += int(file_size or 0)
        if not self.first_file:
            self.first_file = decoded_path
        self.last_file = decoded_path
        if parse_error:
            self.parse_errors += 1
        for key, value in tags.items():
            if value not in ('', None) and (not self.fields.get(key)):
                self.fields[key] = str(value)

def decode_zip_name(raw_name: str) -> str:
    try:
        return raw_name.encode('cp437').decode('gbk')
    except Exception:
        return raw_name

def clean_value(value: str) -> str:
    value = value.replace('\x00', '').strip()
    value = re.sub('\\s+', ' ', value)
    return value

def decode_value(vr: Optional[str], raw: bytes, endian: str) -> str:
    if raw is None:
        return ''
    raw = raw.rstrip(b'\x00 ')
    if not raw:
        return ''
    if vr in NUMERIC_2_VRS and len(raw) >= 2:
        fmt = 'H' if vr == 'US' else 'h'
        count = len(raw) // 2
        vals = struct.unpack(endian + fmt * count, raw[:count * 2])
        return '\\'.join((str(v) for v in vals))
    if vr in NUMERIC_4_VRS and len(raw) >= 4:
        if vr == 'FL':
            fmt = 'f'
        else:
            fmt = 'L' if vr == 'UL' else 'l'
        count = len(raw) // 4
        vals = struct.unpack(endian + fmt * count, raw[:count * 4])
        return '\\'.join((f'{v:g}' if isinstance(v, float) else str(v) for v in vals))
    if vr in NUMERIC_8_VRS and len(raw) >= 8:
        count = len(raw) // 8
        vals = struct.unpack(endian + 'd' * count, raw[:count * 8])
        return '\\'.join((f'{v:g}' for v in vals))
    for encoding in ('utf-8', 'gbk', 'latin1'):
        try:
            return clean_value(raw.decode(encoding, errors='ignore'))
        except Exception:
            continue
    return clean_value(str(raw))

def parse_explicit_element(buf: bytes, pos: int, endian: str) -> Tuple[Optional[Tuple[int, int, str, int, int]], int]:
    if pos + 8 > len(buf):
        return (None, len(buf))
    group, elem = struct.unpack(endian + 'HH', buf[pos:pos + 4])
    vr = buf[pos + 4:pos + 6].decode('ascii', errors='ignore')
    if not re.match('^[A-Z0-9]{2}$', vr):
        return (None, len(buf))
    if vr in LONG_VRS:
        if pos + 12 > len(buf):
            return (None, len(buf))
        length = struct.unpack(endian + 'L', buf[pos + 8:pos + 12])[0]
        value_pos = pos + 12
    else:
        length = struct.unpack(endian + 'H', buf[pos + 6:pos + 8])[0]
        value_pos = pos + 8
    next_pos = len(buf) if length == 4294967295 else value_pos + length
    return ((group, elem, vr, length, value_pos), next_pos)

def parse_implicit_element(buf: bytes, pos: int, endian: str) -> Tuple[Optional[Tuple[int, int, str, int, int]], int]:
    if pos + 8 > len(buf):
        return (None, len(buf))
    group, elem, length = struct.unpack(endian + 'HHL', buf[pos:pos + 8])
    value_pos = pos + 8
    next_pos = len(buf) if length == 4294967295 else value_pos + length
    return ((group, elem, '', length, value_pos), next_pos)

def parse_dicom_header(buf: bytes) -> Tuple[Dict[str, str], bool]:
    tags: Dict[str, str] = {}
    parse_error = False
    if len(buf) < 132 or buf[128:132] != b'DICM':
        return (tags, True)
    pos = 132
    transfer_syntax = '1.2.840.10008.1.2.1'
    endian = '<'
    explicit = True
    while pos + 8 <= len(buf):
        item, next_pos = parse_explicit_element(buf, pos, '<')
        if item is None:
            parse_error = True
            break
        group, elem, vr, length, value_pos = item
        if group != 2:
            break
        if (group, elem) == (2, 16):
            raw = buf[value_pos:min(value_pos + length, len(buf))]
            transfer_syntax = decode_value(vr, raw, '<')
        pos = next_pos
        if pos <= value_pos or pos > len(buf):
            parse_error = True
            break
    if transfer_syntax == '1.2.840.10008.1.2':
        explicit = False
        endian = '<'
    elif transfer_syntax == '1.2.840.10008.1.2.2':
        explicit = True
        endian = '>'
    else:
        explicit = True
        endian = '<'
    steps = 0
    while pos + 8 <= len(buf) and steps < 4096:
        steps += 1
        parser = parse_explicit_element if explicit else parse_implicit_element
        item, next_pos = parser(buf, pos, endian)
        if item is None:
            parse_error = True
            break
        group, elem, vr, length, value_pos = item
        if (group, elem) == (32736, 16):
            break
        if group == 65534:
            pos = next_pos
            continue
        if (group, elem) in TARGET_TAGS and length != 4294967295:
            raw = buf[value_pos:min(value_pos + length, len(buf))]
            tags[TARGET_TAGS[group, elem]] = decode_value(vr, raw, endian)
        if length == 4294967295:
            break
        if next_pos <= pos or next_pos > len(buf) + 4:
            parse_error = True
            break
        pos = next_pos
    tags['TransferSyntaxUID'] = transfer_syntax
    return (tags, parse_error)

def norm_text(*parts: str) -> str:
    return ' '.join((str(p or '').lower() for p in parts))

def classify_series(fields: Dict[str, str]) -> str:
    desc_text = norm_text(fields.get('SeriesDescription'), fields.get('ProtocolName'))
    aux_text = norm_text(fields.get('SeriesDescription'), fields.get('ProtocolName'), fields.get('ScanningSequence'), fields.get('SequenceVariant'), fields.get('ScanOptions'))
    tokens = re.findall('[a-z0-9]+', desc_text)
    if any((x in aux_text for x in ['localizer', 'scout', 'calib', 'survey', '定位'])):
        return 'LOCALIZER'
    if any((x in aux_text for x in ['screen save', 'screensave', 'screensave', 'phoenix', 'report'])):
        return 'DERIVED'
    if any((token == 'adc' or token.endswith('adc') for token in tokens)) or 'apparent diffusion' in desc_text:
        return 'ADC'
    if any((token.startswith(('dwi', 'diff', 'ep2d')) for token in tokens)) or 'diffusion' in desc_text or re.search('\\bb[0-9]{2,4}\\b', desc_text):
        return 'DWI'
    contrast_terms = ['+c', 'c+', 'post', 'dyn', 'dynamic', 'lava', 'vibe', 'water', 'gd', 'ce', 'enh', 'contrast']
    has_t1 = any((token.startswith('t1') for token in tokens))
    has_t2 = any((token.startswith('t2') for token in tokens))
    has_contrast = any((x in desc_text for x in contrast_terms))
    if has_t1 and has_contrast:
        return 'T1C'
    if any((x in desc_text for x in ['lava', 'vibe', 'dynamic', 'water: dyn', 'liver acquisition'])):
        return 'T1C'
    if has_t2:
        return 'T2'
    if has_t1:
        return 'T1'
    return 'OTHER'

def choose_best_series(series: Iterable[SeriesSummary], label: str) -> Optional[SeriesSummary]:
    candidates = [s for s in series if s.fields.get('sequence_class') == label]
    if not candidates:
        return None

    def safe_int(value: object) -> int:
        try:
            return int(float(str(value).split('\\')[0]))
        except Exception:
            return 0

    def seq_text(s: SeriesSummary) -> str:
        return norm_text(s.fields.get('SeriesDescription'), s.fields.get('ProtocolName'))

    def orientation_score(text: str) -> int:
        tokens = set(re.findall('[a-z0-9]+', text))
        if tokens & {'ax', 'oax', 'tra', 'trans', 'transverse', 'axial'}:
            return 4
        if any((token.startswith('ax') for token in tokens)):
            return 4
        if tokens & {'sag', 'osag', 'sagittal', 'cor', 'ocor', 'coronal'}:
            return 2
        return 0

    def family_score(text: str) -> int:
        if label == 'T2':
            if any((x in text for x in ['frfse', 'tse', ' fse', '_fse', 't2fse'])):
                return 5
            if 'blade' in text:
                return 4
            if 'trufi' in text:
                return 1
        if label == 'T1':
            if any((x in text for x in ['tse', ' fse', '_fse', 't1wi'])):
                return 5
            if any((x in text for x in ['quick3d', 'fl3d', 'vibe'])):
                return 3
            if 'fl2d' in text:
                return 2
        if label == 'T1C':
            if any((x in text for x in ['lava', 'vibe', 'dynamic', 'dyna', 'water'])):
                return 5
            if any((x in text for x in ['+c', 'c+', 'post', 'enh', 'contrast'])):
                return 4
        if label == 'DWI':
            if any((x in text for x in ['dwi', 'diff', 'ep2d'])):
                return 5
        if label == 'ADC':
            if 'adc' in text or 'apparent diffusion' in text:
                return 5
        return 0
    return sorted(candidates, key=lambda s: (orientation_score(seq_text(s)), family_score(seq_text(s)), safe_int(s.fields.get('Rows')) * safe_int(s.fields.get('Columns')), s.image_count, s.total_bytes), reverse=True)[0]

def write_csv(path: str, rows: List[Dict[str, object]], fieldnames: List[str]) -> None:
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction='ignore')
        writer.writeheader()
        writer.writerows(rows)

def parse_patient_id(decoded_path: str) -> Optional[str]:
    parts = [p for p in decoded_path.replace('\\', '/').split('/') if p]
    for part in parts:
        if re.match('^MR\\d+', part, flags=re.I):
            return part.upper()
    return None

def inventory(args: argparse.Namespace) -> None:
    os.makedirs(args.out_dir, exist_ok=True)
    started = time.time()
    series_map: Dict[Tuple[str, str], SeriesSummary] = {}
    patient_file_counts: Counter = Counter()
    skipped = Counter()
    with zipfile.ZipFile(args.zip_path) as zf:
        infos = zf.infolist()
        candidate_infos = []
        for info in infos:
            if info.is_dir():
                skipped['dirs'] += 1
                continue
            decoded = decode_zip_name(info.filename)
            base = os.path.basename(decoded)
            if base.upper() == 'DICOMDIR':
                skipped['dicomdir'] += 1
                continue
            if os.path.splitext(base)[1].lower() in {'.xlsx', '.xls', '.htm', '.html', '.nii', '.gz', '.csv'}:
                skipped['non_dicom_extension'] += 1
                continue
            patient_id = parse_patient_id(decoded)
            if not patient_id:
                skipped['no_patient_id'] += 1
                continue
            candidate_infos.append((info, decoded, patient_id))
        if args.max_files and args.max_files > 0:
            candidate_infos = candidate_infos[:args.max_files]
        total = len(candidate_infos)
        for idx, (info, decoded, patient_id) in enumerate(candidate_infos, start=1):
            patient_file_counts[patient_id] += 1
            try:
                with zf.open(info, 'r') as fp:
                    header = fp.read(args.read_bytes)
                tags, parse_error = parse_dicom_header(header)
            except Exception:
                tags, parse_error = ({}, True)
            if not tags:
                skipped['not_dicom_or_unparsed'] += 1
                continue
            series_uid = tags.get('SeriesInstanceUID') or ''
            series_number = tags.get('SeriesNumber') or ''
            series_desc = tags.get('SeriesDescription') or ''
            protocol_name = tags.get('ProtocolName') or ''
            if series_uid:
                series_key = series_uid
            else:
                series_key = '|'.join([series_number, series_desc, protocol_name]) or decoded
            key = (patient_id, series_key)
            if key not in series_map:
                series_map[key] = SeriesSummary(patient_id=patient_id, series_key=series_key)
            tags['sequence_class'] = classify_series(tags)
            series_map[key].add_file(decoded, info.file_size, tags, parse_error)
            if args.progress_every and idx % args.progress_every == 0:
                elapsed = time.time() - started
                rate = idx / elapsed if elapsed else 0
                print(f'[progress] {idx}/{total} files, {len(series_map)} series, {len(patient_file_counts)} patients, {rate:.1f} files/s', flush=True)
    series_rows: List[Dict[str, object]] = []
    for s in sorted(series_map.values(), key=lambda x: (x.patient_id, x.fields.get('SeriesNumber', ''), x.series_key)):
        row = {'patient_id': s.patient_id, 'series_key': s.series_key, 'sequence_class': s.fields.get('sequence_class', 'OTHER'), 'image_count': s.image_count, 'total_bytes': s.total_bytes, 'first_file': s.first_file, 'last_file': s.last_file, 'parse_errors': s.parse_errors}
        row.update({name: s.fields.get(name, '') for name in sorted(set(TARGET_TAGS.values()) | {'TransferSyntaxUID'})})
        series_rows.append(row)
    series_fields = ['patient_id', 'sequence_class', 'series_key', 'SeriesNumber', 'SeriesDescription', 'ProtocolName', 'image_count', 'Rows', 'Columns', 'NumberOfFrames', 'MRAcquisitionType', 'EchoTime', 'SliceThickness', 'SpacingBetweenSlices', 'PixelSpacing', 'Modality', 'StudyDate', 'SeriesTime', 'Manufacturer', 'ManufacturerModelName', 'PatientID', 'PatientName', 'ScanningSequence', 'SequenceVariant', 'ScanOptions', 'TransferSyntaxUID', 'parse_errors', 'total_bytes', 'first_file', 'last_file']
    series_path = os.path.join(args.out_dir, 'guangxi_series_inventory.csv')
    write_csv(series_path, series_rows, series_fields)
    by_patient: Dict[str, List[SeriesSummary]] = defaultdict(list)
    for s in series_map.values():
        by_patient[s.patient_id].append(s)
    patient_rows: List[Dict[str, object]] = []
    labels = ['T2', 'DWI', 'ADC', 'T1', 'T1C', 'LOCALIZER', 'DERIVED', 'OTHER']
    for patient_id in sorted(by_patient):
        series_list = by_patient[patient_id]
        counts = Counter((s.fields.get('sequence_class', 'OTHER') for s in series_list))
        row: Dict[str, object] = {'patient_id': patient_id, 'dicom_file_count': patient_file_counts.get(patient_id, 0), 'series_count': len(series_list)}
        for label in labels:
            label_series = [s for s in series_list if s.fields.get('sequence_class') == label]
            row[f'has_{label.lower()}'] = int(bool(label_series))
            row[f'{label.lower()}_series_count'] = len(label_series)
            row[f'{label.lower()}_image_count'] = sum((s.image_count for s in label_series))
        for label in ['T2', 'DWI', 'ADC', 'T1', 'T1C']:
            best = choose_best_series(series_list, label)
            prefix = label.lower()
            row[f'selected_{prefix}_series_key'] = best.series_key if best else ''
            row[f'selected_{prefix}_series_description'] = best.fields.get('SeriesDescription', '') if best else ''
            row[f'selected_{prefix}_protocol_name'] = best.fields.get('ProtocolName', '') if best else ''
            row[f'selected_{prefix}_image_count'] = best.image_count if best else 0
            row[f'selected_{prefix}_first_file'] = best.first_file if best else ''
        patient_rows.append(row)
    patient_fields = ['patient_id', 'dicom_file_count', 'series_count']
    for label in labels:
        patient_fields.extend([f'has_{label.lower()}', f'{label.lower()}_series_count', f'{label.lower()}_image_count'])
    for label in ['T2', 'DWI', 'ADC', 'T1', 'T1C']:
        prefix = label.lower()
        patient_fields.extend([f'selected_{prefix}_series_key', f'selected_{prefix}_series_description', f'selected_{prefix}_protocol_name', f'selected_{prefix}_image_count', f'selected_{prefix}_first_file'])
    patient_path = os.path.join(args.out_dir, 'guangxi_patient_modality_manifest.csv')
    write_csv(patient_path, patient_rows, patient_fields)
    summary = {'zip_path': args.zip_path, 'read_bytes': args.read_bytes, 'elapsed_seconds': round(time.time() - started, 3), 'zip_entries': len(infos), 'candidate_dicom_files': sum(patient_file_counts.values()), 'parsed_dicom_files': sum((s.image_count for s in series_map.values())), 'patient_count': len(by_patient), 'series_count': len(series_map), 'skipped': dict(skipped), 'patient_manifest': patient_path, 'series_inventory': series_path, 'sequence_class_series_counts': dict(Counter((row['sequence_class'] for row in series_rows))), 'sequence_class_patient_counts': {label: int(sum((1 for row in patient_rows if row.get(f'has_{label.lower()}') == 1))) for label in labels}}
    summary_path = os.path.join(args.out_dir, 'guangxi_inventory_summary.json')
    with open(summary_path, 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)

def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip-path', required=True, help='Path to Guangxi zip archive.')
    parser.add_argument('--out-dir', required=True, help='Output directory for CSV/JSON files.')
    parser.add_argument('--read-bytes', type=int, default=262144, help='Header bytes to read from each candidate file.')
    parser.add_argument('--progress-every', type=int, default=5000, help='Print progress every N files; 0 disables.')
    parser.add_argument('--max-files', type=int, default=0, help='Debug limit on candidate files; 0 means all.')
    return parser

def main(argv: Optional[List[str]]=None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    inventory(args)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
