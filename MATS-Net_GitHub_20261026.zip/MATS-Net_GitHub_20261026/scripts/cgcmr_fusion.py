import torch
import torch.nn as nn

class CGCMRFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, num_modalities=4, rect_hidden_ratio=0.25):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 1, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.num_modalities = num_modalities
        hidden_dim = max(32, int(self.feat_dim * rect_hidden_ratio))
        n_pairs = num_modalities * (num_modalities - 1)
        self.rect_mlps = nn.ModuleList([nn.Sequential(nn.Linear(2 * self.feat_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, self.feat_dim)) for _ in range(n_pairs)])
        self.conf_gates = nn.ModuleList([nn.Sequential(nn.Linear(2 * self.feat_dim, hidden_dim), nn.GELU(), nn.Linear(hidden_dim, 1), nn.Sigmoid()) for _ in range(n_pairs)])
        self.mod_weights = nn.Parameter(torch.ones(num_modalities) / num_modalities)
        self.classifier = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))

    def forward(self, x):
        feats = [self.encoder.forward_features(xi) for xi in x]
        rectified = list(feats)
        pair_idx = 0
        for i in range(self.num_modalities):
            for j in range(self.num_modalities):
                if i == j:
                    continue
                pair_feat = torch.cat([feats[i], feats[j]], dim=-1)
                confidence = self.conf_gates[pair_idx](pair_feat)
                rect_signal = self.rect_mlps[pair_idx](pair_feat)
                rectified[i] = rectified[i] + confidence * rect_signal
                pair_idx += 1
        w = torch.softmax(self.mod_weights, dim=0)
        fused = sum((w[i] * rectified[i] for i in range(self.num_modalities)))
        return self.classifier(fused)
