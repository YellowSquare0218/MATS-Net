from __future__ import annotations
from _paths import project_path as _project_path
import argparse
import hashlib
import json
import random
import time
from pathlib import Path
import joblib
import numpy as np
import pandas as pd
import torch
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import log_loss, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader
import train as core
import fully_nested_patient_fusion as training
import fast_evidence_fusion as geometry
import evaluate_heterogeneous_evidence_fusion_262 as fusion
EXPERTS = fusion.DEFAULT_EXPERTS
DEEP = [name for name in EXPERTS if name != 'geo_lr_c0_3']

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, default=str).encode()).hexdigest()

def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + '.tmp')
    temp.write_text(json.dumps(value, indent=2, default=str), encoding='utf-8')
    temp.replace(path)

def seed_all(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)

def group_splits(frame, indices, n, seed):
    selected = frame.iloc[indices]
    splitter = StratifiedGroupKFold(n, shuffle=True, random_state=seed)
    for it, iv in splitter.split(selected, selected.label, selected.base_id):
        train_index, eval_index = (indices[it], indices[iv])
        assert not set(frame.iloc[train_index].base_id) & set(frame.iloc[eval_index].base_id)
        assert frame.iloc[train_index].label.nunique() == frame.iloc[eval_index].label.nunique() == 2
        yield (train_index, eval_index)

def load_inputs(args):
    source = args.project / 'training_results/grouped_deep_recompute_aug262'
    configs, summaries = ({}, {})
    for expert in DEEP:
        configs[expert] = json.loads((source / expert / 'config.json').read_text())
        summaries[expert] = json.loads((source / expert / 'cv_summary.json').read_text())
        assert configs[expert]['task'] == 2
        assert configs[expert]['model_name'] == 'convnext3d_tiny'
        assert configs[expert]['split_strategy'] == 'group'
        assert not configs[expert].get('teacher_oof') and (not configs[expert].get('tta'))
    first = configs[DEEP[0]]
    index_path = Path(first['index_csv'])
    clinical_path = Path(first['clinical_csv'])
    assert all((c['index_csv'] == str(index_path) and c['clinical_csv'] == str(clinical_path) for c in configs.values()))
    base = pd.read_csv(index_path, dtype={'id': str, 'base_id': str})
    base['id'] = base.id.map(core.normalize_id)
    assert len(base) == 262 and base.id.is_unique and (set(base.label) == {0, 1})
    if 'base_id' not in base:
        base['base_id'] = base.id.map(core.base_patient_id)
    else:
        base['base_id'] = base.base_id.map(core.normalize_id)
    assert (base.base_id == base.id.map(core.base_patient_id)).all()
    assert base.groupby('base_id').label.nunique().max() == 1
    evidence_path = source / 'fast_evidence_fusion_grouped/aligned_predictions.csv'
    evidence = pd.read_csv(evidence_path, dtype={'pid': str}).set_index('pid')
    assert set(evidence.index) == set(base.id)
    assert np.array_equal(evidence.loc[base.id, 'label'].to_numpy(), base.label.to_numpy())
    core.ROI_DIR = str(args.project / 'dataset/roi_v4')
    for sample_id in base.id:
        for modal in core.MODALITIES:
            path = Path(core.ROI_DIR) / sample_id / (modal + '.nii.gz')
            if not path.exists():
                raise FileNotFoundError(path)
    prepared, transformed = ({}, {})
    for expert, saved in configs.items():
        config = dict(saved)
        config['modalities'] = core.MODALITIES if saved['modal'] == 'all' else [saved['modal']]
        config['warmup'] = saved.get('causal_warmup_epochs', 0)
        historical_cols = summaries[expert].get('tabular_cols', [])
        old_cols = core.CLINICAL_FEATURE_COLS
        core.CLINICAL_FEATURE_COLS = [col.removeprefix('clin_') for col in historical_cols if col.startswith('clin_')]
        try:
            prepared[expert] = training.prepare_expert_frame(base, config, clinical_path)
        finally:
            core.CLINICAL_FEATURE_COLS = old_cols
        assert prepared[expert][1] == historical_cols, (expert, prepared[expert][1], historical_cols)
        transformed[expert] = config
    roi_geo = geometry.load_geometry(str(index_path), str(args.project / 'dataset/patient_index.csv'))
    assert roi_geo.pid.is_unique
    roi_geo = roi_geo.set_index('pid').loc[base.id].reset_index()
    geo_cols = [col for col in roi_geo if col.startswith('geo_')]
    x_geo = roi_geo[geo_cols].replace([np.inf, -np.inf], np.nan)
    assert len(x_geo) == 262
    code_files = sorted(Path(__file__).parent.glob('*.py'))
    spec = {'n_records': len(base), 'n_positive': int(base.label.sum()), 'experts': EXPERTS, 'configs': configs, 'tabular_columns': {e: prepared[e][1] for e in DEEP}, 'outer_folds': 5, 'inner_folds': 4, 'stopping_folds': 5, 'seed': args.seed, 'max_epochs': args.max_epochs, 'patience': args.patience, 'batch_size': core.BATCH_SIZE, 'learning_rate': core.LR, 'weight_decay': core.WEIGHT_DECAY, 'num_workers': args.workers, 'scheduler': 'cosine T_max=max_epochs in selection and refits', 'evaluation_unit': 'all 262 records; existing group assignment kept within every split', 'epoch_selection': 'separate stopping split inside inner-training only', 'outer_refit_epochs': 'rounded median of four training-only inner stopping epochs', 'reuse_historical_weights_or_predictions': False, 'architecture_selection': 'historically fixed eight-expert panel; not a nested architecture search', 'data_hashes': {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in [index_path, clinical_path, args.project / 'dataset/patient_index.csv', evidence_path]}, 'source_hashes': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in code_files}, 'versions': {'torch': torch.__version__, 'numpy': np.__version__, 'pandas': pd.__version__}}
    spec_path = args.output / 'protocol.json'
    if spec_path.exists():
        assert json.loads(spec_path.read_text()) == spec, 'Protocol changed; use a new output directory'
    else:
        write_json(spec_path, spec)
    return (base, transformed, prepared, x_geo, digest(spec))

def fit_deep(args, expert, config, prepared, train_idx, eval_idx, folder, seed, protocol_hash, epochs=None, smoke=False, model_factory=None):
    frame, columns, aux_col, fusion_kwargs = prepared
    selecting = epochs is None
    budget = args.max_epochs if selecting else epochs
    manifest = {'protocol_hash': protocol_hash, 'expert': expert, 'seed': seed, 'train_ids': frame.iloc[train_idx].id.tolist(), 'evaluation_ids': frame.iloc[eval_idx].id.tolist(), 'purpose': 'epoch_selection' if selecting else 'fixed_epoch_prediction', 'epochs': budget}
    assert not set(frame.iloc[train_idx].base_id) & set(frame.iloc[eval_idx].base_id)
    folder.mkdir(parents=True, exist_ok=True)
    manifest_path = folder / 'fit_manifest.json'
    if manifest_path.exists():
        assert json.loads(manifest_path.read_text()) == manifest, 'Cached fit has different provenance'
    else:
        write_json(manifest_path, manifest)
    result_path = folder / 'complete.json'
    if result_path.exists():
        result = json.loads(result_path.read_text())
        pred = None if selecting else pd.read_csv(folder / 'predictions.csv', dtype={'pid': str})
        return (result, pred)
    seed_all(seed)
    train_df, eval_df = (frame.iloc[train_idx].copy(), frame.iloc[eval_idx].copy())
    tabular_col = None
    if columns:
        preprocess = make_pipeline(SimpleImputer(strategy='median', keep_empty_features=True), StandardScaler())
        train_tab = preprocess.fit_transform(train_df[columns]).astype(np.float32)
        eval_tab = preprocess.transform(eval_df[columns]).astype(np.float32)
        assert train_tab.shape[1] == len(columns) and np.isfinite(train_tab).all() and np.isfinite(eval_tab).all()
        tabular_col = 'tabular_features'
        train_df[tabular_col], eval_df[tabular_col] = (list(train_tab), list(eval_tab))
        joblib.dump(preprocess, folder / 'preprocessing.joblib')
    train_loader, eval_loader = training.make_loaders(train_df, eval_df, config, tabular_col, aux_col, args.workers)
    if smoke:
        batch = next(iter(train_loader))
        sample_audit = [{'shape': list(v.shape), 'dtype': str(v.dtype), 'min': float(v.min()), 'max': float(v.max())} for v in batch['volumes']]
        assert all((torch.isfinite(v).all() for v in batch['volumes']))
        train_loader = [batch]
    factory = training.build_model if model_factory is None else model_factory
    model, is_fusion = factory(config, fusion_kwargs, torch.device('cuda'))
    criterion = torch.nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=core.LR, weight_decay=core.WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.max_epochs)
    checkpoint_path = folder / 'resume.pt'
    start, best_epoch, best_score, stale = (1, 0, None, 0)
    state = None
    stopped = False
    if checkpoint_path.exists():
        ckpt = torch.load(checkpoint_path, map_location='cpu', weights_only=False)
        assert ckpt['manifest_hash'] == digest(manifest)
        model.load_state_dict(ckpt['model'], strict=True)
        optimizer.load_state_dict(ckpt['optimizer'])
        scheduler.load_state_dict(ckpt['scheduler'])
        start, best_epoch, best_score, stale = (ckpt['epoch'] + 1, ckpt['best_epoch'], ckpt['best_score'], ckpt['stale'])
        random.setstate(ckpt['python_rng'])
        np.random.set_state(ckpt['numpy_rng'])
        torch.set_rng_state(ckpt['torch_rng'])
        torch.cuda.set_rng_state_all(ckpt['cuda_rng'])
        stopped = selecting and stale >= args.patience
        del ckpt
    started = time.time()
    for epoch in [] if stopped else range(start, budget + 1):
        loss, accuracy = core.train_epoch(model, train_loader, optimizer, criterion, torch.device('cuda'), fusion=is_fusion, causal_enabled=smoke or epoch > int(config.get('warmup') or 0), distill_weight=float(config.get('distill_weight') or 0), distill_temperature=float(config.get('distill_temperature') or 2))
        if not np.isfinite(loss):
            raise FloatingPointError(f'Nonfinite loss in {folder}')
        if smoke:
            assert any((p.grad is not None and torch.isfinite(p.grad).all() and (p.grad.abs().sum() > 0) for p in model.parameters()))
        val_score = None
        if selecting:
            evaluation = core.validate(model, eval_loader, criterion, torch.device('cuda'), 2, fusion=is_fusion)
            val_score = float(evaluation[config.get('select_metric', 'auc')])
            if not np.isfinite(val_score):
                raise FloatingPointError('Stopping score is nonfinite')
            if best_score is None or val_score > best_score:
                best_score, best_epoch, stale = (val_score, epoch, 0)
            else:
                stale += 1
        scheduler.step()
        with (folder / 'epochs.jsonl').open('a', encoding='utf-8') as handle:
            handle.write(json.dumps({'epoch': epoch, 'loss': float(loss), 'accuracy': float(accuracy), 'stopping_score': val_score}) + '\n')
        state = {'manifest_hash': digest(manifest), 'model': model.state_dict(), 'optimizer': optimizer.state_dict(), 'scheduler': scheduler.state_dict(), 'epoch': epoch, 'best_epoch': best_epoch, 'best_score': best_score, 'stale': stale, 'python_rng': random.getstate(), 'numpy_rng': np.random.get_state(), 'torch_rng': torch.get_rng_state(), 'cuda_rng': torch.cuda.get_rng_state_all()}
        temp = checkpoint_path.with_suffix('.tmp')
        torch.save(state, temp)
        temp.replace(checkpoint_path)
        print(f'{folder.relative_to(args.output)} epoch={epoch}/{budget} loss={loss:.4f} stop_score={val_score}', flush=True)
        if selecting and stale >= args.patience:
            break
    predictions = None
    if not selecting:
        evaluation = core.validate(model, eval_loader, criterion, torch.device('cuda'), 2, fusion=is_fusion)
        predictions = pd.DataFrame(evaluation['predictions'])
        predictions['pid'] = predictions.pid.map(core.normalize_id)
        assert set(predictions.pid) == set(eval_df.id) and predictions.pid.is_unique
        assert np.isfinite(predictions.prob_pos).all()
        predictions.to_csv(folder / 'predictions.csv', index=False)
        torch.save(model.state_dict(), folder / 'model.pt')
    result = {'best_epoch': best_epoch, 'best_score': best_score, 'epochs': epoch if start <= budget and (not stopped) else start - 1, 'elapsed_seconds_this_session': time.time() - started}
    if smoke:
        result['sample_audit'] = sample_audit
        result['active_auxiliary_backward_checked'] = True
    write_json(result_path, result)
    checkpoint_path.unlink(missing_ok=True)
    del model, optimizer, scheduler, state
    torch.cuda.empty_cache()
    return (result, predictions)

def fit_roi(base, x, train_idx, eval_idx, folder, protocol_hash):
    folder.mkdir(parents=True, exist_ok=True)
    assert not set(base.iloc[train_idx].base_id) & set(base.iloc[eval_idx].base_id)
    manifest = {'protocol_hash': protocol_hash, 'train_ids': base.iloc[train_idx].id.tolist(), 'evaluation_ids': base.iloc[eval_idx].id.tolist(), 'C': 0.3}
    write_json(folder / 'fit_manifest.json', manifest)
    cols = x.iloc[train_idx].notna().any(axis=0)
    estimator = make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), LogisticRegression(C=0.3, max_iter=500, solver='liblinear', class_weight='balanced', random_state=42))
    estimator.fit(x.loc[:, cols].iloc[train_idx], base.iloc[train_idx].label)
    score = estimator.predict_proba(x.loc[:, cols].iloc[eval_idx])[:, 1]
    joblib.dump({'columns': x.columns[cols].tolist(), 'estimator': estimator}, folder / 'model.joblib')
    predictions = base.iloc[eval_idx][['id', 'label']].rename(columns={'id': 'pid'}).copy()
    predictions['prob_pos'] = score
    predictions.to_csv(folder / 'predictions.csv', index=False)
    return predictions

def fit_fusion(train_frame, test_frame, folder, seed):
    y = train_frame.label.to_numpy(dtype=int)
    a, b = (train_frame[EXPERTS].to_numpy(float), test_frame[EXPERTS].to_numpy(float))
    assert np.isfinite(a).all() and np.isfinite(b).all()
    out = test_frame[['id', 'label', 'outer_fold']].copy()
    aucs = np.array([roc_auc_score(y, a[:, j]) for j in range(8)])
    best = int(aucs.argmax())
    out['best_single'] = b[:, best]
    am, bm = (a.mean(axis=1), b.mean(axis=1))
    out['unweighted_mean'] = bm
    platt = LogisticRegression(C=1000000.0, max_iter=3000).fit(fusion.logit(am)[:, None], y)
    out['platt_mean'] = platt.predict_proba(fusion.logit(bm)[:, None])[:, 1]

    def beta_features(p):
        return np.column_stack([np.log(np.clip(p, 1e-06, 1)), -np.log(np.clip(1 - p, 1e-06, 1))])
    beta = LogisticRegression(C=1000000.0, max_iter=3000).fit(beta_features(am), y)
    out['beta_mean'] = beta.predict_proba(beta_features(bm))[:, 1]
    weights = np.maximum(aucs - 0.5, 0.005) ** 2
    weights /= weights.sum()
    out['auc_weighted_mean'] = b @ weights
    simplex, simplex_info = fusion.fit_simplex(y, a)
    out['simplex_logloss'] = b @ simplex
    subset, ranking = fusion.select_subset(y, a)
    out['selected_subset_mean'] = b[:, subset].mean(axis=1)
    split = list(group_splits(train_frame, np.arange(len(y)), 4, seed))
    tuning = []
    for c in [0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0]:
        losses = []
        for it, iv in split:
            model = make_pipeline(StandardScaler(), LogisticRegression(C=c, max_iter=3000))
            model.fit(fusion.logit(a[it]), y[it])
            losses.append(log_loss(y[iv], model.predict_proba(fusion.logit(a[iv]))[:, 1], labels=[0, 1]))
        tuning.append({'method': 'logistic_stacking', 'C': c, 'loss': float(np.mean(losses))})
    best_c = min(tuning, key=lambda row: (row['loss'], row['C']))['C']
    logistic = make_pipeline(StandardScaler(), LogisticRegression(C=best_c, max_iter=3000))
    logistic.fit(fusion.logit(a), y)
    out['logistic_stacking'] = logistic.predict_proba(fusion.logit(b))[:, 1]
    rdef_tuning = []
    for lam in [0.0, 0.01, 0.03, 0.1, 0.3]:
        for gamma in [0.0, 0.01, 0.03, 0.1]:
            losses = []
            for it, iv in split:
                w, _ = fusion.fit_simplex(y[it], a[it], lam, gamma)
                losses.append(log_loss(y[iv], a[iv] @ w, labels=[0, 1]))
            rdef_tuning.append({'method': 'rdef', 'lambda': lam, 'gamma': gamma, 'loss': float(np.mean(losses))})
    chosen = min(rdef_tuning, key=lambda row: (row['loss'], row['lambda'], row['gamma']))
    rw, rinfo = fusion.fit_simplex(y, a, chosen['lambda'], chosen['gamma'])
    out['rdef'] = b @ rw
    folder.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(tuning + rdef_tuning).to_csv(folder / 'fusion_tuning.csv', index=False)
    ranking.to_csv(folder / 'subset_ranking_inner_only.csv', index=False)
    joblib.dump({'platt': platt, 'beta': beta, 'logistic': logistic}, folder / 'fitted_calibration_and_stacking.joblib')
    write_json(folder / 'fusion_fit.json', {'train_ids': train_frame.id.tolist(), 'test_ids': test_frame.id.tolist(), 'best_expert': EXPERTS[best], 'auc_weights': weights.tolist(), 'simplex_weights': simplex.tolist(), 'simplex_audit': simplex_info, 'subset': [EXPERTS[j] for j in subset], 'logistic_C': best_c, 'rdef_weights': rw.tolist(), 'rdef_audit': rinfo})
    assert np.isfinite(out[fusion.METHODS].to_numpy()).all()
    return out

def aggregate(args, base):
    paths = [args.output / f'outer_{i}/outer_fusion_predictions.csv' for i in range(1, 6)]
    if not all((path.exists() for path in paths)):
        print('Incomplete outer folds; final results not produced', flush=True)
        return False
    frame = pd.concat([pd.read_csv(p, dtype={'id': str}) for p in paths], ignore_index=True)
    assert len(frame) == 262 and frame.id.is_unique and (set(frame.id) == set(base.id))
    frame = frame.set_index('id').loc[base.id].reset_index()
    assert np.array_equal(frame.label, base.label)
    y = frame.label.to_numpy(int)
    rng = np.random.default_rng(args.seed)
    groups = base.base_id.to_numpy()
    unique = np.unique(groups)
    blocks = [np.flatnonzero(groups == g) for g in unique]
    draws = []
    while len(draws) < args.n_boot:
        indices = np.concatenate([blocks[i] for i in rng.integers(0, len(blocks), len(blocks))])
        if len(np.unique(y[indices])) == 2:
            draws.append(indices)
    rows, fold_rows = ([], [])
    for method in fusion.METHODS:
        score = frame[method].to_numpy(float)
        row = {'method': method, 'evaluation': 'outer-held-out full base/fusion nesting; 262 records', **fusion.metrics(y, score)}
        fusion.add_bootstrap_ci(row, y, score, draws)
        fold_aucs = []
        for fold, part in frame.groupby('outer_fold'):
            measured = fusion.metrics(part.label.to_numpy(int), part[method].to_numpy(float))
            fold_rows.append({'outer_fold': int(fold), 'method': method, **measured})
            fold_aucs.append(measured['auc'])
        row['fold_mean_auc'], row['fold_sd_auc'] = (float(np.mean(fold_aucs)), float(np.std(fold_aucs, ddof=1)))
        rows.append(row)
    frame.to_csv(args.output / 'fully_nested_fusion_predictions_262.csv', index=False)
    pd.DataFrame(rows).to_csv(args.output / 'fully_nested_fusion_metrics_262.csv', index=False)
    pd.DataFrame(fold_rows).to_csv(args.output / 'fully_nested_fold_metrics_262.csv', index=False)
    contrasts = fusion.paired_auc_contrasts(y, frame, 'unweighted_mean', [m for m in fusion.METHODS if m != 'unweighted_mean'], draws)
    contrasts.to_csv(args.output / 'paired_auc_contrasts_holm.csv', index=False)
    write_json(args.output / 'complete.json', {'n': 262, 'status': 'all_five_outer_folds_complete', 'CI': 'group bootstrap of fixed outer-held-out predictions; conditional on this training/split realization', 'paired_p': 'bootstrap sign-tail approximation with Holm adjustment'})
    return True

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--project', type=Path, default=Path(_project_path('')))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=['preflight', 'smoke', 'run', 'aggregate'], default='preflight')
    parser.add_argument('--outer-folds', default='1,2,3,4,5')
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--max-epochs', type=int, default=80)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--n-boot', type=int, default=5000)
    args = parser.parse_args()
    torch.set_num_threads(8)
    if not torch.cuda.is_available():
        raise RuntimeError('Cell CUDA is required for this experiment')
    base, configs, prepared, x_geo, protocol_hash = load_inputs(args)
    outer = list(group_splits(base, np.arange(len(base)), 5, args.seed))
    manifest = []
    for number, (ot, ov) in enumerate(outer, 1):
        inner = list(group_splits(base, ot, 4, training.stable_seed(args.seed, number, 'inner')))
        for inner_number, (it, iv) in enumerate(inner, 1):
            st, sv = next(group_splits(base, it, 5, training.stable_seed(args.seed, number, inner_number, 'stop')))
            assert not set(base.iloc[ov].base_id) & set(base.iloc[np.concatenate([st, sv, iv])].base_id)
            manifest.append({'outer_fold': number, 'inner_fold': inner_number, 'outer_train_ids': base.iloc[ot].id.tolist(), 'outer_test_ids': base.iloc[ov].id.tolist(), 'inner_train_ids': base.iloc[it].id.tolist(), 'inner_validation_ids': base.iloc[iv].id.tolist(), 'stopping_train_ids': base.iloc[st].id.tolist(), 'stopping_validation_ids': base.iloc[sv].id.tolist()})
    write_json(args.output / 'split_manifest.json', manifest)
    print(f'n=262, experts=8, outer=5, inner=4; device={torch.cuda.get_device_name(0)}', flush=True)
    if args.mode == 'preflight':
        write_json(args.output / 'preflight_passed.json', {'status': 'passed', 'n': 262, 'volume_paths_checked': 1048, 'split_blocks_checked': len(manifest), 'protocol_hash': protocol_hash, 'gpu': torch.cuda.get_device_name(0)})
        return
    if args.mode == 'aggregate':
        aggregate(args, base)
        return
    if args.mode == 'smoke':
        it, iv = next(group_splits(base, outer[0][0], 4, training.stable_seed(args.seed, 1, 'inner')))
        results = {}
        for expert in DEEP:
            result, _ = fit_deep(args, expert, configs[expert], prepared[expert], it, iv, args.output / 'smoke' / expert, 1234, protocol_hash, epochs=1, smoke=True)
            results[expert] = result
        fit_roi(base, x_geo, it, iv, args.output / 'smoke/roi', protocol_hash)
        rng = np.random.default_rng(567)
        toy_train = base.iloc[it][['id', 'base_id', 'label']].copy()
        toy_test = base.iloc[iv][['id', 'base_id', 'label']].copy()
        toy_test['outer_fold'] = 1
        for expert in EXPERTS:
            toy_train[expert] = rng.uniform(0.1, 0.9, len(toy_train))
            toy_test[expert] = rng.uniform(0.1, 0.9, len(toy_test))
        original = fit_fusion(toy_train, toy_test, args.output / 'smoke/SYNTHETIC_LABEL_CONTROL/original', 89)
        toy_test['label'] = 1 - toy_test.label
        flipped = fit_fusion(toy_train, toy_test, args.output / 'smoke/SYNTHETIC_LABEL_CONTROL/flipped', 89)
        assert np.allclose(original[fusion.METHODS], flipped[fusion.METHODS], atol=1e-12, rtol=0)
        results['synthetic_outer_label_invariance'] = 'passed; not an experimental performance result'
        write_json(args.output / 'smoke_passed.json', results)
        return
    import fcntl
    lock_handle = (args.output / 'run.lock').open('w')
    fcntl.flock(lock_handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
    selected_outer = {int(i) for i in args.outer_folds.split(',')}
    for number, (ot, ov) in enumerate(outer, 1):
        if number not in selected_outer:
            continue
        folder = args.output / f'outer_{number}'
        if (folder / 'outer_fusion_predictions.csv').exists():
            continue
        inner_frames, selected_epochs = ([], {expert: [] for expert in DEEP})
        for inner_number, (it, iv) in enumerate(group_splits(base, ot, 4, training.stable_seed(args.seed, number, 'inner')), 1):
            st, sv = next(group_splits(base, it, 5, training.stable_seed(args.seed, number, inner_number, 'stop')))
            inner_frame = base.iloc[iv][['id', 'base_id', 'label']].copy()
            for expert in DEEP:
                expert_dir = folder / f'inner_{inner_number}' / expert
                stop, _ = fit_deep(args, expert, configs[expert], prepared[expert], st, sv, expert_dir / 'stopping', training.stable_seed(args.seed, number, inner_number, expert, 'stop'), protocol_hash)
                epoch = stop['best_epoch']
                selected_epochs[expert].append(epoch)
                _, prediction = fit_deep(args, expert, configs[expert], prepared[expert], it, iv, expert_dir / 'refit', training.stable_seed(args.seed, number, inner_number, expert, 'refit'), protocol_hash, epochs=epoch)
                inner_frame[expert] = inner_frame.id.map(prediction.set_index('pid').prob_pos)
            prediction = fit_roi(base, x_geo, it, iv, folder / f'inner_{inner_number}/geo_lr_c0_3', protocol_hash)
            inner_frame['geo_lr_c0_3'] = inner_frame.id.map(prediction.set_index('pid').prob_pos)
            inner_frame['inner_fold'] = inner_number
            inner_frames.append(inner_frame)
        inner_frame = pd.concat(inner_frames, ignore_index=True)
        assert inner_frame.id.is_unique and set(inner_frame.id) == set(base.iloc[ot].id)
        inner_frame.to_csv(folder / 'inner_oof_evidence.csv', index=False)
        test_frame = base.iloc[ov][['id', 'base_id', 'label']].copy()
        test_frame['outer_fold'] = number
        epochs = {e: max(1, int(round(np.median(values)))) for e, values in selected_epochs.items()}
        write_json(folder / 'epoch_selection.json', {'inner_stopping_epochs': selected_epochs, 'outer_refit_epochs': epochs})
        for expert in DEEP:
            _, prediction = fit_deep(args, expert, configs[expert], prepared[expert], ot, ov, folder / 'outer_refit' / expert, training.stable_seed(args.seed, number, expert, 'outer'), protocol_hash, epochs=epochs[expert])
            test_frame[expert] = test_frame.id.map(prediction.set_index('pid').prob_pos)
        prediction = fit_roi(base, x_geo, ot, ov, folder / 'outer_refit/geo_lr_c0_3', protocol_hash)
        test_frame['geo_lr_c0_3'] = test_frame.id.map(prediction.set_index('pid').prob_pos)
        test_frame.to_csv(folder / 'outer_test_evidence.csv', index=False)
        results = fit_fusion(inner_frame, test_frame, folder / 'fusion', training.stable_seed(args.seed, number, 'fusion'))
        results.to_csv(folder / 'outer_fusion_predictions.csv', index=False)
        print(f'OUTER {number} COMPLETE', flush=True)
    aggregate(args, base)
if __name__ == '__main__':
    main()
