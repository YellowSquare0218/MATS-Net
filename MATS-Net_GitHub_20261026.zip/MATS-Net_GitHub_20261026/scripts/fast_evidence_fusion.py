import argparse
import itertools
import os
import re
import warnings
from collections import OrderedDict
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
try:
    from sklearn.model_selection import StratifiedGroupKFold
except ImportError:
    StratifiedGroupKFold = None
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_INDEX = os.path.join(PROJECT_ROOT, 'dataset', 'roi_v4', 'index.csv')
DEFAULT_PATIENT_INDEX = os.path.join(PROJECT_ROOT, 'dataset', 'patient_index.csv')
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']
DEFAULT_MODELS = OrderedDict([('mara', 'training_results/convnext_tiny_all_2cls_mara_aucselect'), ('early', 'training_results/convnext_tiny_all_2cls_early_aucselect'), ('cif', 'training_results/convnext_tiny_all_2cls_causal_invariant'), ('cmara', 'training_results/convnext_tiny_all_2cls_causal_mara'), ('cmara_light', 'training_results/convnext_tiny_all_2cls_causal_mara_light'), ('gmara_auc', 'training_results/convnext_tiny_all_2cls_geometry_mara_auc'), ('gmara_acc', 'training_results/convnext_tiny_all_2cls_geometry_mara_acc'), ('gmara_clingeo', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_acc'), ('gmara_clingeo_node_mtl', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_mtl_acc'), ('gmara_clingeo_node_burden_mtl', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_mtl_acc'), ('gmara_clingeo_node_burden_auc', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_mtl_auc'), ('gmara_burden_w004', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_w004_acc'), ('gmara_burden_w006', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_w006_acc'), ('gmara_burden_w010', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_w010_acc'), ('gmara_burden_w012', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_w012_acc'), ('gmara_src279n_bin_w008', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_src279n_bin_w008_acc'), ('gmara_gm_w008', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_gM_w008_acc'), ('gmara_gq_w008', 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_gQ_w008_acc'), ('tripath_acc', 'training_results/convnext_tiny_all_2cls_tripath_mara_acc'), ('cqof_acc', 'training_results/convnext_tiny_all_2cls_causal_quality_acc'), ('omara_acc', 'training_results/convnext_tiny_all_2cls_ordinal_mara_acc'), ('gmara_distill_w015', 'training_results/convnext_tiny_all_2cls_gmara_distill_w015_acc'), ('gmara_distill_w030', 'training_results/convnext_tiny_all_2cls_gmara_distill_w030_acc')])

def normalize_id(value):
    return re.sub('\\.0$', '', str(value)).strip()

def base_patient_id(value):
    return re.sub('_2$', '', normalize_id(value))

def parse_name_path(value):
    if '=' not in value:
        raise argparse.ArgumentTypeError('Expected name=path')
    name, path = value.split('=', 1)
    name = name.strip()
    path = path.strip()
    if not name or not path:
        raise argparse.ArgumentTypeError('Empty model name or path')
    return (name, path)

def resolve_path(path):
    if os.path.isabs(path):
        return path
    return os.path.join(PROJECT_ROOT, path)

def load_predictions(name, model_dir):
    path = os.path.join(resolve_path(model_dir), 'all_predictions.csv')
    if not os.path.exists(path):
        return None
    df = pd.read_csv(path)
    score_col = None
    for col in ['prob_pos', 'prob_1', 'score']:
        if col in df.columns:
            score_col = col
            break
    if score_col is None:
        raise ValueError(f'{path} must contain one of prob_pos/prob_1/score')
    out = df[['pid', 'label', score_col]].copy()
    out['pid'] = out['pid'].map(normalize_id)
    out['label'] = out['label'].astype(int)
    out = out.rename(columns={score_col: name})
    return out

def parse_range(value):
    if pd.isna(value):
        return (np.nan, np.nan, np.nan, np.nan)
    match = re.match('(-?\\d+)_(-?\\d+)$', str(value))
    if match:
        start, end = map(float, match.groups())
        length = end - start + 1.0
        center = (start + end) / 2.0
        return (start, end, length, center)
    try:
        value = float(value)
        return (value, value, 0.0, value)
    except (TypeError, ValueError):
        return (np.nan, np.nan, np.nan, np.nan)

def load_geometry(index_path, patient_index_path):
    index = pd.read_csv(index_path)
    index['id'] = index['id'].map(normalize_id)
    index['_base_id'] = index['id'].map(base_patient_id)
    if 'label' not in index.columns:
        index['label'] = (index['state'].astype(int) == 3).astype(int)
    meta = pd.read_csv(patient_index_path)
    meta['id'] = meta['id'].map(normalize_id)
    meta['_base_id'] = meta['id'].map(base_patient_id)
    meta = meta.drop_duplicates(['_base_id', 'state'])
    df = index.merge(meta.drop(columns=['id']), on=['_base_id', 'state'], how='left')
    features = {'pid': df['id'].astype(str), 'label': df['label'].astype(int)}
    for mod in MODALITIES:
        features[f'geo_{mod}_max'] = pd.to_numeric(df.get(f'{mod}_max'), errors='coerce')
        for axis in ['x', 'y', 'z']:
            parsed = [parse_range(v) for v in df.get(f'{mod}_{axis}')]
            features[f'geo_{mod}_{axis}_start'] = [v[0] for v in parsed]
            features[f'geo_{mod}_{axis}_end'] = [v[1] for v in parsed]
            features[f'geo_{mod}_{axis}_len'] = [v[2] for v in parsed]
            features[f'geo_{mod}_{axis}_center'] = [v[3] for v in parsed]
        features[f'geo_{mod}_xy_area'] = np.asarray(features[f'geo_{mod}_x_len']) * np.asarray(features[f'geo_{mod}_y_len'])
        features[f'geo_{mod}_vol_approx'] = np.asarray(features[f'geo_{mod}_xy_area']) * np.asarray(features[f'geo_{mod}_z_len'])
        features[f'geo_{mod}_aspect_xy'] = np.asarray(features[f'geo_{mod}_x_len']) / np.clip(np.asarray(features[f'geo_{mod}_y_len']), 1e-06, None)
    for key in ['max', 'x_len', 'y_len', 'z_len', 'xy_area', 'vol_approx']:
        cols = [f'geo_{mod}_{key}' for mod in MODALITIES if f'geo_{mod}_{key}' in features]
        if not cols:
            continue
        arr = np.vstack([np.asarray(features[col], dtype=float) for col in cols]).T
        if np.all(np.isnan(arr)):
            features[f'geo_cross_{key}_mean'] = np.full(arr.shape[0], np.nan)
            features[f'geo_cross_{key}_std'] = np.full(arr.shape[0], np.nan)
            features[f'geo_cross_{key}_range'] = np.full(arr.shape[0], np.nan)
        else:
            features[f'geo_cross_{key}_mean'] = np.nanmean(arr, axis=1)
            features[f'geo_cross_{key}_std'] = np.nanstd(arr, axis=1)
            features[f'geo_cross_{key}_range'] = np.nanmax(arr, axis=1) - np.nanmin(arr, axis=1)
    return pd.DataFrame(features)

def make_aligned_frame(model_items):
    base = None
    used = []
    for name, model_dir in model_items:
        df = load_predictions(name, model_dir)
        if df is None:
            continue
        used.append(name)
        base = df if base is None else base.merge(df, on=['pid', 'label'], how='inner')
    if base is None or not used:
        raise RuntimeError('No prediction files were found.')
    return (base.sort_values('pid').reset_index(drop=True), used)

def make_splits(frame, y, seed, n_splits, split_strategy):
    if split_strategy == 'stratified':
        splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        return list(splitter.split(frame, y))
    if StratifiedGroupKFold is None:
        raise ImportError('StratifiedGroupKFold is unavailable; upgrade scikit-learn or use --split_strategy stratified.')
    groups = frame['pid'].map(base_patient_id).to_numpy()
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(splitter.split(frame, y, groups=groups))

def metric_row(name, y, score):
    y = np.asarray(y, dtype=int)
    score = np.asarray(score, dtype=float)
    pred = (score >= 0.5).astype(int)
    neg = y == 0
    pos = y == 1
    tn = int(np.sum((pred == 0) & neg))
    fp = int(np.sum((pred == 1) & neg))
    fn = int(np.sum((pred == 0) & pos))
    tp = int(np.sum((pred == 1) & pos))
    thresholds = np.linspace(0.05, 0.95, 91)
    pred_grid = score[:, None] >= thresholds[None, :]
    tp_grid = np.sum(pred_grid & pos[:, None], axis=0).astype(float)
    fp_grid = np.sum(pred_grid & neg[:, None], axis=0).astype(float)
    fn_grid = np.sum(~pred_grid & pos[:, None], axis=0).astype(float)
    tn_grid = np.sum(~pred_grid & neg[:, None], axis=0).astype(float)
    acc_grid = (tp_grid + tn_grid) / len(y)
    recall_grid = np.divide(tp_grid, tp_grid + fn_grid, out=np.zeros_like(tp_grid), where=tp_grid + fn_grid > 0)
    spec_grid = np.divide(tn_grid, tn_grid + fp_grid, out=np.zeros_like(tn_grid), where=tn_grid + fp_grid > 0)
    prec_grid = np.divide(tp_grid, tp_grid + fp_grid, out=np.zeros_like(tp_grid), where=tp_grid + fp_grid > 0)
    f1_grid = np.divide(2 * prec_grid * recall_grid, prec_grid + recall_grid, out=np.zeros_like(prec_grid), where=prec_grid + recall_grid > 0)
    bal_grid = (recall_grid + spec_grid) / 2.0
    best_idx = int(np.lexsort((bal_grid, f1_grid, acc_grid))[-1])
    out = {'candidate': name, 'auc': roc_auc_score(y, score), 'acc05': (tp + tn) / len(y), 'f1_05': 2 * tp / (2 * tp + fp + fn) if 2 * tp + fp + fn else 0.0, 'balanced_acc05': ((tp / (tp + fn) if tp + fn else 0.0) + (tn / (tn + fp) if tn + fp else 0.0)) / 2.0, 'precision05': tp / (tp + fp) if tp + fp else 0.0, 'recall05': tp / (tp + fn) if tp + fn else 0.0, 'specificity05': tn / (tn + fp) if tn + fp else 0.0, 'best_acc': float(acc_grid[best_idx]), 'best_f1': float(f1_grid[best_idx]), 'best_bal_acc': float(bal_grid[best_idx]), 'best_threshold': float(thresholds[best_idx]), 'best_recall': float(recall_grid[best_idx]), 'best_specificity': float(spec_grid[best_idx])}
    return out

def geometry_oof_scores(frame, index_path, patient_index_path, seed, n_splits, split_strategy):
    with warnings.catch_warnings():
        warnings.simplefilter('ignore', category=RuntimeWarning)
        geo = load_geometry(index_path, patient_index_path)
    df = frame[['pid', 'label']].merge(geo, on=['pid', 'label'], how='left')
    geo_cols = [c for c in df.columns if c.startswith('geo_')]
    x = df[geo_cols].replace([np.inf, -np.inf], np.nan)
    x = x.loc[:, x.notna().any(axis=0)]
    y = df['label'].to_numpy()
    splits = make_splits(df, y, seed, n_splits, split_strategy)
    scores = {}
    for c_value in [0.1, 0.3, 1.0]:
        name = f"geo_lr_c{str(c_value).replace('.', '_')}"
        pred = np.zeros(len(y), dtype=float)
        estimator = make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), LogisticRegression(C=c_value, max_iter=500, solver='liblinear', class_weight='balanced'))
        for train_idx, val_idx in splits:
            model = clone(estimator)
            model.fit(x.iloc[train_idx], y[train_idx])
            pred[val_idx] = model.predict_proba(x.iloc[val_idx])[:, 1]
        scores[name] = pred
    return scores

def score_column_name(prefix, candidate):
    text = re.sub('[^0-9A-Za-z]+', '_', str(candidate)).strip('_').lower()
    return f'{prefix}_{text[:80]}'

def add_candidate(rows, seen, name, y, score, score_store=None):
    if name in seen:
        return
    seen.add(name)
    score = np.asarray(score, dtype=float)
    rows.append(metric_row(name, y, score))
    if score_store is not None:
        score_store[name] = score

def search_weighted_candidates(frame, model_cols, geo_cols, score_store=None):
    y = frame['label'].to_numpy(dtype=int)
    rows = []
    seen = set()
    focus = [c for c in ['single_T2W', 'single_DWI', 'single_T1C', 'single_T1W', 'mara', 'early', 'cif', 'cmara', 'gmara_auc', 'gmara_acc', 'gmara_clingeo', 'gmara_clingeo_node_mtl', 'gmara_clingeo_node_burden_mtl', 'gmara_clingeo_node_burden_auc', 'gmara_burden_w004', 'gmara_burden_w006', 'gmara_burden_w010', 'gmara_burden_w012', 'gmara_src279n_bin_w008', 'gmara_gm_w008', 'gmara_gq_w008', 'gmara_geometry_only', 'gmara_clinical_only', 'gmara_clingeo_nocausal', 'tripath_acc', 'cqof_acc', 'omara_acc', 'gmara_distill_w015', 'gmara_distill_w030'] if c in model_cols]
    all_score_cols = focus + [c for c in geo_cols if c in frame.columns]
    for col in all_score_cols:
        add_candidate(rows, seen, col, y, frame[col].to_numpy(), score_store=score_store)
    for size in range(2, min(5, len(focus)) + 1):
        for combo in itertools.combinations(focus, size):
            score = frame[list(combo)].mean(axis=1).to_numpy()
            add_candidate(rows, seen, 'mean:' + '+'.join(combo), y, score, score_store=score_store)
    deep_bases = [['single_T2W', 'single_DWI', 'single_T1C', 'single_T1W'], ['single_DWI', 'single_T1C', 'mara'], ['mara', 'early', 'cif', 'cmara'], ['mara', 'early', 'cif', 'cmara', 'gmara_acc'], ['mara', 'early', 'cif', 'cmara', 'gmara_auc', 'gmara_acc'], ['mara', 'early', 'cif', 'cmara', 'gmara_clingeo'], ['mara', 'early', 'cif', 'gmara_acc', 'gmara_clingeo'], ['mara', 'early', 'cif', 'gmara_clingeo_node_mtl'], ['mara', 'early', 'cif', 'gmara_clingeo', 'gmara_clingeo_node_mtl'], ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl'], ['mara', 'early', 'cif', 'gmara_clingeo', 'gmara_clingeo_node_burden_mtl'], ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_auc'], ['mara', 'early', 'cif', 'gmara_clingeo', 'gmara_clingeo_node_burden_auc'], ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl', 'gmara_clingeo_node_burden_auc'], ['mara', 'early', 'cif', 'gmara_burden_w004'], ['mara', 'early', 'cif', 'gmara_burden_w006'], ['mara', 'early', 'cif', 'gmara_burden_w010'], ['mara', 'early', 'cif', 'gmara_burden_w012'], ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl', 'gmara_burden_w006'], ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl', 'gmara_burden_w010'], ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl', 'gmara_burden_w012'], ['mara', 'early', 'cif', 'gmara_src279n_bin_w008'], ['mara', 'early', 'cif', 'gmara_gm_w008'], ['mara', 'early', 'cif', 'gmara_gq_w008'], ['mara', 'early', 'cif', 'gmara_burden_w006', 'gmara_gm_w008', 'gmara_gq_w008'], ['mara', 'early', 'cif', 'gmara_geometry_only'], ['mara', 'early', 'cif', 'gmara_clinical_only'], ['mara', 'early', 'cif', 'gmara_clingeo_nocausal'], ['mara', 'early', 'cif', 'gmara_geometry_only', 'gmara_clinical_only'], ['mara', 'early', 'cif', 'gmara_clingeo_nocausal', 'gmara_clingeo'], ['mara', 'cif', 'cmara', 'gmara_auc', 'gmara_acc'], ['mara', 'early', 'cif', 'gmara_acc', 'tripath_acc'], ['mara', 'early', 'cif', 'gmara_distill_w030'], ['mara', 'early', 'cif', 'cmara', 'gmara_distill_w030'], ['mara', 'early', 'cif', 'gmara_acc', 'gmara_distill_w030'], ['gmara_acc', 'gmara_distill_w015', 'gmara_distill_w030', 'tripath_acc'], ['mara', 'early', 'cif', 'cmara', 'gmara_acc', 'cqof_acc', 'omara_acc']]
    for combo in deep_bases:
        present = [c for c in combo if c in frame.columns]
        if len(present) < 2:
            continue
        score = frame[present].mean(axis=1).to_numpy()
        add_candidate(rows, seen, 'mean_base:' + '+'.join(present), y, score, score_store=score_store)
        for geo_col in geo_cols:
            if geo_col not in frame.columns:
                continue
            for alpha in [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.4]:
                mixed = (1.0 - alpha) * score + alpha * frame[geo_col].to_numpy()
                name = f"geo_mix:{'+'.join(present)}|{geo_col}|a{alpha:.2f}"
                add_candidate(rows, seen, name, y, mixed, score_store=score_store)
    hand_weights = [{'single_T2W': 0.2, 'single_DWI': 0.3, 'single_T1C': 0.3, 'single_T1W': 0.2}, {'mara': 0.35, 'early': 0.2, 'cif': 0.2, 'cmara': 0.15, 'gmara_acc': 0.1}, {'mara': 0.3, 'early': 0.2, 'cif': 0.2, 'cmara': 0.15, 'gmara_acc': 0.15}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'cmara': 0.15, 'gmara_clingeo': 0.25}, {'mara': 0.25, 'early': 0.15, 'cif': 0.15, 'gmara_acc': 0.15, 'gmara_clingeo': 0.3}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_clingeo_node_mtl': 0.4}, {'mara': 0.2, 'early': 0.15, 'cif': 0.15, 'gmara_clingeo': 0.2, 'gmara_clingeo_node_mtl': 0.3}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_clingeo_node_burden_mtl': 0.4}, {'mara': 0.2, 'early': 0.15, 'cif': 0.15, 'gmara_clingeo': 0.2, 'gmara_clingeo_node_burden_mtl': 0.3}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_clingeo_node_burden_auc': 0.4}, {'mara': 0.2, 'early': 0.15, 'cif': 0.15, 'gmara_clingeo': 0.2, 'gmara_clingeo_node_burden_auc': 0.3}, {'mara': 0.2, 'early': 0.1, 'cif': 0.15, 'gmara_clingeo_node_burden_mtl': 0.25, 'gmara_clingeo_node_burden_auc': 0.3}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_burden_w004': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_burden_w006': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_burden_w010': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_burden_w012': 0.4}, {'mara': 0.2, 'early': 0.1, 'cif': 0.15, 'gmara_clingeo_node_burden_mtl': 0.25, 'gmara_burden_w010': 0.3}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_src279n_bin_w008': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_gm_w008': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_gq_w008': 0.4}, {'mara': 0.2, 'early': 0.1, 'cif': 0.15, 'gmara_burden_w006': 0.25, 'gmara_gm_w008': 0.15, 'gmara_gq_w008': 0.15}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_geometry_only': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_clinical_only': 0.4}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'gmara_clingeo_nocausal': 0.4}, {'mara': 0.2, 'early': 0.1, 'cif': 0.15, 'gmara_clingeo_nocausal': 0.2, 'gmara_clingeo': 0.35}, {'mara': 0.3, 'early': 0.15, 'cif': 0.2, 'cmara': 0.15, 'gmara_acc': 0.15, 'tripath_acc': 0.05}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'cmara': 0.15, 'gmara_auc': 0.15, 'gmara_acc': 0.1}, {'mara': 0.3, 'cif': 0.2, 'cmara': 0.15, 'gmara_auc': 0.2, 'gmara_acc': 0.15}, {'mara': 0.25, 'early': 0.15, 'cif': 0.15, 'cmara': 0.15, 'gmara_acc': 0.15, 'cqof_acc': 0.1, 'omara_acc': 0.05}, {'mara': 0.25, 'early': 0.15, 'cif': 0.2, 'cmara': 0.1, 'gmara_distill_w030': 0.3}, {'mara': 0.2, 'early': 0.1, 'cif': 0.15, 'gmara_acc': 0.2, 'gmara_distill_w030': 0.25, 'tripath_acc': 0.1}, {'gmara_acc': 0.25, 'gmara_distill_w015': 0.2, 'gmara_distill_w030': 0.35, 'tripath_acc': 0.2}]
    for weights in hand_weights:
        present = {k: v for k, v in weights.items() if k in frame.columns}
        if len(present) < 2:
            continue
        total = sum(present.values())
        score = sum((w / total * frame[k].to_numpy() for k, w in present.items()))
        name = 'wmean:' + '+'.join((f'{k}={w / total:.2f}' for k, w in present.items()))
        add_candidate(rows, seen, name, y, score, score_store=score_store)
        for geo_col in geo_cols:
            if geo_col not in frame.columns:
                continue
            for alpha in [0.05, 0.1, 0.15, 0.2, 0.25, 0.3]:
                mixed = (1.0 - alpha) * score + alpha * frame[geo_col].to_numpy()
                add_candidate(rows, seen, f'{name}|{geo_col}|a{alpha:.2f}', y, mixed, score_store=score_store)
    return rows

def meta_features(frame, cols):
    probs = frame[cols].clip(1e-05, 1 - 1e-05)
    x = probs.copy()
    x['p_mean'] = probs.mean(axis=1)
    x['p_std'] = probs.std(axis=1)
    x['p_range'] = probs.max(axis=1) - probs.min(axis=1)
    x['vote_pos'] = (probs >= 0.5).sum(axis=1)
    for col in cols:
        p = probs[col].to_numpy()
        x[f'logit_{col}'] = np.log(p / (1.0 - p))
    return x

def meta_lr_candidates(frame, model_cols, geo_cols, seed, n_splits, split_strategy, score_store=None):
    y = frame['label'].to_numpy(dtype=int)
    focus = [c for c in ['single_T2W', 'single_DWI', 'single_T1C', 'single_T1W', 'mara', 'early', 'cif', 'cmara', 'gmara_auc', 'gmara_acc', 'gmara_clingeo', 'gmara_clingeo_node_mtl', 'gmara_clingeo_node_burden_mtl', 'gmara_clingeo_node_burden_auc', 'gmara_burden_w004', 'gmara_burden_w006', 'gmara_burden_w010', 'gmara_burden_w012', 'gmara_src279n_bin_w008', 'gmara_gm_w008', 'gmara_gq_w008', 'gmara_geometry_only', 'gmara_clinical_only', 'gmara_clingeo_nocausal', 'tripath_acc', 'cqof_acc', 'omara_acc', 'gmara_distill_w015', 'gmara_distill_w030'] if c in model_cols]
    feature_sets = []
    if focus:
        feature_sets.append(('meta_lr:deep', focus))
    if focus and geo_cols:
        feature_sets.append(('meta_lr:deep_geo', focus + geo_cols))
    if {'mara', 'early', 'cif', 'cmara', 'gmara_acc'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:core_geo', ['mara', 'early', 'cif', 'cmara', 'gmara_acc'] + geo_cols))
    if {'mara', 'early', 'cif', 'cmara', 'gmara_clingeo'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:clingeo_core', ['mara', 'early', 'cif', 'cmara', 'gmara_clingeo'] + geo_cols))
    if {'mara', 'early', 'cif', 'gmara_clingeo_node_mtl'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:node_mtl_core', ['mara', 'early', 'cif', 'gmara_clingeo_node_mtl'] + geo_cols))
    if {'mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:node_burden_core', ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_mtl'] + geo_cols))
    if {'mara', 'early', 'cif', 'gmara_clingeo_node_burden_auc'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:node_burden_auc_core', ['mara', 'early', 'cif', 'gmara_clingeo_node_burden_auc'] + geo_cols))
    if {'single_T2W', 'single_DWI', 'single_T1C', 'single_T1W'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:single_modalities', ['single_T2W', 'single_DWI', 'single_T1C', 'single_T1W'] + geo_cols))
    if {'mara', 'early', 'cif', 'gmara_geometry_only', 'gmara_clinical_only'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:component_context', ['mara', 'early', 'cif', 'gmara_geometry_only', 'gmara_clinical_only'] + geo_cols))
    if {'mara', 'early', 'cif', 'gmara_clingeo_nocausal', 'gmara_clingeo'}.issubset(set(frame.columns)):
        feature_sets.append(('meta_lr:causal_ablation', ['mara', 'early', 'cif', 'gmara_clingeo_nocausal', 'gmara_clingeo'] + geo_cols))
    for aux_name in ['gmara_burden_w004', 'gmara_burden_w006', 'gmara_burden_w010', 'gmara_burden_w012', 'gmara_src279n_bin_w008', 'gmara_gm_w008', 'gmara_gq_w008', 'gmara_geometry_only', 'gmara_clinical_only', 'gmara_clingeo_nocausal']:
        if {'mara', 'early', 'cif', aux_name}.issubset(set(frame.columns)):
            feature_sets.append((f'meta_lr:{aux_name}_core', ['mara', 'early', 'cif', aux_name] + geo_cols))
    rows = []
    splits = make_splits(frame, y, seed, n_splits, split_strategy)
    for set_name, cols in feature_sets:
        x = meta_features(frame, cols)
        for c_value in [0.1, 0.3, 1.0]:
            pred = np.zeros(len(y), dtype=float)
            estimator = make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), LogisticRegression(C=c_value, max_iter=500, solver='liblinear', class_weight='balanced'))
            for train_idx, val_idx in splits:
                model = clone(estimator)
                model.fit(x.iloc[train_idx], y[train_idx])
                pred[val_idx] = model.predict_proba(x.iloc[val_idx])[:, 1]
            name = f'{set_name}:c{c_value}'
            rows.append(metric_row(name, y, pred))
            if score_store is not None:
                score_store[name] = pred
    return rows

def write_markdown(path, metrics, used_models, geo_cols, split_strategy):
    top = metrics.head(20)
    cols = list(top.columns)
    table = ['| ' + ' | '.join(cols) + ' |', '| ' + ' | '.join(['---'] * len(cols)) + ' |']
    for _, row in top.iterrows():
        values = []
        for col in cols:
            value = row[col]
            if isinstance(value, (float, np.floating)):
                values.append(f'{value:.4f}')
            else:
                values.append(str(value))
        table.append('| ' + ' | '.join(values) + ' |')
    lines = ['# Fast evidence fusion', '', f"Used deep OOF models: {', '.join(used_models)}", f'OOF split strategy for geometry/meta models: {split_strategy}', f"Geometry OOF scores: {(', '.join(geo_cols) if geo_cols else 'disabled')}", '', 'Metrics are OOF estimates at the same unit as the input index. `best_*` uses a threshold sweep on the OOF scores and should be treated as model-selection evidence, not a locked external-test threshold.', '', '\n'.join(table), '']
    with open(path, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', default=os.path.join(PROJECT_ROOT, 'training_results', 'fast_evidence_fusion_2cls'))
    parser.add_argument('--models', nargs='*', type=parse_name_path)
    parser.add_argument('--index', default=DEFAULT_INDEX)
    parser.add_argument('--patient_index', default=DEFAULT_PATIENT_INDEX)
    parser.add_argument('--no_geometry', action='store_true')
    parser.add_argument('--n_splits', type=int, default=5)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--split_strategy', choices=['group', 'stratified'], default='group')
    args = parser.parse_args()
    model_items = args.models if args.models else list(DEFAULT_MODELS.items())
    frame, used_models = make_aligned_frame(model_items)
    geo_cols = []
    if not args.no_geometry:
        geo_scores = geometry_oof_scores(frame, resolve_path(args.index), resolve_path(args.patient_index), seed=args.seed, n_splits=args.n_splits, split_strategy=args.split_strategy)
        for name, score in geo_scores.items():
            frame[name] = score
            geo_cols.append(name)
    candidate_scores = {}
    rows = []
    rows.extend(search_weighted_candidates(frame, used_models, geo_cols, score_store=candidate_scores))
    rows.extend(meta_lr_candidates(frame, used_models, geo_cols, seed=args.seed, n_splits=args.n_splits, split_strategy=args.split_strategy, score_store=candidate_scores))
    metrics = pd.DataFrame(rows).sort_values(['best_acc', 'auc', 'f1_05', 'balanced_acc05'], ascending=False)
    os.makedirs(args.output, exist_ok=True)
    selected = []
    if not metrics.empty:
        selected.append(('selected_fusion_best_acc', metrics.iloc[0]['candidate']))
        top_auc = metrics.sort_values(['auc', 'best_acc', 'f1_05'], ascending=False).iloc[0]['candidate']
        selected.append(('selected_fusion_auc', top_auc))
        for prefix, candidate in selected:
            if candidate in candidate_scores:
                frame[prefix] = candidate_scores[candidate]
                frame[f'{prefix}_candidate'] = candidate
        top_score_cols = {}
        for _, row in metrics.head(20).iterrows():
            candidate = row['candidate']
            if candidate in candidate_scores:
                top_score_cols[score_column_name('candidate', candidate)] = candidate_scores[candidate]
        if top_score_cols:
            score_frame = frame[['pid', 'label']].copy()
            for col, score in top_score_cols.items():
                score_frame[col] = score
            score_frame.to_csv(os.path.join(args.output, 'candidate_scores_top20.csv'), index=False)
    frame.to_csv(os.path.join(args.output, 'aligned_predictions.csv'), index=False)
    metrics.to_csv(os.path.join(args.output, 'metrics.csv'), index=False)
    write_markdown(os.path.join(args.output, 'top_metrics.md'), metrics, used_models, geo_cols, args.split_strategy)
    print(f"Used models: {', '.join(used_models)}")
    print(f'Split strategy: {args.split_strategy}')
    print(f"Geometry scores: {(', '.join(geo_cols) if geo_cols else 'disabled')}")
    print(metrics.head(30).to_string(index=False))
if __name__ == '__main__':
    main()
