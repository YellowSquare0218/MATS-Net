import torch
import torch.nn as nn
import torch.nn.functional as F
from functools import partial
from typing import Optional, Tuple, List

def make_conv3d(conv2d_cls, in_chans, out_chans, kernel_size, stride=1, padding=0, groups=1, bias=True, **kw):
    if isinstance(kernel_size, int):
        k = (1, kernel_size, kernel_size) if kernel_size > 1 else (1, 1, 1)
    elif len(kernel_size) == 2:
        k = (1, kernel_size[0], kernel_size[1])
    else:
        k = kernel_size
    if isinstance(stride, int):
        s = (1, stride, stride) if stride > 1 else (1, 1, 1)
    elif len(stride) == 2:
        s = (1, stride[0], stride[1])
    else:
        s = stride
    if isinstance(padding, int):
        p = (0, padding, padding) if padding > 0 else (0, 0, 0)
    elif len(padding) == 2:
        p = (0, padding[0], padding[1])
    else:
        p = padding
    return nn.Conv3d(in_chans, out_chans, k, stride=s, padding=p, groups=groups, bias=bias)

class DropPath3d(nn.Module):

    def __init__(self, drop_prob=0.0):
        super().__init__()
        self.drop_prob = drop_prob

    def forward(self, x):
        if self.drop_prob == 0.0 or not self.training:
            return x
        keep_prob = 1 - self.drop_prob
        shape = (x.shape[0],) + (1,) * (x.ndim - 1)
        random_tensor = keep_prob + torch.rand(shape, dtype=x.dtype, device=x.device)
        random_tensor.floor_()
        return x.div(keep_prob) * random_tensor

class ConvNeXtBlock3d(nn.Module):

    def __init__(self, dim, drop_path=0.0, layer_scale_init_value=1e-06):
        super().__init__()
        self.dwconv = nn.Conv3d(dim, dim, kernel_size=7, padding=3, groups=dim)
        self.norm = nn.LayerNorm(dim, eps=1e-06)
        self.pwconv1 = nn.Linear(dim, 4 * dim)
        self.act = nn.GELU()
        self.pwconv2 = nn.Linear(4 * dim, dim)
        self.gamma = nn.Parameter(layer_scale_init_value * torch.ones(dim)) if layer_scale_init_value > 0 else None
        self.drop_path = DropPath3d(drop_path) if drop_path > 0 else nn.Identity()

    def forward(self, x):
        inp = x
        x = self.dwconv(x)
        x = x.permute(0, 2, 3, 4, 1)
        x = self.norm(x)
        x = self.pwconv1(x)
        x = self.act(x)
        x = self.pwconv2(x)
        if self.gamma is not None:
            x = self.gamma * x
        x = x.permute(0, 4, 1, 2, 3)
        return inp + self.drop_path(x)

class ConvNeXt3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, depths=(3, 3, 9, 3), dims=(96, 192, 384, 768)):
        super().__init__()
        self.stem_conv = nn.Conv3d(in_chans, dims[0], kernel_size=(3, 4, 4), stride=(1, 4, 4), padding=(1, 0, 0))
        self.downsample_layers = nn.ModuleList()
        self.stages = nn.ModuleList()
        dp_rates = [x.item() for x in torch.linspace(0, 0.1, sum(depths))]
        cur = 0
        for i in range(4):
            if i > 0:
                self.downsample_layers.append(nn.Conv3d(dims[i - 1], dims[i], kernel_size=(1, 2, 2), stride=(1, 2, 2)))
            else:
                self.downsample_layers.append(nn.Identity())
            stage = nn.Sequential(*[ConvNeXtBlock3d(dim=dims[i], drop_path=dp_rates[cur + j]) for j in range(depths[i])])
            self.stages.append(stage)
            cur += depths[i]
        self.norm = nn.LayerNorm(dims[-1], eps=1e-06)
        self.head = nn.Linear(dims[-1], num_classes)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, (nn.Conv3d, nn.Linear)):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward_features(self, x):
        x = self.stem_conv(x)
        for i in range(4):
            if i > 0:
                x = self.downsample_layers[i](x)
            x = self.stages[i](x)
        x = x.mean(dim=(-3, -2, -1))
        return self.norm(x)

    def forward(self, x):
        return self.head(self.forward_features(x))

def _window_partition3d(x, window_size):
    B, C, D, H, W = x.shape
    wd = wh = ww = window_size if isinstance(window_size, int) else window_size[0]
    x = x.view(B, C, D // wd, wd, H // wh, wh, W // ww, ww)
    windows = x.permute(0, 2, 4, 6, 3, 5, 7, 1).contiguous()
    return windows.view(-1, wd * wh * ww, C)

def _window_reverse3d(windows, window_size, D, H, W):
    wd = wh = ww = window_size if isinstance(window_size, int) else window_size[0]
    nW = D * H * W // (wd * wh * ww)
    B = windows.shape[0] // nW
    x = windows.view(B, D // wd, H // wh, W // ww, wd, wh, ww, -1)
    return x.permute(0, 7, 1, 4, 2, 5, 3, 6).contiguous().view(B, -1, D, H, W)

class PatchEmbed3d(nn.Module):

    def __init__(self, in_chans, embed_dim, patch_size=(2, 4, 4)):
        super().__init__()
        self.proj = nn.Conv3d(in_chans, embed_dim, kernel_size=patch_size, stride=patch_size)
        self.norm = nn.LayerNorm(embed_dim)

    def forward(self, x):
        x = self.proj(x)
        return self.norm(x.permute(0, 2, 3, 4, 1))

class PatchMerging3d(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.reduction = nn.Linear(4 * dim, 2 * dim, bias=False)
        self.norm = nn.LayerNorm(4 * dim)

    def forward(self, x):
        B, D, H, W, C = x.shape
        x = x.reshape(B, D, H // 2, 2, W // 2, 2, C)
        x = x.permute(0, 1, 2, 4, 3, 5, 6).reshape(B, D, H // 2, W // 2, 4 * C)
        return self.reduction(self.norm(x))

class WindowAttention3d(nn.Module):

    def __init__(self, dim, window_size, num_heads, qkv_bias=True, attn_drop=0.0, proj_drop=0.0):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** (-0.5)
        wd = wh = ww = window_size if isinstance(window_size, int) else window_size[0]
        self.window_size = (wd, wh, ww)
        self.relative_position_bias_table = nn.Parameter(torch.zeros((2 * wd - 1) * (2 * wh - 1) * (2 * ww - 1), num_heads))
        coords = torch.stack(torch.meshgrid(torch.arange(wd), torch.arange(wh), torch.arange(ww), indexing='ij'))
        coords_flatten = torch.flatten(coords, 1)
        relative_coords = coords_flatten[:, :, None] - coords_flatten[:, None, :]
        relative_coords = relative_coords.permute(1, 2, 0).contiguous()
        relative_coords[:, :, 0] += wd - 1
        relative_coords[:, :, 1] += wh - 1
        relative_coords[:, :, 2] += ww - 1
        relative_coords[:, :, 0] *= (2 * wh - 1) * (2 * ww - 1)
        relative_coords[:, :, 1] *= 2 * ww - 1
        self.register_buffer('relative_position_index', relative_coords.sum(-1))
        self.qkv = nn.Linear(dim, dim * 3, bias=qkv_bias)
        self.attn_drop = nn.Dropout(attn_drop)
        self.proj = nn.Linear(dim, dim)
        self.proj_drop = nn.Dropout(proj_drop)
        nn.init.trunc_normal_(self.relative_position_bias_table, std=0.02)

    def forward(self, x, mask=None):
        B_, N, C = x.shape
        qkv = self.qkv(x).reshape(B_, N, 3, self.num_heads, C // self.num_heads)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = (qkv[0], qkv[1], qkv[2])
        q = q * self.scale
        attn = q @ k.transpose(-2, -1)
        rel_bias = self.relative_position_bias_table[self.relative_position_index.view(-1)]
        rel_bias = rel_bias.view(N, N, -1).permute(2, 0, 1).contiguous()
        attn = attn + rel_bias.unsqueeze(0)
        if mask is not None:
            nW = mask.shape[0]
            attn = attn.view(B_ // nW, nW, self.num_heads, N, N) + mask.unsqueeze(1).unsqueeze(0)
            attn = attn.view(-1, self.num_heads, N, N)
        attn = attn.softmax(dim=-1)
        attn = self.attn_drop(attn)
        x = (attn @ v).transpose(1, 2).reshape(B_, N, C)
        return self.proj_drop(self.proj(x))

class SwinBlock3d(nn.Module):

    def __init__(self, dim, input_resolution, num_heads, window_size, shift_size=0, mlp_ratio=4.0, drop=0.0, attn_drop=0.0, drop_path=0.0):
        super().__init__()
        D, H, W = input_resolution
        ws = min(window_size, D, H, W)
        self.window_size = ws
        self.shift_size = min(shift_size, ws // 2) if shift_size > 0 and ws > 1 else 0
        self.norm1 = nn.LayerNorm(dim)
        self.attn = WindowAttention3d(dim, ws, num_heads, attn_drop=attn_drop, proj_drop=drop)
        self.drop_path = DropPath3d(drop_path) if drop_path > 0 else nn.Identity()
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(nn.Linear(dim, int(dim * mlp_ratio)), nn.GELU(), nn.Linear(int(dim * mlp_ratio), dim), nn.Dropout(drop))
        if self.shift_size > 0:
            img_mask = torch.zeros((1, 1, D, H, W))
            sh = self.shift_size
            cnt = 0
            for ds, de in [(0, -ws), (-ws, -sh), (-sh, D)]:
                for hs, he in [(0, -ws), (-ws, -sh), (-sh, H)]:
                    for w_s, w_e in [(0, -ws), (-ws, -sh), (-sh, W)]:
                        img_mask[:, :, ds:de, hs:he, w_s:w_e] = cnt
                        cnt += 1
            mask_windows = _window_partition3d(img_mask, ws)
            mask_windows = mask_windows.view(-1, ws ** 3)
            attn_mask = mask_windows.unsqueeze(1) - mask_windows.unsqueeze(2)
            self.register_buffer('attn_mask', attn_mask.masked_fill(attn_mask != 0, -100.0).masked_fill(attn_mask == 0, 0.0))
        else:
            self.register_buffer('attn_mask', torch.zeros(1))

    def forward(self, x):
        B, D, H, W, C = x.shape
        shortcut = x
        ws = self.window_size
        x = self.norm1(x)
        if self.shift_size > 0:
            x = torch.roll(x, shifts=(-self.shift_size,) * 3, dims=(1, 2, 3))
        x_windows = _window_partition3d(x.permute(0, 4, 1, 2, 3), ws)
        attn_windows = self.attn(x_windows, mask=None if self.shift_size == 0 else self.attn_mask)
        x = _window_reverse3d(attn_windows, ws, D, H, W).permute(0, 2, 3, 4, 1)
        if self.shift_size > 0:
            x = torch.roll(x, shifts=(self.shift_size,) * 3, dims=(1, 2, 3))
        x = shortcut + self.drop_path(x)
        return x + self.drop_path(self.mlp(self.norm2(x)))

class SwinT3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, embed_dim=96, depths=(2, 2, 6, 2), num_heads=(3, 6, 12, 24), window_size=4):
        super().__init__()
        patch_size = (2, 4, 4)
        self.patch_embed = PatchEmbed3d(in_chans, embed_dim, patch_size)
        D0, H0, W0 = (16 // patch_size[0], 64 // patch_size[2], 64 // patch_size[2])
        dpr = [x.item() for x in torch.linspace(0, 0.1, sum(depths))]
        self.layers = nn.ModuleList()
        for i_layer in range(len(depths)):
            res = (D0, H0 // 2 ** i_layer, W0 // 2 ** i_layer)
            blocks = nn.ModuleList([SwinBlock3d(dim=int(embed_dim * 2 ** i_layer), input_resolution=res, num_heads=num_heads[i_layer], window_size=window_size, shift_size=0 if j % 2 == 0 else window_size // 2, drop_path=dpr[sum(depths[:i_layer]) + j]) for j in range(depths[i_layer])])
            downsample = PatchMerging3d(int(embed_dim * 2 ** i_layer)) if i_layer < len(depths) - 1 else None
            self.layers.append(nn.ModuleDict({'blocks': blocks, 'downsample': downsample}))
        self.num_features = int(embed_dim * 2 ** (len(depths) - 1))
        self.norm = nn.LayerNorm(self.num_features)
        self.head = nn.Linear(self.num_features, num_classes)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Linear):
                nn.init.trunc_normal_(m.weight, std=0.02)
                if m.bias is not None:
                    nn.init.zeros_(m.bias)

    def forward_features(self, x):
        x = self.patch_embed(x)
        for layer in self.layers:
            for blk in layer['blocks']:
                x = blk(x)
            if layer['downsample'] is not None:
                x = layer['downsample'](x)
        return self.norm(x).mean(dim=(1, 2, 3))

    def forward(self, x):
        return self.head(self.forward_features(x))

class SEBlock3d(nn.Module):

    def __init__(self, in_ch, reduction=4):
        super().__init__()
        mid = max(1, in_ch // reduction)
        self.se = nn.Sequential(nn.AdaptiveAvgPool3d(1), nn.Conv3d(in_ch, mid, 1), nn.SiLU(), nn.Conv3d(mid, in_ch, 1), nn.Sigmoid())

    def forward(self, x):
        return x * self.se(x)

class MBConvBlock3d(nn.Module):

    def __init__(self, in_ch, out_ch, expand_ratio, kernel_size=3, stride=1, se_ratio=0.25, drop_path=0.0):
        super().__init__()
        self.use_residual = stride == 1 and in_ch == out_ch
        hidden = int(in_ch * expand_ratio)
        layers = []
        if expand_ratio != 1:
            layers.append(nn.Conv3d(in_ch, hidden, 1, bias=False))
            layers.append(nn.BatchNorm3d(hidden))
            layers.append(nn.SiLU())
        k = (1, kernel_size, kernel_size) if kernel_size > 1 else (1, 1, 1)
        s = (1, stride, stride) if stride > 1 else 1
        p = tuple((x // 2 for x in k))
        layers.extend([nn.Conv3d(hidden, hidden, k, stride=s, padding=p, groups=hidden, bias=False), nn.BatchNorm3d(hidden), nn.SiLU(), SEBlock3d(hidden, int(1 / se_ratio)) if se_ratio else nn.Identity(), nn.Conv3d(hidden, out_ch, 1, bias=False), nn.BatchNorm3d(out_ch)])
        self.conv = nn.Sequential(*layers)
        self.drop_path = DropPath3d(drop_path) if drop_path > 0 else nn.Identity()

    def forward(self, x):
        if self.use_residual:
            return x + self.drop_path(self.conv(x))
        return self.conv(x)

class EfficientNetV2_3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, width_mult=1.0, depth_mult=1.0):
        super().__init__()
        cfg = [(1, 24, 3, 1, 0, 2), (4, 48, 3, 2, 0, 4), (4, 64, 3, 2, 0, 4), (4, 128, 3, 2, 0.25, 6), (6, 160, 3, 1, 0.25, 9), (6, 256, 3, 2, 0.25, 15)]
        stem_ch = int(24 * width_mult)
        self.stem = nn.Sequential(nn.Conv3d(in_chans, stem_ch, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1), bias=False), nn.BatchNorm3d(stem_ch), nn.SiLU())
        cur_ch = stem_ch
        dpr = [x.item() for x in torch.linspace(0, 0.1, sum((c[-1] for c in cfg)))]
        stages = []
        dpr_idx = 0
        for expand, out_ch, k, s, se, n in cfg:
            out_ch = int(out_ch * width_mult)
            n = int(n * depth_mult)
            for i in range(n):
                s_ = s if i == 0 else 1
                stages.append(MBConvBlock3d(cur_ch, out_ch, expand, k, s_, se, drop_path=dpr[dpr_idx]))
                cur_ch = out_ch
                dpr_idx += 1
        self.stages = nn.Sequential(*stages)
        self.head_conv = nn.Sequential(nn.Conv3d(cur_ch, 1280, 1), nn.BatchNorm3d(1280), nn.SiLU())
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.head = nn.Linear(1280, num_classes)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

    def forward_features(self, x):
        x = self.stem(x)
        x = self.stages(x)
        x = self.head_conv(x)
        return self.pool(x).flatten(1)

    def forward(self, x):
        return self.head(self.forward_features(x))

class RepVGGBlock3d(nn.Module):

    def __init__(self, in_ch, out_ch, kernel_size=3, stride=1, groups=1):
        super().__init__()
        k = (1, kernel_size, kernel_size) if kernel_size > 1 else (1, 1, 1)
        s = (1, stride, stride) if stride > 1 else 1
        p = tuple((x // 2 for x in k))
        self.conv = nn.Conv3d(in_ch, out_ch, k, stride=s, padding=p, groups=groups, bias=False)
        self.bn = nn.BatchNorm3d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        if in_ch != out_ch or stride > 1:
            self.shortcut = nn.Sequential(nn.Conv3d(in_ch, out_ch, 1, stride=s, bias=False), nn.BatchNorm3d(out_ch))
        else:
            self.shortcut = nn.Identity()

    def forward(self, x):
        return self.relu(self.bn(self.conv(x)) + self.shortcut(x))

class RepVGG3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, num_blocks=(2, 4, 14, 1), width=(64, 128, 256, 512)):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv3d(in_chans, width[0], (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1), bias=False), nn.BatchNorm3d(width[0]), nn.ReLU(inplace=True))
        cur = width[0]
        stages = []
        for i, (n, w) in enumerate(zip(num_blocks, width)):
            for j in range(n):
                stride = 2 if i > 0 and j == 0 else 1
                stages.append(RepVGGBlock3d(cur, w, 3, stride))
                cur = w
        self.stages = nn.Sequential(*stages)
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.head = nn.Linear(cur, num_classes)
        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        x = self.stem(x)
        x = self.stages(x)
        return self.head(self.pool(x).flatten(1))

class ResNeXtBlock3d(nn.Module):

    def __init__(self, in_ch, out_ch, stride=1, cardinality=32, base_width=4):
        super().__init__()
        D = int(out_ch // 2 * (base_width / 64)) * cardinality
        self.conv1 = nn.Conv3d(in_ch, D, 1, bias=False)
        self.bn1 = nn.BatchNorm3d(D)
        s = (1, stride, stride) if stride > 1 else 1
        self.conv2 = nn.Conv3d(D, D, (1, 3, 3), stride=s, padding=(0, 1, 1), groups=cardinality, bias=False)
        self.bn2 = nn.BatchNorm3d(D)
        self.conv3 = nn.Conv3d(D, out_ch, 1, bias=False)
        self.bn3 = nn.BatchNorm3d(out_ch)
        self.relu = nn.ReLU(inplace=True)
        self.downsample = None
        if stride > 1 or in_ch != out_ch:
            self.downsample = nn.Sequential(nn.Conv3d(in_ch, out_ch, 1, stride=s, bias=False), nn.BatchNorm3d(out_ch))

    def forward(self, x):
        identity = x
        out = self.relu(self.bn1(self.conv1(x)))
        out = self.relu(self.bn2(self.conv2(out)))
        out = self.bn3(self.conv3(out))
        if self.downsample is not None:
            identity = self.downsample(x)
        return self.relu(out + identity)

class ResNeXt3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, layers=(3, 4, 6, 3), cardinality=32):
        super().__init__()
        self.stem = nn.Sequential(nn.Conv3d(in_chans, 64, (1, 7, 7), stride=(1, 2, 2), padding=(0, 3, 3), bias=False), nn.BatchNorm3d(64), nn.ReLU(inplace=True), nn.MaxPool3d((1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1)))
        self.inplanes = 64
        ch = [256, 512, 1024, 2048]
        self.layer1 = self._make_layer(ResNeXtBlock3d, ch[0], layers[0], cardinality)
        self.layer2 = self._make_layer(ResNeXtBlock3d, ch[1], layers[1], cardinality, stride=2)
        self.layer3 = self._make_layer(ResNeXtBlock3d, ch[2], layers[2], cardinality, stride=2)
        self.layer4 = self._make_layer(ResNeXtBlock3d, ch[3], layers[3], cardinality, stride=2)
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.head = nn.Linear(ch[3], num_classes)
        self._init_weights()

    def _make_layer(self, block, planes, blocks, cardinality, stride=1):
        layers = [block(self.inplanes, planes, stride, cardinality)]
        self.inplanes = planes
        for _ in range(1, blocks):
            layers.append(block(planes, planes, 1, cardinality))
        return nn.Sequential(*layers)

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv3d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
            elif isinstance(m, nn.BatchNorm3d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        x = self.stem(x)
        x = self.layer1(x)
        x = self.layer2(x)
        x = self.layer3(x)
        x = self.layer4(x)
        return self.head(self.pool(x).flatten(1))

class MobileNetV3Block3d(nn.Module):

    def __init__(self, in_ch, out_ch, expand_ratio, kernel_size=3, stride=1, use_se=False, use_hs=False):
        super().__init__()
        self.use_residual = stride == 1 and in_ch == out_ch
        hidden = int(in_ch * expand_ratio)
        act = nn.Hardswish() if use_hs else nn.ReLU(inplace=True)
        layers = []
        if expand_ratio != 1:
            layers.extend([nn.Conv3d(in_ch, hidden, 1, bias=False), nn.BatchNorm3d(hidden), act])
        k = (1, kernel_size, kernel_size) if kernel_size > 1 else (1, 1, 1)
        s = (1, stride, stride) if stride > 1 else 1
        p = tuple((x // 2 for x in k))
        layers.extend([nn.Conv3d(hidden, hidden, k, stride=s, padding=p, groups=hidden, bias=False), nn.BatchNorm3d(hidden), act])
        if use_se:
            mid = max(1, hidden // 4)
            layers.append(nn.Sequential(nn.AdaptiveAvgPool3d(1), nn.Conv3d(hidden, mid, 1), nn.ReLU(inplace=True), nn.Conv3d(mid, hidden, 1), nn.Hardsigmoid()))
        layers.extend([nn.Conv3d(hidden, out_ch, 1, bias=False), nn.BatchNorm3d(out_ch)])
        self.conv = nn.Sequential(*layers)

    def forward(self, x):
        if self.use_residual:
            return x + self.conv(x)
        return self.conv(x)

class MobileNetV3_3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, mode='small'):
        super().__init__()
        if mode == 'small':
            cfg = [(1, 16, 3, 2, True, False), (4.5, 24, 3, 2, False, False), (3.67, 24, 3, 1, False, False), (4, 40, 5, 2, True, True), (6, 40, 5, 1, True, True), (6, 48, 5, 1, True, True), (3, 48, 5, 1, True, True), (6, 96, 5, 2, True, True), (6, 96, 5, 1, True, True)]
            out_ch = 576
        else:
            cfg = [(1, 16, 3, 1, False, False), (4, 24, 3, 2, False, False), (3, 24, 3, 1, False, False), (3, 40, 5, 2, True, False), (3, 40, 5, 1, True, False), (3, 40, 5, 1, True, False), (6, 80, 3, 2, False, True), (2.5, 80, 3, 1, False, True), (2.3, 80, 3, 1, False, True), (2.3, 80, 3, 1, False, True), (6, 112, 3, 1, True, True), (6, 112, 3, 1, True, True), (6, 160, 5, 2, True, True), (6, 160, 5, 1, True, True), (6, 160, 5, 1, True, True)]
            out_ch = 960
        self.stem = nn.Sequential(nn.Conv3d(in_chans, 16, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1), bias=False), nn.BatchNorm3d(16), nn.Hardswish())
        cur_ch = 16
        stages = []
        for expand, out, k, s, se, hs in cfg:
            stages.append(MobileNetV3Block3d(cur_ch, out, expand, k, s, se, hs))
            cur_ch = out
        self.stages = nn.Sequential(*stages)
        self.head_conv = nn.Sequential(nn.Conv3d(cur_ch, out_ch, 1), nn.BatchNorm3d(out_ch), nn.Hardswish())
        self.pool = nn.AdaptiveAvgPool3d(1)
        self.head = nn.Linear(out_ch, num_classes)

    def forward(self, x):
        x = self.stem(x)
        x = self.stages(x)
        x = self.head_conv(x)
        return self.head(self.pool(x).flatten(1))

class CvTAttention3d(nn.Module):

    def __init__(self, dim, num_heads, kernel_size=3, stride=1):
        super().__init__()
        self.num_heads = num_heads
        head_dim = dim // num_heads
        self.scale = head_dim ** (-0.5)
        k = (1, kernel_size, kernel_size) if kernel_size > 1 else (1, 1, 1)
        s = (1, stride, stride) if stride > 1 else 1
        p = tuple((x // 2 for x in k))
        self.q = nn.Conv3d(dim, dim, k, stride=s, padding=p, groups=dim, bias=True)
        self.kv = nn.Conv3d(dim, dim * 2, k, stride=s, padding=p, groups=dim, bias=True)
        self.proj = nn.Linear(dim, dim)

    def forward(self, x):
        B, D, H, W, C = x.shape
        x_c = x.permute(0, 4, 1, 2, 3)
        q = self.q(x_c).permute(0, 2, 3, 4, 1).reshape(B, D * H * W, C)
        kv = self.kv(x_c).permute(0, 2, 3, 4, 1).reshape(B, D * H * W, -1)
        k, v = kv.chunk(2, dim=-1)
        q = q.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        k = k.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        v = v.reshape(B, -1, self.num_heads, C // self.num_heads).permute(0, 2, 1, 3)
        attn = q @ k.transpose(-2, -1) * self.scale
        attn = attn.softmax(dim=-1)
        x = (attn @ v).transpose(1, 2).reshape(B, D * H * W, C)
        return self.proj(x).reshape(B, D, H, W, C)

class CvTBlock3d(nn.Module):

    def __init__(self, dim, num_heads, kernel_size=3, mlp_ratio=4.0, drop_path=0.0):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = CvTAttention3d(dim, num_heads, kernel_size)
        self.drop_path = DropPath3d(drop_path) if drop_path > 0 else nn.Identity()
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(nn.Linear(dim, int(dim * mlp_ratio)), nn.GELU(), nn.Linear(int(dim * mlp_ratio), dim))

    def forward(self, x):
        x = x + self.drop_path(self.attn(self.norm1(x)))
        return x + self.drop_path(self.mlp(self.norm2(x)))

class CvT3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, embed_dims=(64, 192, 384), depths=(1, 2, 10), num_heads=(1, 3, 6)):
        super().__init__()
        self.stage1 = nn.Sequential(nn.Conv3d(in_chans, embed_dims[0], (1, 7, 7), stride=(1, 4, 4), padding=(0, 3, 3)), nn.BatchNorm3d(embed_dims[0]), nn.ReLU(inplace=True))
        cur_dim = embed_dims[0]
        self.stages = nn.ModuleList()
        dpr = [x.item() for x in torch.linspace(0, 0.1, sum(depths))]
        cur = 0
        for i, (dim, depth, nhead) in enumerate(zip(embed_dims, depths, num_heads)):
            if i > 0:
                self.stages.append(nn.Conv3d(cur_dim, dim, (1, 2, 2), stride=(1, 2, 2)))
            else:
                self.stages.append(nn.Identity())
            self.stages.append(nn.Sequential(*[CvTBlock3d(dim, nhead, drop_path=dpr[cur + j]) for j in range(depth)]))
            cur_dim = dim
            cur += depth
        self.norm = nn.LayerNorm(cur_dim)
        self.head = nn.Linear(cur_dim, num_classes)

    def forward(self, x):
        x = self.stage1(x)
        B, C, D, H, W = x.shape
        for s in self.stages:
            if isinstance(s, nn.Identity):
                pass
            elif isinstance(s, nn.Conv3d):
                x = s(x)
                B, C, D, H, W = x.shape
            else:
                x = x.permute(0, 2, 3, 4, 1)
                x = s(x)
                x = x.permute(0, 4, 1, 2, 3)
        x = x.mean(dim=(-3, -2, -1))
        return self.head(self.norm(x))

class MambaSSM3d(nn.Module):

    def __init__(self, dim, d_state=16, d_conv=3, expand=2):
        super().__init__()
        self.dim = dim
        inner = int(dim * expand)
        self.in_proj = nn.Linear(dim, inner * 2)
        self.conv1d = nn.Conv1d(inner, inner, d_conv, padding=d_conv // 2, groups=inner)
        self.x_proj = nn.Linear(inner, d_state * 2)
        self.dt_proj = nn.Linear(d_state, inner)
        self.out_proj = nn.Linear(inner, dim)
        A = torch.arange(1, d_state + 1).float().view(1, d_state).repeat(inner, 1)
        self.register_buffer('A_log', torch.log(A))

    def forward(self, x):
        B, N, C = x.shape
        xz = self.in_proj(x)
        x, z = xz.chunk(2, dim=-1)
        x = x.transpose(1, 2)
        x = F.silu(self.conv1d(x)).transpose(1, 2)
        dt = F.softplus(self.dt_proj(torch.ones(B, N, self.A_log.size(0), device=x.device)))
        return self.out_proj(x * F.silu(z))

class VimBlock3d(nn.Module):

    def __init__(self, dim, drop_path=0.0):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.ssm = MambaSSM3d(dim)
        self.drop_path = DropPath3d(drop_path) if drop_path > 0 else nn.Identity()

    def forward(self, x):
        B, D, H, W, C = x.shape
        shortcut = x
        n = self.norm(x).view(B, D * H * W, C)
        n = self.ssm(n).view(B, D, H, W, C)
        return shortcut + self.drop_path(n)

class Vim3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, dim=192, depth=6):
        super().__init__()
        self.patch_embed = nn.Conv3d(in_chans, dim, kernel_size=(2, 4, 4), stride=(2, 4, 4))
        self.blocks = nn.Sequential(*[nn.Sequential(nn.LayerNorm(dim), nn.Linear(dim, dim * 2), nn.GELU(), nn.Linear(dim * 2, dim)) for _ in range(depth)])
        self.norm = nn.LayerNorm(dim)
        self.head = nn.Linear(dim, num_classes)

    def forward(self, x):
        x = self.patch_embed(x)
        x = x.permute(0, 2, 3, 4, 1)
        D, H, W = x.shape[1:4]
        for blk in self.blocks:
            x = x + blk(x)
        return self.head(self.norm(x).mean(dim=(1, 2, 3)))

class CoAtNetAttention3d(nn.Module):

    def __init__(self, dim, num_heads):
        super().__init__()
        self.num_heads = num_heads
        self.scale = (dim // num_heads) ** (-0.5)
        self.qkv = nn.Linear(dim, dim * 3)
        self.proj = nn.Linear(dim, dim)

    def forward(self, x):
        B, D, H, W, C = x.shape
        N = D * H * W
        qkv = self.qkv(x.view(B, N, C)).reshape(B, N, 3, self.num_heads, C // self.num_heads)
        qkv = qkv.permute(2, 0, 3, 1, 4)
        q, k, v = (qkv[0], qkv[1], qkv[2])
        attn = q @ k.transpose(-2, -1) * self.scale
        attn = attn.softmax(dim=-1)
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)
        return self.proj(x).reshape(B, D, H, W, C)

class CoAtNetBlock3d(nn.Module):

    def __init__(self, dim, num_heads, drop_path=0.0, use_attn=False):
        super().__init__()
        self.use_attn = use_attn
        if use_attn:
            self.norm1 = nn.LayerNorm(dim)
            self.mixer = CoAtNetAttention3d(dim, num_heads)
        else:
            self.norm1 = nn.LayerNorm(dim)
            self.mixer = nn.Sequential(nn.Conv3d(dim, dim, (1, 3, 3), padding=(0, 1, 1), groups=dim), nn.Conv3d(dim, dim, 1))
        self.drop_path = DropPath3d(drop_path) if drop_path > 0 else nn.Identity()
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = nn.Sequential(nn.Linear(dim, dim * 4), nn.GELU(), nn.Linear(dim * 4, dim))

    def forward(self, x):
        if self.use_attn:
            x = x + self.drop_path(self.mixer(self.norm1(x)))
        else:
            n = self.norm1(x).permute(0, 4, 1, 2, 3)
            n = self.mixer(n).permute(0, 2, 3, 4, 1)
            x = x + self.drop_path(n)
        return x + self.drop_path(self.mlp(self.norm2(x)))

class CoAtNet3d(nn.Module):

    def __init__(self, in_chans=1, num_classes=3, dims=(64, 128, 256, 512), depths=(2, 2, 6, 2)):
        super().__init__()
        self.stem = nn.Conv3d(in_chans, dims[0], (1, 4, 4), stride=(1, 4, 4))
        self.stages = nn.ModuleList()
        cur = dims[0]
        for i, (dim, d) in enumerate(zip(dims, depths)):
            if i > 0:
                self.stages.append(nn.Conv3d(cur, dim, (1, 2, 2), stride=(1, 2, 2)))
            cur = dim
            use_attn = i >= len(dims) // 2
            self.stages.append(nn.Sequential(*[CoAtNetBlock3d(dim, num_heads=dim // 32, drop_path=0.0, use_attn=use_attn) for _ in range(d)]))
        self.norm = nn.LayerNorm(cur)
        self.head = nn.Linear(cur, num_classes)

    def forward(self, x):
        x = self.stem(x)
        B = x.shape[0]
        for s in self.stages:
            if isinstance(s, nn.Conv3d):
                x = s(x)
            else:
                x = x.permute(0, 2, 3, 4, 1)
                x = s(x)
                x = x.permute(0, 4, 1, 2, 3)
        return self.head(self.norm(x.mean(dim=(-3, -2, -1))))

class EarlyFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)

    def forward(self, x: List[torch.Tensor]):
        fused = torch.cat(x, dim=1)
        return self.encoder(fused)

class LateFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoders = nn.ModuleList([backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs) for _ in range(4)])
        self._feature_dims = [e.forward_features(torch.randn(1, 1, 16, 64, 64)).shape[-1] for e in self.encoders]
        feat_dim = sum(self._feature_dims)
        self.fusion_head = nn.Sequential(nn.Linear(feat_dim, feat_dim // 2), nn.ReLU(), nn.Dropout(0.3), nn.Linear(feat_dim // 2, num_classes))

    def forward(self, x: List[torch.Tensor]):
        feats = []
        for i, enc in enumerate(self.encoders):
            feats.append(enc.forward_features(x[i]))
        fused = torch.cat(feats, dim=-1)
        return self.fusion_head(fused)

class CrossAttnFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoders = nn.ModuleList([backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs) for _ in range(4)])
        dummy = torch.randn(1, 1, 16, 64, 64)
        self.feat_dim = self.encoders[0].forward_features(dummy).shape[-1]
        self.cross_attn = nn.MultiheadAttention(self.feat_dim, num_heads=4, batch_first=True)
        self.fusion_head = nn.Sequential(nn.Linear(self.feat_dim, self.feat_dim // 2), nn.ReLU(), nn.Linear(self.feat_dim // 2, num_classes))

    def forward(self, x: List[torch.Tensor]):
        feats = [enc.forward_features(xi) for enc, xi in zip(self.encoders, x)]
        q = feats[0].unsqueeze(1)
        kv = torch.stack(feats[1:], dim=1)
        out, _ = self.cross_attn(q, kv, kv)
        return self.fusion_head(out.squeeze(1))

class GatedFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoders = nn.ModuleList([backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs) for _ in range(4)])
        dummy = torch.randn(1, 1, 16, 64, 64)
        self.feat_dim = self.encoders[0].forward_features(dummy).shape[-1]
        self.gates = nn.Sequential(nn.Linear(4 * self.feat_dim, 4), nn.Softmax(dim=-1))
        self.head = nn.Linear(self.feat_dim, num_classes)

    def forward(self, x: List[torch.Tensor]):
        feats = [enc.forward_features(xi) for enc, xi in zip(self.encoders, x)]
        stacked = torch.stack(feats, dim=-1)
        gates = self.gates(stacked.flatten(1))
        fused = (stacked * gates.unsqueeze(1)).sum(dim=-1)
        return self.head(fused)
from cgcmr_fusion import CGCMRFusion
from mara_fusion import MARAFusion
from mara_v2_fusion import MARAv2Fusion
from mdn_fusion import MDNFusion
MODELS = {'convnext3d_tiny': lambda **kw: ConvNeXt3d(depths=(3, 3, 9, 3), dims=(96, 192, 384, 768), **kw), 'convnext3d_small': lambda **kw: ConvNeXt3d(depths=(3, 3, 27, 3), dims=(96, 192, 384, 768), **kw), 'efficientnetv2_3d': lambda **kw: EfficientNetV2_3d(**kw), 'repvgg3d_a0': lambda **kw: RepVGG3d(num_blocks=(2, 4, 14, 1), width=(48, 96, 192, 1280), **kw), 'repvgg3d_a1': lambda **kw: RepVGG3d(num_blocks=(2, 4, 14, 1), width=(64, 128, 256, 1280), **kw), 'resnext3d_50': lambda **kw: ResNeXt3d(layers=(3, 4, 6, 3), **kw), 'mobilenetv3_small': lambda **kw: MobileNetV3_3d(mode='small', **kw), 'mobilenetv3_large': lambda **kw: MobileNetV3_3d(mode='large', **kw), 'swin3d_tiny': lambda **kw: SwinT3d(embed_dim=96, depths=(2, 2, 6, 2), num_heads=(3, 6, 12, 24), **kw), 'swin3d_small': lambda **kw: SwinT3d(embed_dim=96, depths=(2, 2, 18, 2), num_heads=(3, 6, 12, 24), **kw), 'cvt3d': lambda **kw: CvT3d(**kw), 'coatnet3d': lambda **kw: CoAtNet3d(**kw), 'vim3d': lambda **kw: Vim3d(**kw)}

class CausalFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoders = nn.ModuleList([backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs) for _ in range(4)])
        dummy = torch.randn(1, 1, 16, 64, 64)
        self.feat_dim = self.encoders[0].forward_features(dummy).shape[-1]
        self.causal_graph = nn.Parameter(torch.zeros(4, 4))
        nn.init.xavier_uniform_(self.causal_graph)
        self.causal_attn = nn.MultiheadAttention(self.feat_dim, num_heads=4, batch_first=True)
        self.intervention_embeds = nn.Parameter(torch.randn(4, self.feat_dim))
        self.gate = nn.Sequential(nn.Linear(4 * self.feat_dim, 4), nn.Softmax(dim=-1))
        self.head = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))

    def forward(self, x):
        feats = torch.stack([enc.forward_features(x[i]) for enc in self.encoders], dim=1)
        causal_mask = torch.sigmoid(self.causal_graph)
        causal_w = causal_mask.softmax(dim=-1)
        intervened = feats + self.intervention_embeds.unsqueeze(0)
        attn = []
        for i in range(4):
            qi = intervened[:, i:i + 1, :]
            ki = intervened * causal_w[i].view(1, 4, 1)
            vi = intervened * causal_w[i].view(1, 4, 1)
            out, _ = self.causal_attn(qi, ki, vi)
            attn.append(out.squeeze(1))
        attn = torch.stack(attn, dim=1)
        gates = self.gate(attn.reshape(attn.shape[0], -1))
        fused = (attn * gates.unsqueeze(-1)).sum(dim=1)
        return self.head(fused)

class CausalFusionV2(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, do_rate=0.3, l1_lambda=0.01):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 1, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.num_modalities = 4
        self.do_rate = do_rate
        self.l1_lambda = l1_lambda
        n_edges = self.num_modalities * (self.num_modalities - 1) // 2
        self.edge_logits = nn.Parameter(torch.randn(n_edges) * 0.1)
        hidden = self.feat_dim // 4
        self.causal_mlps = nn.ModuleList([nn.Sequential(nn.Linear(2 * self.feat_dim, hidden), nn.GELU(), nn.Linear(hidden, self.feat_dim)) for _ in range(n_edges)])
        self.gate = nn.Sequential(nn.Linear(self.num_modalities * self.feat_dim, self.num_modalities * 2), nn.GELU(), nn.Linear(self.num_modalities * 2, self.num_modalities), nn.Softmax(dim=-1))
        self.head = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))

    def _build_adjacency(self, do_intervene: bool=False):
        adj = torch.zeros(self.num_modalities, self.num_modalities, device=self.edge_logits.device, dtype=self.edge_logits.dtype)
        edge_weights = F.softplus(self.edge_logits)
        if do_intervene and self.training:
            mask = torch.bernoulli(torch.full_like(edge_weights, 1 - self.do_rate))
            edge_weights = edge_weights * mask
        idx = 0
        for i in range(self.num_modalities):
            for j in range(i):
                adj[i, j] = edge_weights[idx]
                idx += 1
        row_sum = adj.sum(dim=-1, keepdim=True).clamp(min=1e-08)
        adj = adj / row_sum
        return adj

    def _causal_propagate(self, raw_feats, adj):
        B = raw_feats.shape[0]
        causal_feats = raw_feats.clone()
        idx = 0
        for i in range(1, self.num_modalities):
            parent_signals = []
            for j in range(i):
                if adj[i, j] > 0.01:
                    pair = torch.cat([causal_feats[:, i, :], causal_feats[:, j, :]], dim=-1)
                    signal = self.causal_mlps[idx](pair)
                    parent_signals.append(adj[i, j] * signal)
                idx += 1
            if parent_signals:
                causal_feats[:, i, :] = causal_feats[:, i, :] + torch.stack(parent_signals).sum(dim=0)
        return causal_feats

    def forward(self, x: List[torch.Tensor], return_adj: bool=False):
        raw_feats = []
        for mod_vol in x:
            feat = self.encoder.forward_features(mod_vol)
            raw_feats.append(feat)
        raw_feats = torch.stack(raw_feats, dim=1)
        adj = self._build_adjacency(do_intervene=True)
        causal_feats = self._causal_propagate(raw_feats, adj)
        gates = self.gate(causal_feats.reshape(causal_feats.shape[0], -1))
        fused = (causal_feats * gates.unsqueeze(-1)).sum(dim=1)
        logits = self.head(fused)
        if return_adj:
            return (logits, adj)
        return logits

    def get_l1_loss(self):
        return self.l1_lambda * F.softplus(self.edge_logits).sum()

    def forward_features(self, x: List[torch.Tensor]):
        raw_feats = []
        for mod_vol in x:
            feat = self.encoder.forward_features(mod_vol)
            raw_feats.append(feat)
        raw_feats = torch.stack(raw_feats, dim=1)
        adj = self._build_adjacency(do_intervene=False)
        causal_feats = self._causal_propagate(raw_feats, adj)
        gates = self.gate(causal_feats.reshape(causal_feats.shape[0], -1))
        return (causal_feats * gates.unsqueeze(-1)).sum(dim=1)

class EarlyCausalFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, mod_drop_rate=0.4, consis_weight=0.3):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        self.mod_drop_rate = mod_drop_rate
        self.consis_weight = consis_weight
        self.num_modalities = 4

    def forward(self, x: List[torch.Tensor], mod_drop_mask=None):
        fused = torch.cat(x, dim=1)
        if mod_drop_mask is not None and self.training:
            fused = fused * mod_drop_mask.to(fused.device)
        return self.encoder(fused)

    def sample_drop_mask(self, batch_size, device):
        while True:
            mask = torch.bernoulli(torch.full((batch_size, self.num_modalities, 1, 1, 1), 1 - self.mod_drop_rate, device=device))
            if mask.sum(dim=1).min() > 0:
                return mask

class CausalContrastiveFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, proj_dim=128, temperature=0.07, lambda_contrast=0.3):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 1, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.num_modalities = 4
        self.temperature = temperature
        self.lambda_contrast = lambda_contrast
        self.projection = nn.Sequential(nn.Linear(self.feat_dim, self.feat_dim), nn.BatchNorm1d(self.feat_dim), nn.ReLU(), nn.Linear(self.feat_dim, proj_dim))
        self.classifier = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))

    def encode_modalities(self, x: List[torch.Tensor]):
        raw_feats = []
        for mod_vol in x:
            feat = self.encoder.forward_features(mod_vol)
            raw_feats.append(feat)
        raw_feats = torch.stack(raw_feats, dim=1)
        B = raw_feats.shape[0]
        proj_feats = self.projection(raw_feats.view(B * self.num_modalities, self.feat_dim))
        proj_feats = proj_feats.view(B, self.num_modalities, -1)
        proj_feats = F.normalize(proj_feats, dim=-1)
        return (raw_feats, proj_feats)

    def forward(self, x: List[torch.Tensor], return_proj: bool=False):
        raw_feats, proj_feats = self.encode_modalities(x)
        fused = raw_feats.mean(dim=1)
        logits = self.classifier(fused)
        if return_proj:
            return (logits, proj_feats)
        return logits

    def contrastive_loss(self, proj_feats: torch.Tensor):
        B = proj_feats.shape[0]
        n_pairs = self.num_modalities * (self.num_modalities - 1) // 2
        total_loss = 0.0
        pair_idx = 0
        for i in range(self.num_modalities):
            for j in range(i + 1, self.num_modalities):
                zi = proj_feats[:, i, :]
                zj = proj_feats[:, j, :]
                sim = torch.matmul(zi, zj.T) / self.temperature
                pos = sim.diag()
                loss_ij = -pos + torch.logsumexp(sim, dim=1)
                total_loss += loss_ij.mean()
                pair_idx += 1
        return total_loss / n_pairs

class SequentialRefineFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, modality_order=None, use_auxiliary=True):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=1, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 1, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.num_modalities = 4
        self.modality_order = modality_order or [0, 1, 2, 3]
        self.use_auxiliary = use_auxiliary
        n_refine = self.num_modalities - 1
        self.refine_cells = nn.ModuleList([RefineCell(self.feat_dim) for _ in range(n_refine)])
        self.classifier = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))
        if use_auxiliary:
            self.aux_classifiers = nn.ModuleList([nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, num_classes)) for _ in range(n_refine + 1)])

    def forward(self, x: List[torch.Tensor]):
        order = self.modality_order
        z_all = [self.encoder.forward_features(x[i]) for i in order]
        aux_logits = []
        h = z_all[0]
        if self.use_auxiliary:
            aux_logits.append(self.aux_classifiers[0](h))
        for step in range(1, self.num_modalities):
            h = self.refine_cells[step - 1](h, z_all[step])
            if self.use_auxiliary:
                aux_logits.append(self.aux_classifiers[step](h))
        logits = self.classifier(h)
        return (logits, aux_logits)

class RefineCell(nn.Module):

    def __init__(self, dim):
        super().__init__()
        self.W_r = nn.Linear(2 * dim, dim)
        self.W_u = nn.Linear(2 * dim, dim)
        self.W_c = nn.Linear(2 * dim, dim)
        self.norm = nn.LayerNorm(dim)

    def forward(self, h_prev: torch.Tensor, z_new: torch.Tensor):
        combined = torch.cat([h_prev, z_new], dim=-1)
        r = torch.sigmoid(self.W_r(combined))
        u = torch.sigmoid(self.W_u(combined))
        h_candidate = torch.tanh(self.W_c(torch.cat([h_prev, r * z_new], dim=-1)))
        h_new = (1 - u) * h_prev + u * h_candidate
        return self.norm(h_new)

class AdaptiveFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        self.num_modalities = 4
        self.mod_importance = nn.Sequential(nn.AdaptiveAvgPool3d(1), nn.Flatten(), nn.Linear(4, 4, bias=True), nn.Sigmoid())

    def forward(self, x: List[torch.Tensor]):
        fused = torch.cat(x, dim=1)
        weights = self.mod_importance(fused)
        weights = weights.view(-1, self.num_modalities, 1, 1, 1)
        fused = fused * weights
        return self.encoder(fused)

class CausalInvariantFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, drop_rate=0.35, intervention_ce_weight=0.5, consistency_weight=0.4, feature_weight=0.05, gate_scale=0.25, distill_temperature=2.0):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        self.num_modalities = 4
        self.drop_rate = drop_rate
        self.intervention_ce_weight = intervention_ce_weight
        self.consistency_weight = consistency_weight
        self.feature_weight = feature_weight
        self.gate_scale = gate_scale
        self.distill_temperature = distill_temperature
        self.reliability_gate = nn.Sequential(nn.Linear(self.num_modalities * 2, 16), nn.GELU(), nn.Linear(16, self.num_modalities))
        last = self.reliability_gate[-1]
        nn.init.zeros_(last.weight)
        nn.init.zeros_(last.bias)

    def _modality_stats(self, fused):
        means = fused.mean(dim=(-3, -2, -1))
        stds = fused.std(dim=(-3, -2, -1), unbiased=False)
        return torch.cat([means, stds], dim=1)

    def _apply_reliability_gate(self, fused):
        stats = self._modality_stats(fused)
        delta = torch.tanh(self.reliability_gate(stats))
        scale = 1.0 + self.gate_scale * delta
        return fused * scale.view(-1, self.num_modalities, 1, 1, 1)

    def sample_intervention_mask(self, batch_size, device):
        keep_prob = 1.0 - self.drop_rate
        mask = torch.bernoulli(torch.full((batch_size, self.num_modalities), keep_prob, device=device))
        empty = mask.sum(dim=1) == 0
        if empty.any():
            idx = torch.randint(0, self.num_modalities, (int(empty.sum().item()),), device=device)
            mask[empty] = 0
            mask[empty, idx] = 1
        return mask.view(batch_size, self.num_modalities, 1, 1, 1)

    def forward(self, x: List[torch.Tensor], intervention_mask=None, return_features: bool=False):
        fused = torch.cat(x, dim=1)
        if intervention_mask is not None:
            fused = fused * intervention_mask.to(fused.device)
        fused = self._apply_reliability_gate(fused)
        feats = self.encoder.forward_features(fused)
        logits = self.encoder.head(feats)
        if return_features:
            return (logits, feats)
        return logits

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion):
        logits_full, feats_full = self.forward(x, return_features=True)
        mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        logits_do, feats_do = self.forward(x, intervention_mask=mask, return_features=True)
        loss_full = criterion(logits_full, labels)
        loss_do = criterion(logits_do, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_do / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_do, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        loss = loss_full + self.intervention_ce_weight * loss_do + self.consistency_weight * loss_kl + self.feature_weight * loss_feat
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_do': float(loss_do.detach().cpu()), 'loss_kl': float(loss_kl.detach().cpu()), 'loss_feat': float(loss_feat.detach().cpu())}
        return (logits_full, loss, parts)

    @torch.no_grad()
    def get_intervention_effects(self, x: List[torch.Tensor]):
        base = F.softmax(self.forward(x), dim=-1)
        effects = []
        B = x[0].shape[0]
        for i in range(self.num_modalities):
            mask = torch.ones(B, self.num_modalities, 1, 1, 1, device=x[0].device)
            mask[:, i] = 0
            probs_do = F.softmax(self.forward(x, intervention_mask=mask), dim=-1)
            effects.append(base - probs_do)
        return torch.stack(effects, dim=1)

class CausalMARAFusion(MARAFusion):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, drop_rate=0.25, intervention_ce_weight=0.25, consistency_weight=0.25, feature_weight=0.02, distill_temperature=2.0):
        super().__init__(backbone, num_classes, backbone_kwargs)
        self.drop_rate = drop_rate
        self.intervention_ce_weight = intervention_ce_weight
        self.consistency_weight = consistency_weight
        self.feature_weight = feature_weight
        self.distill_temperature = distill_temperature

    def sample_intervention_mask(self, batch_size, device):
        keep_prob = 1.0 - self.drop_rate
        mask = torch.bernoulli(torch.full((batch_size, self.num_modalities), keep_prob, device=device))
        empty = mask.sum(dim=1) == 0
        if empty.any():
            idx = torch.randint(0, self.num_modalities, (int(empty.sum().item()),), device=device)
            mask[empty] = 0
            mask[empty, idx] = 1
        return mask.view(batch_size, self.num_modalities, 1, 1, 1)

    def forward(self, x: List[torch.Tensor], intervention_mask=None, return_features: bool=False):
        fused = torch.cat(x, dim=1)
        if intervention_mask is not None:
            fused = fused * intervention_mask.to(fused.device)
        feats = self.encoder.forward_features(fused)
        feats_normed = self.pre_attn_norm(feats)
        attn_scores = torch.matmul(feats_normed, self.mod_queries.T) / self.attn_scale
        attn_weights = torch.softmax(attn_scores, dim=-1)
        attended = torch.matmul(attn_weights, self.mod_queries)
        feats = feats + self.gamma * attended
        logits = self.classifier(feats)
        if return_features:
            return (logits, feats)
        return logits

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion):
        logits_full, feats_full = self.forward(x, return_features=True)
        mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        logits_do, feats_do = self.forward(x, intervention_mask=mask, return_features=True)
        loss_full = criterion(logits_full, labels)
        loss_do = criterion(logits_do, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_do / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_do, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        loss = loss_full + self.intervention_ce_weight * loss_do + self.consistency_weight * loss_kl + self.feature_weight * loss_feat
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_do': float(loss_do.detach().cpu()), 'loss_kl': float(loss_kl.detach().cpu()), 'loss_feat': float(loss_feat.detach().cpu())}
        return (logits_full, loss, parts)

    @torch.no_grad()
    def get_intervention_effects(self, x: List[torch.Tensor]):
        base = F.softmax(self.forward(x), dim=-1)
        effects = []
        B = x[0].shape[0]
        for i in range(self.num_modalities):
            mask = torch.ones(B, self.num_modalities, 1, 1, 1, device=x[0].device)
            mask[:, i] = 0
            probs_do = F.softmax(self.forward(x, intervention_mask=mask), dim=-1)
            effects.append(base - probs_do)
        return torch.stack(effects, dim=1)

def _fixed_modality_mask(batch_size: int, values, device, num_modalities: int=4):
    mask = torch.tensor(values, dtype=torch.float32, device=device)
    if mask.numel() != num_modalities:
        raise ValueError(f'Expected {num_modalities} modality mask values, got {mask.numel()}')
    return mask.view(1, num_modalities, 1, 1, 1).expand(batch_size, -1, -1, -1, -1)

class ModalityAvailableCausalInvariantFusion(CausalInvariantFusion):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, drop_rate=0.35, intervention_ce_weight=0.25, consistency_weight=0.2, feature_weight=0.02, gate_scale=0.25, distill_temperature=2.0, t2_only_ce_weight=0.45, t2_only_consistency_weight=0.3, t2_only_feature_weight=0.02):
        super().__init__(backbone=backbone, num_classes=num_classes, backbone_kwargs=backbone_kwargs, drop_rate=drop_rate, intervention_ce_weight=intervention_ce_weight, consistency_weight=consistency_weight, feature_weight=feature_weight, gate_scale=gate_scale, distill_temperature=distill_temperature)
        self.t2_only_ce_weight = t2_only_ce_weight
        self.t2_only_consistency_weight = t2_only_consistency_weight
        self.t2_only_feature_weight = t2_only_feature_weight

    def _masked_losses(self, x, labels, criterion, logits_full, feats_full, mask, ce_weight, consistency_weight, feature_weight):
        logits_masked, feats_masked = self.forward(x, intervention_mask=mask, return_features=True)
        loss_ce = criterion(logits_masked, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_masked / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_masked, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        loss = ce_weight * loss_ce + consistency_weight * loss_kl + feature_weight * loss_feat
        return (logits_masked, feats_masked, loss, {'ce': loss_ce, 'kl': loss_kl, 'feat': loss_feat})

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion):
        logits_full, feats_full = self.forward(x, return_features=True)
        loss_full = criterion(logits_full, labels)
        random_mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        _, _, loss_random, parts_random = self._masked_losses(x, labels, criterion, logits_full, feats_full, random_mask, self.intervention_ce_weight, self.consistency_weight, self.feature_weight)
        t2_mask = _fixed_modality_mask(labels.shape[0], [1, 0, 0, 0], labels.device, self.num_modalities)
        _, _, loss_t2, parts_t2 = self._masked_losses(x, labels, criterion, logits_full, feats_full, t2_mask, self.t2_only_ce_weight, self.t2_only_consistency_weight, self.t2_only_feature_weight)
        loss = loss_full + loss_random + loss_t2
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_random_ce': float(parts_random['ce'].detach().cpu()), 'loss_random_kl': float(parts_random['kl'].detach().cpu()), 'loss_random_feat': float(parts_random['feat'].detach().cpu()), 'loss_t2_ce': float(parts_t2['ce'].detach().cpu()), 'loss_t2_kl': float(parts_t2['kl'].detach().cpu()), 'loss_t2_feat': float(parts_t2['feat'].detach().cpu())}
        return (logits_full, loss, parts)

class ModalityAvailableCausalMARAFusion(CausalMARAFusion):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, drop_rate=0.25, intervention_ce_weight=0.2, consistency_weight=0.18, feature_weight=0.01, distill_temperature=2.0, t2_only_ce_weight=0.45, t2_only_consistency_weight=0.3, t2_only_feature_weight=0.02):
        super().__init__(backbone=backbone, num_classes=num_classes, backbone_kwargs=backbone_kwargs, drop_rate=drop_rate, intervention_ce_weight=intervention_ce_weight, consistency_weight=consistency_weight, feature_weight=feature_weight, distill_temperature=distill_temperature)
        self.t2_only_ce_weight = t2_only_ce_weight
        self.t2_only_consistency_weight = t2_only_consistency_weight
        self.t2_only_feature_weight = t2_only_feature_weight

    def _masked_losses(self, x, labels, criterion, logits_full, feats_full, mask, ce_weight, consistency_weight, feature_weight):
        logits_masked, feats_masked = self.forward(x, intervention_mask=mask, return_features=True)
        loss_ce = criterion(logits_masked, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_masked / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_masked, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        loss = ce_weight * loss_ce + consistency_weight * loss_kl + feature_weight * loss_feat
        return (logits_masked, feats_masked, loss, {'ce': loss_ce, 'kl': loss_kl, 'feat': loss_feat})

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion):
        logits_full, feats_full = self.forward(x, return_features=True)
        loss_full = criterion(logits_full, labels)
        random_mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        _, _, loss_random, parts_random = self._masked_losses(x, labels, criterion, logits_full, feats_full, random_mask, self.intervention_ce_weight, self.consistency_weight, self.feature_weight)
        t2_mask = _fixed_modality_mask(labels.shape[0], [1, 0, 0, 0], labels.device, self.num_modalities)
        _, _, loss_t2, parts_t2 = self._masked_losses(x, labels, criterion, logits_full, feats_full, t2_mask, self.t2_only_ce_weight, self.t2_only_consistency_weight, self.t2_only_feature_weight)
        loss = loss_full + loss_random + loss_t2
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_random_ce': float(parts_random['ce'].detach().cpu()), 'loss_random_kl': float(parts_random['kl'].detach().cpu()), 'loss_random_feat': float(parts_random['feat'].detach().cpu()), 'loss_t2_ce': float(parts_t2['ce'].detach().cpu()), 'loss_t2_kl': float(parts_t2['kl'].detach().cpu()), 'loss_t2_feat': float(parts_t2['feat'].detach().cpu())}
        return (logits_full, loss, parts)

class OrdinalCausalMARAFusion(CausalMARAFusion):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, drop_rate=0.2, intervention_ce_weight=0.2, consistency_weight=0.2, feature_weight=0.01, aux_state_weight=0.15, aux_node_weight=0.0, aux_node_classes=2, supcon_weight=0.02, distill_temperature=2.0, supcon_temperature=0.12):
        super().__init__(backbone=backbone, num_classes=num_classes, backbone_kwargs=backbone_kwargs, drop_rate=drop_rate, intervention_ce_weight=intervention_ce_weight, consistency_weight=consistency_weight, feature_weight=feature_weight, distill_temperature=distill_temperature)
        self.num_classes = num_classes
        self.aux_state_weight = aux_state_weight
        self.aux_node_weight = aux_node_weight
        self.aux_node_classes = max(2, int(aux_node_classes))
        self.supcon_weight = supcon_weight
        self.supcon_temperature = supcon_temperature
        self.use_state_aux = self.num_classes == 2 and self.aux_state_weight > 0
        self.use_node_aux = self.num_classes == 2 and self.aux_node_weight > 0
        if self.use_state_aux:
            self.state_head = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 4), nn.GELU(), nn.Dropout(0.2), nn.Linear(self.feat_dim // 4, 3))
        else:
            self.state_head = None
        self.node_head = self._make_aux_head(self.feat_dim, self.aux_node_classes) if self.use_node_aux else None

    def _make_aux_head(self, input_dim, out_dim):
        hidden = max(16, self.feat_dim // 4)
        return nn.Sequential(nn.LayerNorm(input_dim), nn.Linear(input_dim, hidden), nn.GELU(), nn.Dropout(0.2), nn.Linear(hidden, out_dim))

    def _node_aux_loss(self, feats_full, feats_do=None, node_labels: Optional[torch.Tensor]=None, node_mask: Optional[torch.Tensor]=None):
        zero = feats_full.sum() * 0.0
        if not self.use_node_aux or self.node_head is None or node_labels is None:
            return zero
        targets = node_labels.long().to(feats_full.device)
        if node_mask is None:
            valid = targets >= 0
        else:
            valid = node_mask.to(feats_full.device).bool() & (targets >= 0)
        if not valid.any():
            return zero
        targets = targets.clamp(0, self.aux_node_classes - 1)
        loss = F.cross_entropy(self.node_head(feats_full)[valid], targets[valid])
        if feats_do is not None:
            loss = loss + 0.5 * F.cross_entropy(self.node_head(feats_do)[valid], targets[valid])
        return loss

    def supervised_contrastive_loss(self, feats, labels):
        B = feats.shape[0]
        if B < 2:
            return feats.sum() * 0.0
        z = F.normalize(feats, dim=-1)
        logits = torch.matmul(z, z.T) / self.supcon_temperature
        logits = logits - logits.max(dim=1, keepdim=True).values.detach()
        labels = labels.view(-1, 1)
        pos_mask = torch.eq(labels, labels.T).float().to(feats.device)
        self_mask = torch.eye(B, device=feats.device, dtype=pos_mask.dtype)
        logits_mask = 1.0 - self_mask
        pos_mask = pos_mask * logits_mask
        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(dim=1, keepdim=True).clamp_min(1e-08))
        pos_count = pos_mask.sum(dim=1)
        valid = pos_count > 0
        if not valid.any():
            return feats.sum() * 0.0
        return (-(pos_mask * log_prob).sum(dim=1)[valid] / pos_count[valid]).mean()

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion, states: Optional[torch.Tensor]=None, node_labels: Optional[torch.Tensor]=None, node_mask: Optional[torch.Tensor]=None):
        logits_full, feats_full = self.forward(x, return_features=True)
        mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        logits_do, feats_do = self.forward(x, intervention_mask=mask, return_features=True)
        loss_full = criterion(logits_full, labels)
        loss_do = criterion(logits_do, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_do / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_do, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        if states is not None:
            contrast_targets = states.long().clamp(1, 3) - 1
        else:
            contrast_targets = labels
        loss_supcon = self.supervised_contrastive_loss(feats_full, contrast_targets)
        loss = loss_full + self.intervention_ce_weight * loss_do + self.consistency_weight * loss_kl + self.feature_weight * loss_feat + self.supcon_weight * loss_supcon
        loss_aux = feats_full.sum() * 0.0
        if self.use_state_aux and states is not None and (self.state_head is not None):
            state_targets = states.long().clamp(1, 3) - 1
            aux_full = self.state_head(feats_full)
            aux_do = self.state_head(feats_do)
            loss_aux = F.cross_entropy(aux_full, state_targets)
            loss_aux = loss_aux + 0.5 * F.cross_entropy(aux_do, state_targets)
            loss = loss + self.aux_state_weight * loss_aux
        loss_node = self._node_aux_loss(feats_full, feats_do, node_labels=node_labels, node_mask=node_mask)
        loss = loss + self.aux_node_weight * loss_node
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_do': float(loss_do.detach().cpu()), 'loss_kl': float(loss_kl.detach().cpu()), 'loss_feat': float(loss_feat.detach().cpu()), 'loss_supcon': float(loss_supcon.detach().cpu()), 'loss_aux': float(loss_aux.detach().cpu()), 'loss_node': float(loss_node.detach().cpu())}
        return (logits_full, loss, parts)

class GeometryAwareMARAFusion(OrdinalCausalMARAFusion):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, tab_dim=0, tab_hidden=96, drop_rate=0.15, intervention_ce_weight=0.15, consistency_weight=0.15, feature_weight=0.01, aux_state_weight=0.12, aux_node_weight=0.0, aux_node_classes=2, supcon_weight=0.015, distill_temperature=2.0, supcon_temperature=0.12):
        if tab_dim <= 0:
            raise ValueError('GeometryAwareMARAFusion requires tab_dim > 0')
        super().__init__(backbone=backbone, num_classes=num_classes, backbone_kwargs=backbone_kwargs, drop_rate=drop_rate, intervention_ce_weight=intervention_ce_weight, consistency_weight=consistency_weight, feature_weight=feature_weight, aux_state_weight=aux_state_weight, aux_node_weight=aux_node_weight, aux_node_classes=aux_node_classes, supcon_weight=supcon_weight, distill_temperature=distill_temperature, supcon_temperature=supcon_temperature)
        self.tab_dim = tab_dim
        self.tab_hidden = tab_hidden
        self.tab_encoder = nn.Sequential(nn.LayerNorm(tab_dim), nn.Linear(tab_dim, tab_hidden), nn.GELU(), nn.Dropout(0.15), nn.Linear(tab_hidden, tab_hidden), nn.GELU())
        fused_dim = self.feat_dim + tab_hidden
        self.classifier = nn.Sequential(nn.LayerNorm(fused_dim), nn.Linear(fused_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))
        if self.use_state_aux:
            self.state_head = nn.Sequential(nn.LayerNorm(fused_dim), nn.Linear(fused_dim, self.feat_dim // 4), nn.GELU(), nn.Dropout(0.2), nn.Linear(self.feat_dim // 4, 3))
        if self.use_node_aux:
            self.node_head = self._make_aux_head(fused_dim, self.aux_node_classes)

    def _image_features(self, x: List[torch.Tensor], intervention_mask=None):
        fused = torch.cat(x, dim=1)
        if intervention_mask is not None:
            fused = fused * intervention_mask.to(fused.device)
        feats = self.encoder.forward_features(fused)
        feats_normed = self.pre_attn_norm(feats)
        attn_scores = torch.matmul(feats_normed, self.mod_queries.T) / self.attn_scale
        attn_weights = torch.softmax(attn_scores, dim=-1)
        attended = torch.matmul(attn_weights, self.mod_queries)
        return feats + self.gamma * attended

    def _fuse_tabular(self, image_feats, tabular):
        if tabular is None:
            tabular = image_feats.new_zeros(image_feats.shape[0], self.tab_dim)
        tab_feats = self.tab_encoder(tabular.to(image_feats.device, dtype=image_feats.dtype))
        return torch.cat([image_feats, tab_feats], dim=-1)

    def forward(self, x: List[torch.Tensor], tabular=None, intervention_mask=None, return_features: bool=False):
        image_feats = self._image_features(x, intervention_mask=intervention_mask)
        feats = self._fuse_tabular(image_feats, tabular)
        logits = self.classifier(feats)
        if return_features:
            return (logits, feats)
        return logits

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion, states: Optional[torch.Tensor]=None, tabular=None, node_labels: Optional[torch.Tensor]=None, node_mask: Optional[torch.Tensor]=None):
        logits_full, feats_full = self.forward(x, tabular=tabular, return_features=True)
        mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        logits_do, feats_do = self.forward(x, tabular=tabular, intervention_mask=mask, return_features=True)
        loss_full = criterion(logits_full, labels)
        loss_do = criterion(logits_do, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_do / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_do, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        contrast_targets = states.long().clamp(1, 3) - 1 if states is not None else labels
        loss_supcon = self.supervised_contrastive_loss(feats_full, contrast_targets)
        loss = loss_full + self.intervention_ce_weight * loss_do + self.consistency_weight * loss_kl + self.feature_weight * loss_feat + self.supcon_weight * loss_supcon
        loss_aux = feats_full.sum() * 0.0
        if self.use_state_aux and states is not None and (self.state_head is not None):
            state_targets = states.long().clamp(1, 3) - 1
            aux_full = self.state_head(feats_full)
            aux_do = self.state_head(feats_do)
            loss_aux = F.cross_entropy(aux_full, state_targets)
            loss_aux = loss_aux + 0.5 * F.cross_entropy(aux_do, state_targets)
            loss = loss + self.aux_state_weight * loss_aux
        loss_node = self._node_aux_loss(feats_full, feats_do, node_labels=node_labels, node_mask=node_mask)
        loss = loss + self.aux_node_weight * loss_node
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_do': float(loss_do.detach().cpu()), 'loss_kl': float(loss_kl.detach().cpu()), 'loss_feat': float(loss_feat.detach().cpu()), 'loss_supcon': float(loss_supcon.detach().cpu()), 'loss_aux': float(loss_aux.detach().cpu()), 'loss_node': float(loss_node.detach().cpu())}
        return (logits_full, loss, parts)

class LightMonoEncoder(nn.Module):

    def __init__(self, out_dim=128):
        super().__init__()
        self.net = nn.Sequential(nn.Conv3d(1, 16, kernel_size=(3, 5, 5), stride=(1, 2, 2), padding=(1, 2, 2), bias=False), nn.BatchNorm3d(16), nn.GELU(), nn.Conv3d(16, 32, kernel_size=3, stride=(2, 2, 2), padding=1, bias=False), nn.BatchNorm3d(32), nn.GELU(), nn.Conv3d(32, 64, kernel_size=3, stride=(2, 2, 2), padding=1, bias=False), nn.BatchNorm3d(64), nn.GELU(), nn.AdaptiveAvgPool3d(1), nn.Flatten(), nn.Linear(64, out_dim), nn.GELU())

    def forward(self, x):
        return self.net(x)

class TriPathGeometryMARAFusion(GeometryAwareMARAFusion):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, tab_dim=0, tab_hidden=96, mono_dim=128, drop_rate=0.12, intervention_ce_weight=0.12, consistency_weight=0.12, feature_weight=0.01, aux_state_weight=0.1, supcon_weight=0.01, mono_consistency_weight=0.02, distill_temperature=2.0, supcon_temperature=0.12):
        super().__init__(backbone=backbone, num_classes=num_classes, backbone_kwargs=backbone_kwargs, tab_dim=tab_dim, tab_hidden=tab_hidden, drop_rate=drop_rate, intervention_ce_weight=intervention_ce_weight, consistency_weight=consistency_weight, feature_weight=feature_weight, aux_state_weight=aux_state_weight, supcon_weight=supcon_weight, distill_temperature=distill_temperature, supcon_temperature=supcon_temperature)
        self.mono_dim = mono_dim
        self.mono_consistency_weight = mono_consistency_weight
        self.mono_encoder = LightMonoEncoder(out_dim=mono_dim)
        self.mono_gate = nn.Sequential(nn.LayerNorm(self.feat_dim + self.tab_hidden + self.num_modalities * mono_dim), nn.Linear(self.feat_dim + self.tab_hidden + self.num_modalities * mono_dim, 64), nn.GELU(), nn.Linear(64, self.num_modalities), nn.Softmax(dim=-1))
        fused_dim = self.feat_dim + self.tab_hidden + mono_dim
        self.classifier = nn.Sequential(nn.LayerNorm(fused_dim), nn.Linear(fused_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))
        if self.use_state_aux:
            self.state_head = nn.Sequential(nn.LayerNorm(fused_dim), nn.Linear(fused_dim, self.feat_dim // 4), nn.GELU(), nn.Dropout(0.2), nn.Linear(self.feat_dim // 4, 3))

    def _mono_features(self, x: List[torch.Tensor], intervention_mask=None):
        mono = []
        for i, vol in enumerate(x):
            if intervention_mask is not None:
                vol = vol * intervention_mask[:, i:i + 1].to(vol.device)
            mono.append(self.mono_encoder(vol))
        return torch.stack(mono, dim=1)

    def _tri_features(self, x: List[torch.Tensor], tabular=None, intervention_mask=None):
        image_feats = self._image_features(x, intervention_mask=intervention_mask)
        if tabular is None:
            tabular = image_feats.new_zeros(image_feats.shape[0], self.tab_dim)
        tab_feats = self.tab_encoder(tabular.to(image_feats.device, dtype=image_feats.dtype))
        mono_feats = self._mono_features(x, intervention_mask=intervention_mask)
        gate_input = torch.cat([image_feats, tab_feats, mono_feats.flatten(1)], dim=-1)
        mono_weights = self.mono_gate(gate_input)
        mono_fused = (mono_feats * mono_weights.unsqueeze(-1)).sum(dim=1)
        fused = torch.cat([image_feats, tab_feats, mono_fused], dim=-1)
        return (fused, image_feats, mono_fused, mono_weights)

    def forward(self, x: List[torch.Tensor], tabular=None, intervention_mask=None, return_features: bool=False):
        feats, _, _, _ = self._tri_features(x, tabular=tabular, intervention_mask=intervention_mask)
        logits = self.classifier(feats)
        if return_features:
            return (logits, feats)
        return logits

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion, states: Optional[torch.Tensor]=None, tabular=None):
        feats_full, image_full, mono_full, gate_full = self._tri_features(x, tabular=tabular)
        logits_full = self.classifier(feats_full)
        mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        feats_do, image_do, mono_do, gate_do = self._tri_features(x, tabular=tabular, intervention_mask=mask)
        logits_do = self.classifier(feats_do)
        loss_full = criterion(logits_full, labels)
        loss_do = criterion(logits_do, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_do / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_do, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        loss_mono = F.mse_loss(F.normalize(mono_do, dim=-1), F.normalize(mono_full.detach(), dim=-1))
        contrast_targets = states.long().clamp(1, 3) - 1 if states is not None else labels
        loss_supcon = self.supervised_contrastive_loss(feats_full, contrast_targets)
        loss = loss_full + self.intervention_ce_weight * loss_do + self.consistency_weight * loss_kl + self.feature_weight * loss_feat + self.mono_consistency_weight * loss_mono + self.supcon_weight * loss_supcon
        loss_aux = feats_full.sum() * 0.0
        if self.use_state_aux and states is not None and (self.state_head is not None):
            state_targets = states.long().clamp(1, 3) - 1
            aux_full = self.state_head(feats_full)
            aux_do = self.state_head(feats_do)
            loss_aux = F.cross_entropy(aux_full, state_targets)
            loss_aux = loss_aux + 0.5 * F.cross_entropy(aux_do, state_targets)
            loss = loss + self.aux_state_weight * loss_aux
        gate_entropy = -(gate_full * torch.log(gate_full.clamp_min(1e-08))).sum(dim=1).mean()
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_do': float(loss_do.detach().cpu()), 'loss_kl': float(loss_kl.detach().cpu()), 'loss_feat': float(loss_feat.detach().cpu()), 'loss_mono': float(loss_mono.detach().cpu()), 'loss_supcon': float(loss_supcon.detach().cpu()), 'loss_aux': float(loss_aux.detach().cpu()), 'gate_entropy': float(gate_entropy.detach().cpu())}
        return (logits_full, loss, parts)

class CausalQualityOrdinalFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, drop_rate=0.3, intervention_ce_weight=0.35, consistency_weight=0.3, feature_weight=0.03, aux_state_weight=0.2, supcon_weight=0.04, gate_scale=0.3, distill_temperature=2.0, supcon_temperature=0.12):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        self.num_modalities = 4
        self.num_classes = num_classes
        self.drop_rate = drop_rate
        self.intervention_ce_weight = intervention_ce_weight
        self.consistency_weight = consistency_weight
        self.feature_weight = feature_weight
        self.aux_state_weight = aux_state_weight
        self.supcon_weight = supcon_weight
        self.gate_scale = gate_scale
        self.distill_temperature = distill_temperature
        self.supcon_temperature = supcon_temperature
        with torch.no_grad():
            dummy = torch.randn(1, 4, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.quality_gate = nn.Sequential(nn.Linear(self.num_modalities * 3, 24), nn.GELU(), nn.Dropout(0.1), nn.Linear(24, self.num_modalities))
        last = self.quality_gate[-1]
        nn.init.zeros_(last.weight)
        nn.init.zeros_(last.bias)
        self.use_state_aux = self.num_classes == 2 and self.aux_state_weight > 0
        if self.use_state_aux:
            self.state_head = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 4), nn.GELU(), nn.Dropout(0.2), nn.Linear(self.feat_dim // 4, 3))
        else:
            self.state_head = None

    def _modality_stats(self, fused):
        means = fused.mean(dim=(-3, -2, -1))
        stds = fused.std(dim=(-3, -2, -1), unbiased=False)
        rms = fused.square().mean(dim=(-3, -2, -1)).sqrt()
        return torch.cat([means, stds, rms], dim=1)

    def _apply_quality_gate(self, fused):
        stats = self._modality_stats(fused)
        delta = torch.tanh(self.quality_gate(stats))
        scale = 1.0 + self.gate_scale * delta
        return fused * scale.view(-1, self.num_modalities, 1, 1, 1)

    def sample_intervention_mask(self, batch_size, device):
        keep_prob = 1.0 - self.drop_rate
        mask = torch.bernoulli(torch.full((batch_size, self.num_modalities), keep_prob, device=device))
        empty = mask.sum(dim=1) == 0
        if empty.any():
            idx = torch.randint(0, self.num_modalities, (int(empty.sum().item()),), device=device)
            mask[empty] = 0
            mask[empty, idx] = 1
        return mask.view(batch_size, self.num_modalities, 1, 1, 1)

    def forward(self, x: List[torch.Tensor], intervention_mask=None, return_features: bool=False, return_aux: bool=False):
        fused = torch.cat(x, dim=1)
        if intervention_mask is not None:
            fused = fused * intervention_mask.to(fused.device)
        fused = self._apply_quality_gate(fused)
        feats = self.encoder.forward_features(fused)
        logits = self.encoder.head(feats)
        aux_logits = self.state_head(feats) if self.state_head is not None else None
        outputs = [logits]
        if return_features:
            outputs.append(feats)
        if return_aux:
            outputs.append(aux_logits)
        if len(outputs) == 1:
            return logits
        return tuple(outputs)

    def supervised_contrastive_loss(self, feats, labels):
        B = feats.shape[0]
        if B < 2:
            return feats.sum() * 0.0
        z = F.normalize(feats, dim=-1)
        logits = torch.matmul(z, z.T) / self.supcon_temperature
        logits = logits - logits.max(dim=1, keepdim=True).values.detach()
        labels = labels.view(-1, 1)
        pos_mask = torch.eq(labels, labels.T).float().to(feats.device)
        self_mask = torch.eye(B, device=feats.device, dtype=pos_mask.dtype)
        logits_mask = 1.0 - self_mask
        pos_mask = pos_mask * logits_mask
        exp_logits = torch.exp(logits) * logits_mask
        log_prob = logits - torch.log(exp_logits.sum(dim=1, keepdim=True).clamp_min(1e-08))
        pos_count = pos_mask.sum(dim=1)
        valid = pos_count > 0
        if not valid.any():
            return feats.sum() * 0.0
        loss = -(pos_mask * log_prob).sum(dim=1)[valid] / pos_count[valid]
        return loss.mean()

    def causal_loss(self, x: List[torch.Tensor], labels: torch.Tensor, criterion, states: Optional[torch.Tensor]=None):
        logits_full, feats_full, aux_full = self.forward(x, return_features=True, return_aux=True)
        mask = self.sample_intervention_mask(labels.shape[0], labels.device)
        logits_do, feats_do, aux_do = self.forward(x, intervention_mask=mask, return_features=True, return_aux=True)
        loss_full = criterion(logits_full, labels)
        loss_do = criterion(logits_do, labels)
        temp = self.distill_temperature
        target = F.softmax(logits_full.detach() / temp, dim=-1)
        loss_kl = F.kl_div(F.log_softmax(logits_do / temp, dim=-1), target, reduction='batchmean') * (temp * temp)
        loss_feat = F.mse_loss(F.normalize(feats_do, dim=-1), F.normalize(feats_full.detach(), dim=-1))
        loss_supcon = self.supervised_contrastive_loss(feats_full, labels)
        loss = loss_full + self.intervention_ce_weight * loss_do + self.consistency_weight * loss_kl + self.feature_weight * loss_feat + self.supcon_weight * loss_supcon
        loss_aux = feats_full.sum() * 0.0
        if self.use_state_aux and states is not None and (aux_full is not None):
            state_targets = states.long().clamp(1, 3) - 1
            loss_aux = F.cross_entropy(aux_full, state_targets)
            if aux_do is not None:
                loss_aux = loss_aux + 0.5 * F.cross_entropy(aux_do, state_targets)
            loss = loss + self.aux_state_weight * loss_aux
        parts = {'loss_full': float(loss_full.detach().cpu()), 'loss_do': float(loss_do.detach().cpu()), 'loss_kl': float(loss_kl.detach().cpu()), 'loss_feat': float(loss_feat.detach().cpu()), 'loss_supcon': float(loss_supcon.detach().cpu()), 'loss_aux': float(loss_aux.detach().cpu())}
        return (logits_full, loss, parts)

    @torch.no_grad()
    def get_intervention_effects(self, x: List[torch.Tensor]):
        base = F.softmax(self.forward(x), dim=-1)
        effects = []
        B = x[0].shape[0]
        for i in range(self.num_modalities):
            mask = torch.ones(B, self.num_modalities, 1, 1, 1, device=x[0].device)
            mask[:, i] = 0
            probs_do = F.softmax(self.forward(x, intervention_mask=mask), dim=-1)
            effects.append(base - probs_do)
        return torch.stack(effects, dim=1)
FUSION_STRATEGIES = {'early': EarlyFusion, 'adaptive': AdaptiveFusion, 'early_causal': EarlyCausalFusion, 'late': LateFusion, 'crossattn': CrossAttnFusion, 'gated': GatedFusion, 'causal': CausalFusion, 'causal_v2': CausalFusionV2, 'causal_contrast': CausalContrastiveFusion, 'causal_invariant': CausalInvariantFusion, 'cif': CausalInvariantFusion, 'causal_mara': CausalMARAFusion, 'cmara': CausalMARAFusion, 'ma_cif': ModalityAvailableCausalInvariantFusion, 'ma_cmara': ModalityAvailableCausalMARAFusion, 'ordinal_mara': OrdinalCausalMARAFusion, 'omara': OrdinalCausalMARAFusion, 'geometry_mara': GeometryAwareMARAFusion, 'gmara': GeometryAwareMARAFusion, 'tripath_mara': TriPathGeometryMARAFusion, 'tmara': TriPathGeometryMARAFusion, 'causal_quality': CausalQualityOrdinalFusion, 'cqof': CausalQualityOrdinalFusion, 'sequential': SequentialRefineFusion, 'cgcmr': CGCMRFusion, 'mara': MARAFusion, 'marav2': MARAv2Fusion, 'mdn': MDNFusion}

def get_model(name, in_chans=1, num_classes=3):
    return MODELS[name](in_chans=in_chans, num_classes=num_classes)

def get_fusion(strategy, backbone_name, num_classes=3, **fusion_kwargs):
    backbone = MODELS[backbone_name]
    return FUSION_STRATEGIES[strategy](backbone, num_classes, **fusion_kwargs)

def get_fusion_v2(backbone_name, num_classes=3, do_rate=0.3, l1_lambda=0.01):
    return CausalFusionV2(MODELS[backbone_name], num_classes, do_rate=do_rate, l1_lambda=l1_lambda)

def count_params(model):
    return sum((p.numel() for p in model.parameters() if p.requires_grad))
if __name__ == '__main__':
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f'Device: {device}\n')
    for name in MODELS:
        for ch, desc in [(1, '1ch'), (4, '4ch')]:
            for nc, lbl in [(2, '2cls'), (3, '3cls')]:
                try:
                    m = get_model(name, in_chans=ch, num_classes=nc).to(device)
                    x = torch.randn(2, ch, 16, 64, 64).to(device)
                    y = m(x)
                    print(f'  {name:25s} {desc} {lbl}  params={count_params(m) / 1000000.0:.1f}M  OK')
                except Exception as e:
                    print(f'  {name:25s} {desc} {lbl}  FAIL: {str(e)[:80]}')
    print('\n=== Fusion Strategies ===')
    for strat in ['early', 'late', 'crossattn', 'gated']:
        for nc in [2, 3]:
            try:
                m = get_fusion(strat, 'convnext3d_tiny', nc).to(device)
                x = [torch.randn(2, 1, 16, 64, 64).to(device) for _ in range(4)]
                y = m(x)
                print(f'  {strat:12s} convnext3d_tiny {nc}cls  OK')
            except Exception as e:
                print(f'  {strat:12s} convnext3d_tiny {nc}cls  FAIL: {str(e)[:80]}')
    print('\nAll tests complete!')
