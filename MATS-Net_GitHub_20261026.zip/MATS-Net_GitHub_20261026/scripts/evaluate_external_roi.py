from __future__ import annotations
import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, List
import nibabel as nib
import numpy as np
import pandas as pd
import torch
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from torch.utils.data import DataLoader, Dataset
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import get_model

class ExternalROIDataset(Dataset):

    def __init__(self, roi_dir: str, index_csv: str, modalities: List[str]):
        self.roi_dir = roi_dir
        self.df = pd.read_csv(index_csv)
        self.df['id'] = self.df['id'].astype(str)
        self.modalities = modalities

    def __len__(self) -> int:
        return len(self.df)

    def __getitem__(self, idx: int) -> Dict[str, object]:
        row = self.df.iloc[idx]
        pid = str(row['id'])
        channels = []
        for modality in self.modalities:
            path = os.path.join(self.roi_dir, pid, f'{modality}.nii.gz')
            data = nib.load(path).get_fdata().astype(np.float32)
            data = np.transpose(data, (2, 0, 1))
            vmin, vmax = (float(data.min()), float(data.max()))
            if vmax > vmin:
                data = (data - vmin) / (vmax - vmin)
            channels.append(torch.from_numpy(data).unsqueeze(0))
        tensor = torch.cat(channels, dim=0)
        return {'pid': pid, 'volume': tensor, 'label': int(row['label'])}

def collate(batch: List[Dict[str, object]]) -> Dict[str, object]:
    return {'pid': [item['pid'] for item in batch], 'volume': torch.stack([item['volume'] for item in batch], dim=0), 'label': torch.tensor([item['label'] for item in batch], dtype=torch.long)}

def find_fold_checkpoints(model_dir: str) -> List[str]:
    paths = sorted(Path(model_dir).glob('fold_*/best_model.pth'))
    if not paths:
        raise FileNotFoundError(f'No fold_*/best_model.pth found under {model_dir}')
    return [str(p) for p in paths]

def load_state(path: str, device: torch.device) -> Dict[str, torch.Tensor]:
    state = torch.load(path, map_location=device)
    if isinstance(state, dict) and 'state_dict' in state:
        state = state['state_dict']
    if isinstance(state, dict) and any((k.startswith('module.') for k in state)):
        state = {k.replace('module.', '', 1): v for k, v in state.items()}
    return state

def metrics_from_prob(y_true: np.ndarray, prob: np.ndarray, threshold: float=0.5) -> Dict[str, object]:
    pred = (prob >= threshold).astype(int)
    cm = confusion_matrix(y_true, pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    out = {'auc': float(roc_auc_score(y_true, prob)) if len(np.unique(y_true)) == 2 else None, 'accuracy': float(accuracy_score(y_true, pred)), 'precision': float(precision_score(y_true, pred, zero_division=0)), 'recall': float(recall_score(y_true, pred, zero_division=0)), 'sensitivity': float(tp / (tp + fn)) if tp + fn else None, 'specificity': float(tn / (tn + fp)) if tn + fp else None, 'f1': float(f1_score(y_true, pred, zero_division=0)), 'brier': float(brier_score_loss(y_true, prob)), 'threshold': float(threshold), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}
    return out

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', required=True)
    parser.add_argument('--roi-dir', required=True)
    parser.add_argument('--index-csv', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--model-name', default='convnext3d_tiny')
    parser.add_argument('--modality', default='T2W')
    parser.add_argument('--modalities', nargs='+', default=None)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--num-workers', type=int, default=2)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device if args.device == 'cpu' or torch.cuda.is_available() else 'cpu')
    modalities = args.modalities or [args.modality]
    ds = ExternalROIDataset(args.roi_dir, args.index_csv, modalities)
    loader = DataLoader(ds, batch_size=args.batch_size, shuffle=False, num_workers=args.num_workers, collate_fn=collate)
    checkpoints = find_fold_checkpoints(args.model_dir)
    y_true = ds.df['label'].astype(int).to_numpy()
    pred_frame = pd.DataFrame({'pid': ds.df['id'].astype(str), 'label': y_true})
    fold_metrics = []
    for fold_idx, ckpt in enumerate(checkpoints, start=1):
        model = get_model(args.model_name, in_chans=len(modalities), num_classes=2).to(device)
        model.load_state_dict(load_state(ckpt, device), strict=True)
        model.eval()
        probs: List[float] = []
        with torch.no_grad():
            for batch in loader:
                volume = batch['volume'].to(device)
                logits = model(volume)
                prob = torch.softmax(logits, dim=1)[:, 1].detach().cpu().numpy()
                probs.extend(prob.tolist())
        prob_arr = np.asarray(probs, dtype=np.float32)
        pred_frame[f'fold_{fold_idx}_prob'] = prob_arr
        fold_result = metrics_from_prob(y_true, prob_arr)
        fold_result['fold'] = fold_idx
        fold_result['checkpoint'] = ckpt
        fold_metrics.append(fold_result)
    fold_cols = [c for c in pred_frame.columns if c.endswith('_prob')]
    pred_frame['ensemble_prob'] = pred_frame[fold_cols].mean(axis=1)
    pred_frame['ensemble_pred_0p5'] = (pred_frame['ensemble_prob'] >= 0.5).astype(int)
    ensemble_metrics = metrics_from_prob(y_true, pred_frame['ensemble_prob'].to_numpy())
    pred_path = os.path.join(args.output_dir, 'external_predictions.csv')
    pred_frame.to_csv(pred_path, index=False)
    pd.DataFrame(fold_metrics).to_csv(os.path.join(args.output_dir, 'fold_metrics.csv'), index=False)
    summary = {'model_dir': args.model_dir, 'roi_dir': args.roi_dir, 'index_csv': args.index_csv, 'model_name': args.model_name, 'modalities': modalities, 'device': str(device), 'n': int(len(ds)), 'label_counts': {str(k): int(v) for k, v in ds.df['label'].value_counts().sort_index().items()}, 'checkpoints': checkpoints, 'ensemble_metrics': ensemble_metrics, 'fold_metrics': fold_metrics, 'predictions_csv': pred_path}
    with open(os.path.join(args.output_dir, 'external_eval_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
