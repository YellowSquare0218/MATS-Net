from __future__ import annotations
import argparse
import json
import os
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import StratifiedShuffleSplit
from torch.utils.data import DataLoader
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import adapt_external_holdout_t2 as holdout
from adapt_external_t2_full_oof import freeze_for_head_only

def label_counts(frame: pd.DataFrame) -> dict[str, int]:
    return {str(k): int(v) for k, v in frame['label'].value_counts().sort_index().items()}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--roi-dir', required=True)
    parser.add_argument('--index-csv', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--source-model-dir', required=True)
    parser.add_argument('--epoch-plan-csv', required=True)
    parser.add_argument('--teacher-pred-csv', default=None)
    parser.add_argument('--teacher-weight', type=float, default=0.0)
    parser.add_argument('--teacher-temperature', type=float, default=2.0)
    parser.add_argument('--model-name', default='convnext3d_tiny')
    parser.add_argument('--modality', default='T2W')
    parser.add_argument('--adaptation-mode', choices=['finetune', 'linear_probe', 'head_only'], default='finetune')
    parser.add_argument('--intensity-mode', choices=['minmax', 'percentile', 'zscore'], default='minmax')
    parser.add_argument('--seed', type=int, default=20260824)
    parser.add_argument('--lr', type=float, default=8e-05)
    parser.add_argument('--weight-decay', type=float, default=0.0001)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--num-workers', type=int, default=2)
    parser.add_argument('--class-balanced', action='store_true')
    parser.add_argument('--train-size', type=int, default=None, help='Stratified number of external cases used for adaptation; default uses every case.')
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device if args.device == 'cpu' or torch.cuda.is_available() else 'cpu')
    index = pd.read_csv(args.index_csv).reset_index(drop=True)
    index['id'] = index['id'].map(holdout.normalize_id)
    index['label'] = index['label'].astype(int)
    index, teacher_col = holdout.add_teacher_predictions(index, args.teacher_pred_csv)
    if args.train_size is None:
        train_index = index.copy().reset_index(drop=True)
        heldout_index = index.iloc[0:0].copy().reset_index(drop=True)
    else:
        if args.train_size <= 1 or args.train_size >= len(index):
            raise ValueError(f'--train-size must be between 2 and {len(index) - 1}')
        splitter = StratifiedShuffleSplit(n_splits=1, train_size=args.train_size, random_state=args.seed)
        train_positions, heldout_positions = next(splitter.split(index, index['label'].to_numpy(int)))
        train_index = index.iloc[train_positions].reset_index(drop=True)
        heldout_index = index.iloc[heldout_positions].reset_index(drop=True)
    checkpoints = holdout.list_checkpoints(args.source_model_dir)
    epoch_plan = pd.read_csv(args.epoch_plan_csv).sort_values('fold')
    if len(epoch_plan) != len(checkpoints):
        raise ValueError(f'Epoch plan has {len(epoch_plan)} rows but source directory has {len(checkpoints)} checkpoints')
    epochs = epoch_plan['best_epoch'].astype(int).tolist()
    if any((epoch < 1 for epoch in epochs)):
        raise ValueError(f'Invalid epoch plan: {epochs}')
    manifest = {'n_total': len(index), 'total_label_counts': label_counts(index), 'n_training': len(train_index), 'training_label_counts': label_counts(train_index), 'n_heldout': len(heldout_index), 'heldout_label_counts': label_counts(heldout_index) if len(heldout_index) else {}, 'all_cases_used_for_training': len(train_index) == len(index), 'full_cohort_evaluation_is_apparent_or_mixed': True, 'heldout_evaluation_is_independent': len(heldout_index) > 0, 'epoch_plan': epochs, 'epoch_plan_source': args.epoch_plan_csv, 'training_ids': train_index['id'].astype(str).tolist(), 'heldout_ids': heldout_index['id'].astype(str).tolist()}
    Path(args.output_dir, 'all_case_training_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    Path(args.output_dir, 'config.json').write_text(json.dumps(vars(args), indent=2), encoding='utf-8')
    train_dataset = holdout.ExternalT2Dataset(args.roi_dir, train_index, args.modality, augment=True, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
    eval_dataset = holdout.ExternalT2Dataset(args.roi_dir, index, args.modality, augment=False, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
    eval_loader = DataLoader(eval_dataset, batch_size=min(args.batch_size, len(eval_dataset)), shuffle=False, num_workers=args.num_workers, collate_fn=holdout.collate)
    y = index['label'].to_numpy(int)
    predictions = pd.DataFrame({'pid': index['id'].astype(str), 'label': y})
    records = []
    start = time.time()
    for model_index, (checkpoint, num_epochs) in enumerate(zip(checkpoints, epochs), start=1):
        torch.manual_seed(args.seed + model_index)
        np.random.seed(args.seed + model_index)
        generator = torch.Generator().manual_seed(args.seed + model_index)
        train_loader = DataLoader(train_dataset, batch_size=min(args.batch_size, len(train_dataset)), shuffle=True, generator=generator, num_workers=args.num_workers, collate_fn=holdout.collate)
        print(f"\n{'=' * 64}\nAll-case adaptation model {model_index}/{len(checkpoints)} for {num_epochs} epochs\n{'=' * 64}", flush=True)
        model = holdout.get_model(args.model_name, in_chans=1, num_classes=2).to(device)
        model.load_state_dict(holdout.load_state(checkpoint, device), strict=True)
        before_prob = holdout.predict_prob(model, eval_loader, device)
        predictions[f'source_model_{model_index}_prob'] = before_prob
        if args.adaptation_mode == 'linear_probe':
            holdout.freeze_for_linear_probe(model)
        elif args.adaptation_mode == 'head_only':
            freeze_for_head_only(model)
        trainable = sum((parameter.numel() for parameter in model.parameters() if parameter.requires_grad))
        if trainable == 0:
            raise ValueError(f'No trainable parameters for {args.adaptation_mode}')
        print(f'Train cases={len(train_index)} {label_counts(train_index)}, held-out cases={len(heldout_index)} {(label_counts(heldout_index) if len(heldout_index) else {})}, adaptation={args.adaptation_mode}, trainable={trainable:,}', flush=True)
        if args.class_balanced:
            counts = train_index['label'].value_counts().sort_index()
            weights = torch.tensor([len(train_index) / (2.0 * counts.get(0, 1)), len(train_index) / (2.0 * counts.get(1, 1))], dtype=torch.float32, device=device)
            criterion = nn.CrossEntropyLoss(weight=weights)
        else:
            criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.AdamW([parameter for parameter in model.parameters() if parameter.requires_grad], lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=num_epochs)
        last_train = None
        for epoch in range(1, num_epochs + 1):
            last_train = holdout.train_epoch(model, train_loader, optimizer, criterion, device, args.teacher_weight, args.teacher_temperature)
            scheduler.step()
            if epoch <= 3 or epoch % 5 == 0 or epoch == num_epochs:
                print(f"  Epoch {epoch:03d}/{num_epochs:03d}: loss={last_train['loss']:.4f}, train_acc={last_train['acc']:.4f}", flush=True)
        model_dir = Path(args.output_dir, f'model_{model_index}')
        model_dir.mkdir(parents=True, exist_ok=True)
        torch.save(model.state_dict(), model_dir / 'best_model.pth')
        after_prob = holdout.predict_prob(model, eval_loader, device)
        predictions[f'adapted_model_{model_index}_prob'] = after_prob
        apparent_metrics = holdout.metrics_from_prob(y, after_prob)
        heldout_mask = predictions['pid'].isin(set(heldout_index['id'].astype(str)))
        heldout_metrics = holdout.metrics_from_prob(y[heldout_mask], after_prob[heldout_mask]) if heldout_mask.any() else {}
        records.append({'model_index': model_index, 'source_checkpoint': checkpoint, 'epochs': num_epochs, 'trainable_parameters': trainable, 'last_train_loss': last_train['loss'], 'last_train_accuracy': last_train['acc'], **apparent_metrics, **{f'heldout_{key}': value for key, value in heldout_metrics.items()}})
        print(f"Model {model_index} same-case apparent AUC={apparent_metrics['auc']:.4f}", flush=True)
    source_columns = [column for column in predictions if column.startswith('source_model_')]
    adapted_columns = [column for column in predictions if column.startswith('adapted_model_')]
    predictions['source_ensemble_prob'] = predictions[source_columns].mean(axis=1)
    predictions['adapted_ensemble_prob'] = predictions[adapted_columns].mean(axis=1)
    predictions['source_pred_0p5'] = (predictions['source_ensemble_prob'] >= 0.5).astype(int)
    predictions['adapted_pred_0p5'] = (predictions['adapted_ensemble_prob'] >= 0.5).astype(int)
    training_ids = set(train_index['id'].astype(str))
    predictions['scope'] = np.where(predictions['pid'].isin(training_ids), 'adaptation', 'heldout')
    predictions.to_csv(Path(args.output_dir, 'all_case_predictions.csv'), index=False)
    pd.DataFrame(records).to_csv(Path(args.output_dir, 'model_metrics.csv'), index=False)
    summary = {**{key: value for key, value in manifest.items() if key not in {'training_ids', 'heldout_ids'}}, 'adaptation_mode': args.adaptation_mode, 'source_ensemble_full_cohort_metrics': holdout.metrics_from_prob(y, predictions['source_ensemble_prob'].to_numpy()), 'adapted_ensemble_full_cohort_metrics': holdout.metrics_from_prob(y, predictions['adapted_ensemble_prob'].to_numpy()), 'model_metrics': records, 'elapsed_minutes': (time.time() - start) / 60.0}
    heldout_mask = predictions['scope'].eq('heldout').to_numpy()
    if heldout_mask.any():
        summary['source_ensemble_heldout_metrics'] = holdout.metrics_from_prob(y[heldout_mask], predictions.loc[heldout_mask, 'source_ensemble_prob'].to_numpy())
        summary['adapted_ensemble_heldout_metrics'] = holdout.metrics_from_prob(y[heldout_mask], predictions.loc[heldout_mask, 'adapted_ensemble_prob'].to_numpy())
    Path(args.output_dir, 'all_case_adaptation_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
