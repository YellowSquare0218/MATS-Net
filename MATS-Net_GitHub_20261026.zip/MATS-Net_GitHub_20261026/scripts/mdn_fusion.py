import torch
import torch.nn as nn
import torch.nn.functional as F
from itertools import combinations

class TinyModalityEncoder(nn.Module):

    def __init__(self, in_chans=1, hidden_dims=(32, 64, 128), out_dim=256):
        super().__init__()
        layers = []
        prev = in_chans
        for h in hidden_dims:
            layers.extend([nn.Conv3d(prev, h, kernel_size=3, padding=1), nn.BatchNorm3d(h), nn.GELU(), nn.MaxPool3d(kernel_size=(1, 2, 2), stride=(1, 2, 2))])
            prev = h
        self.conv = nn.Sequential(*layers)
        self.proj = nn.Linear(hidden_dims[-1], out_dim)

    def forward(self, x):
        x = self.conv(x)
        x = x.mean(dim=(-3, -2, -1))
        return self.proj(x)

class MDNFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, num_modalities=4, disc_dim=256, gamma_init=0.0):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 4, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.num_modalities = num_modalities
        self.mod_encoder = TinyModalityEncoder(out_dim=disc_dim)
        self.n_pairs = num_modalities * (num_modalities - 1) // 2
        disc_hidden = max(64, disc_dim // 2)
        self.disc_encoder = nn.Sequential(nn.Linear(self.n_pairs * disc_dim, disc_hidden), nn.GELU(), nn.Dropout(0.2), nn.Linear(disc_hidden, self.feat_dim))
        self.gamma = nn.Parameter(torch.full((1,), gamma_init))
        self.feat_norm = nn.LayerNorm(self.feat_dim)
        self.classifier = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))

    def forward(self, x):
        B = x[0].shape[0]
        fused = torch.cat(x, dim=1)
        F = self.encoder.forward_features(fused)
        mod_feats = [self.mod_encoder(x[i]) for i in range(self.num_modalities)]
        discrepancies = []
        for i, j in combinations(range(self.num_modalities), 2):
            d_ij = torch.abs(mod_feats[i] - mod_feats[j])
            discrepancies.append(d_ij)
        disc_concat = torch.cat(discrepancies, dim=-1)
        E = self.disc_encoder(disc_concat)
        F_norm = self.feat_norm(F)
        F_enhanced = F_norm + self.gamma * E
        return self.classifier(F_enhanced)

    def get_discrepancy_analysis(self, x):
        with torch.no_grad():
            mod_feats = [self.mod_encoder(x[i]) for i in range(self.num_modalities)]
            disc = {}
            pair_names = ['T2W-DWI', 'T2W-T1C', 'T2W-T1W', 'DWI-T1C', 'DWI-T1W', 'T1C-T1W']
            for (i, j), name in zip(combinations(range(self.num_modalities), 2), pair_names):
                disc[name] = torch.norm(mod_feats[i] - mod_feats[j], dim=-1).mean().item()
            return disc
