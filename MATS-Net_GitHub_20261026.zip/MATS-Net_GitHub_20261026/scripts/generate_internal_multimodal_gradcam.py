from __future__ import annotations
import argparse
import json
import os
import sys
from pathlib import Path
from typing import Dict, Tuple
import matplotlib.pyplot as plt
import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import get_model
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']
DISPLAY_NAMES = {'T2W': 'T2WI', 'DWI': 'DWI', 'T1C': 'CE-T1WI', 'T1W': 'T1WI'}

def normalize_pid(value: object) -> str:
    text = str(value).strip()
    return text[:-2] if text.endswith('.0') else text

def load_state(path: Path, device: torch.device) -> Dict[str, torch.Tensor]:
    state = torch.load(path, map_location=device)
    if isinstance(state, dict) and 'state_dict' in state:
        state = state['state_dict']
    if isinstance(state, dict) and any((key.startswith('module.') for key in state)):
        state = {key.replace('module.', '', 1): value for key, value in state.items()}
    return state

def load_volume(path: Path) -> np.ndarray:
    data = nib.load(path).get_fdata().astype(np.float32)
    data = np.transpose(data, (2, 0, 1))
    vmin, vmax = (float(np.nanmin(data)), float(np.nanmax(data)))
    if vmax > vmin:
        data = (data - vmin) / (vmax - vmin)
    return np.nan_to_num(data, nan=0.0, posinf=1.0, neginf=0.0).astype(np.float32)

def find_fold(model_dir: Path, pid: str) -> Tuple[int, pd.Series]:
    matches = []
    for path in sorted(model_dir.glob('fold_*/predictions.csv')):
        frame = pd.read_csv(path)
        frame['pid'] = frame['pid'].map(normalize_pid)
        rows = frame.loc[frame['pid'].eq(pid)]
        if not rows.empty:
            matches.append((int(path.parent.name.split('_')[-1]), rows.iloc[0]))
    if len(matches) != 1:
        raise RuntimeError(f'Expected one OOF fold for {pid} under {model_dir}, found {len(matches)}')
    return matches[0]

def gradcam(model: torch.nn.Module, volume: torch.Tensor, target_class: int, target_stage: int, method: str, score_mode: str) -> Tuple[float, np.ndarray]:
    activation = None
    gradient = None

    def forward_hook(_module, _inputs, output):
        nonlocal activation, gradient
        activation = output

        def gradient_hook(value):
            nonlocal gradient
            gradient = value
        output.register_hook(gradient_hook)
    handle = model.stages[target_stage].register_forward_hook(forward_hook)
    try:
        model.zero_grad(set_to_none=True)
        logits = model(volume)
        probability = float(torch.softmax(logits, dim=1)[0, 1].detach().cpu())
        score = logits[0, target_class]
        if score_mode == 'margin':
            score = score - logits[0, 1 - target_class]
        score.backward()
        if activation is None or gradient is None:
            raise RuntimeError('Grad-CAM hooks did not capture tensors')
        if method == 'gradcampp':
            gradients_sq = gradient.pow(2)
            gradients_cube = gradients_sq * gradient
            denominator = 2.0 * gradients_sq + (activation * gradients_cube).sum(dim=(2, 3, 4), keepdim=True)
            alpha = gradients_sq / (denominator + 1e-07)
            alpha = torch.where(gradient != 0, alpha, torch.zeros_like(alpha))
            weights = (alpha * torch.relu(gradient)).sum(dim=(2, 3, 4), keepdim=True)
        else:
            weights = gradient.mean(dim=(2, 3, 4), keepdim=True)
        cam = torch.relu((weights * activation).sum(dim=1, keepdim=True))
        cam = F.interpolate(cam, size=volume.shape[-3:], mode='trilinear', align_corners=False)
        cam = cam[0, 0].detach().cpu().numpy()
        low, high = (float(cam.min()), float(cam.max()))
        cam = (cam - low) / (high - low) if high > low else np.zeros_like(cam)
        return (probability, cam.astype(np.float32))
    finally:
        handle.remove()

def select_cases(expert_root: Path, case_ids=None) -> pd.DataFrame:
    merged = None
    for modality in MODALITIES:
        frame = pd.read_csv(expert_root / f'single_{modality}' / 'all_predictions.csv')
        frame['pid'] = frame['pid'].map(normalize_pid)
        current = frame[['pid', 'label', 'pred', 'prob_pos']].rename(columns={'pred': f'pred_{modality}', 'prob_pos': f'prob_{modality}'})
        merged = current if merged is None else merged.merge(current, on=['pid', 'label'], validate='one_to_one')
    assert merged is not None
    merged['mean_probability'] = merged[[f'prob_{m}' for m in MODALITIES]].mean(axis=1)
    merged['correct_expert_count'] = np.sum([merged[f'pred_{m}'].astype(int).eq(merged['label'].astype(int)).to_numpy(int) for m in MODALITIES], axis=0)
    if case_ids:
        order = {normalize_pid(pid): index for index, pid in enumerate(case_ids)}
        chosen = merged.loc[merged['pid'].isin(order)].copy()
        if len(chosen) != len(order):
            missing = sorted(set(order) - set(chosen['pid']))
            raise RuntimeError(f'Requested case IDs not found: {missing}')
        chosen['requested_order'] = chosen['pid'].map(order)
        return chosen.sort_values('requested_order').drop(columns='requested_order').reset_index(drop=True)
    positive = merged.loc[merged['label'].eq(1)].sort_values(['correct_expert_count', 'mean_probability'], ascending=[False, False]).head(1)
    negative = merged.loc[merged['label'].eq(0)].sort_values(['correct_expert_count', 'mean_probability'], ascending=[False, True]).head(1)
    if positive.empty or negative.empty:
        raise RuntimeError('Could not find both positive and negative cases correctly classified by all experts')
    return pd.concat([positive, negative], ignore_index=True)

def orient(image: np.ndarray) -> np.ndarray:
    return np.rot90(image)

def overlay(image: np.ndarray, cam: np.ndarray) -> np.ndarray:
    gray = np.repeat(image[..., None], 3, axis=-1)
    heat = plt.get_cmap('inferno')(cam)[..., :3]
    alpha = (0.08 + 0.62 * cam)[..., None]
    return np.clip(gray * (1.0 - alpha) + heat * alpha, 0.0, 1.0)

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--roi-dir', default='dataset/roi_v4')
    parser.add_argument('--expert-root', default='training_results/grouped_deep_recompute_aug262')
    parser.add_argument('--output-dir', default='work/submission_priority_analyses_20260908/internal_multimodal_gradcam')
    parser.add_argument('--target-stage', type=int, choices=[0, 1, 2, 3], default=2)
    parser.add_argument('--method', choices=['gradcam', 'gradcampp'], default='gradcampp')
    parser.add_argument('--score-mode', choices=['logit', 'margin'], default='margin')
    parser.add_argument('--case-ids', nargs=2, default=None)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    roi_dir = Path(args.roi_dir)
    expert_root = Path(args.expert_root)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)
    cases = select_cases(expert_root, args.case_ids)
    results = []
    maps = {}
    for _, case in cases.iterrows():
        pid = normalize_pid(case['pid'])
        label = int(case['label'])
        for modality in MODALITIES:
            model_dir = expert_root / f'single_{modality}'
            fold, expected = find_fold(model_dir, pid)
            volume = load_volume(roi_dir / pid / f'{modality}.nii.gz')
            tensor = torch.from_numpy(volume).unsqueeze(0).unsqueeze(0).to(device)
            model = get_model('convnext3d_tiny', in_chans=1, num_classes=2).to(device)
            model.load_state_dict(load_state(model_dir / f'fold_{fold}' / 'best_model.pth', device), strict=True)
            model.eval()
            expected_probability = float(expected['prob_pos'])
            target_class = int(expected_probability >= 0.5)
            probability, cam = gradcam(model, tensor, target_class, args.target_stage, args.method, args.score_mode)
            if not np.isclose(probability, expected_probability, atol=1e-05):
                raise RuntimeError(f'OOF probability mismatch for {pid}/{modality}: {probability} vs {expected_probability}')
            margin = max(1, cam.shape[0] // 8)
            candidate_scores = cam[margin:cam.shape[0] - margin].mean(axis=(1, 2))
            slice_index = int(margin + np.argmax(candidate_scores))
            maps[pid, modality] = (volume, cam, slice_index)
            results.append({'pid': pid, 'label': label, 'modality': DISPLAY_NAMES[modality], 'oof_fold': fold, 'oof_probability_class_1': probability, 'predicted_class': int(probability >= 0.5), 'gradcam_target_class': target_class, 'gradcam_method': args.method, 'gradcam_score_mode': args.score_mode, 'gradcam_layer': f'stages[{args.target_stage}]', 'displayed_slice_index': slice_index, 'case_correct_expert_count': int(case['correct_expert_count'])})
            del model
            if device.type == 'cuda':
                torch.cuda.empty_cache()
    result_frame = pd.DataFrame(results)
    result_frame.to_csv(output_dir / 'internal_gradcam_case_manifest.csv', index=False)
    metadata = {'data_type': 'real internal OOF', 'case_selection': f'explicit predefined case IDs: {args.case_ids}' if args.case_ids else 'within each class, maximize the number of correct single-sequence experts, then select the most class-consistent four-expert mean probability', 'models': 'fold-specific single-sequence 3D ConvNeXt-tiny experts', 'target_layer': f'stages[{args.target_stage}]', 'method': args.method, 'score_mode': args.score_mode, 'target_class': "each single-sequence expert's predicted class", 'slice_selection': 'within each manually defined ROI crop, exclude the outermost one-eighth of slices and select the slice with maximum mean CAM activation', 'modalities': MODALITIES}
    (output_dir / 'internal_gradcam_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'figure.facecolor': 'white', 'savefig.facecolor': 'white'})
    fig, axes = plt.subplots(len(MODALITIES), 4, figsize=(8.2, 8.8))
    high_pid = normalize_pid(cases.iloc[0]['pid'])
    low_pid = normalize_pid(cases.iloc[1]['pid'])
    column_titles = ['High-risk case A\nOriginal', 'High-risk case A\nGrad-CAM++', 'Lower-risk case B\nOriginal', 'Lower-risk case B\nGrad-CAM++']
    for column, title in enumerate(column_titles):
        axes[0, column].set_title(title, fontsize=10.5, fontweight='bold', pad=8)
    for row, modality in enumerate(MODALITIES):
        for case_column, pid in enumerate([high_pid, low_pid]):
            volume, cam, slice_index = maps[pid, modality]
            image_slice = orient(volume[slice_index])
            cam_slice = orient(cam[slice_index])
            original_axis = axes[row, case_column * 2]
            overlay_axis = axes[row, case_column * 2 + 1]
            original_axis.imshow(image_slice, cmap='gray', vmin=0, vmax=1)
            overlay_axis.imshow(overlay(image_slice, cam_slice))
            overlay_axis.contour(cam_slice, levels=[0.65], colors=['#00E5FF'], linewidths=0.8)
            if case_column == 0:
                original_axis.set_ylabel(DISPLAY_NAMES[modality], fontsize=10.5, fontweight='bold')
            for axis in (original_axis, overlay_axis):
                axis.set_xticks([])
                axis.set_yticks([])
                for spine in axis.spines.values():
                    spine.set_visible(True)
                    spine.set_linewidth(0.7)
                    spine.set_edgecolor('#455A64')
    high_mean = float(cases.iloc[0]['mean_probability'])
    low_mean = float(cases.iloc[1]['mean_probability'])
    high_correct = int(cases.iloc[0]['correct_expert_count'])
    low_correct = int(cases.iloc[1]['correct_expert_count'])
    fig.suptitle('Internal OOF single-sequence expert Grad-CAM++', fontsize=14, fontweight='bold', y=0.985)
    fig.text(0.5, 0.022, f'Four-expert mean P(class 1): high-risk={high_mean:.3f} ({high_correct}/4 correct); lower-risk={low_mean:.3f} ({low_correct}/4 correct). Cyan contours denote CAM >= 0.65.', ha='center', fontsize=8.5, color='#455A64')
    fig.subplots_adjust(left=0.08, right=0.99, top=0.92, bottom=0.06, wspace=0.035, hspace=0.04)
    stem = output_dir / f'internal_multimodal_oof_{args.method}'
    fig.savefig(stem.with_suffix('.png'), dpi=450, bbox_inches='tight')
    fig.savefig(stem.with_suffix('.tiff'), dpi=450, bbox_inches='tight')
    fig.savefig(stem.with_suffix('.svg'), bbox_inches='tight')
    plt.close(fig)
    print(result_frame.to_string(index=False))
    print(f'Saved internal Grad-CAM outputs to {output_dir}')
if __name__ == '__main__':
    main()
