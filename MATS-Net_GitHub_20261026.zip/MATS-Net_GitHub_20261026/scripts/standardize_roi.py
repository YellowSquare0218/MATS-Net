from _paths import project_path as _project_path
import os
import numpy as np
import pandas as pd
import nibabel as nib
from tqdm import tqdm
from scipy.ndimage import zoom
import gc
OLD_ROI_DIR = _project_path('dataset/processed_rois_all_269')
INDEX_FILE = _project_path('dataset/patient_index.csv')
OUTPUT_DIR = _project_path('dataset/roi_v4')
TARGET_XY = 64
TARGET_Z = 16
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']

def standardize_roi(src_path, out_path):
    img = nib.load(src_path)
    data = img.get_fdata().astype(np.float32)
    zoom_factors = (TARGET_XY / data.shape[0], TARGET_XY / data.shape[1], TARGET_Z / data.shape[2])
    resized = zoom(data, zoom_factors, order=1)
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    roi_img = nib.Nifti1Image(resized, np.eye(4))
    nib.save(roi_img, out_path)

def main():
    df = pd.read_csv(INDEX_FILE)
    available = sorted([d for d in os.listdir(OLD_ROI_DIR) if os.path.isdir(os.path.join(OLD_ROI_DIR, d)) and '_2' not in d])
    idx_ids = set((str(int(x)) for x in df['id']))
    available_ids = set(available)
    valid = idx_ids & available_ids
    print(f'Index patients: {len(idx_ids)}')
    print(f'Available (no _2): {len(available_ids)}')
    print(f'Valid overlap: {len(valid)}')
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    records = []
    failed = []
    for pid in tqdm(sorted(valid), desc='Standardizing ROIs'):
        state = int(df[df['id'] == int(pid)]['state'].values[0])
        src_dir = os.path.join(OLD_ROI_DIR, pid)
        out_dir = os.path.join(OUTPUT_DIR, pid)
        all_ok = True
        for mod in MODALITIES:
            src_path = os.path.join(src_dir, f'{mod}.nii.gz')
            out_path = os.path.join(out_dir, f'{mod}.nii.gz')
            if not os.path.exists(src_path):
                all_ok = False
                continue
            try:
                standardize_roi(src_path, out_path)
            except Exception as e:
                print(f'  FAIL {pid}/{mod}: {e}')
                all_ok = False
        gc.collect()
        if all_ok:
            records.append({'id': pid, 'state': state, 'label': 0 if state <= 2 else 1})
        else:
            failed.append(pid)
    idx_df = pd.DataFrame(records)
    idx_df.to_csv(os.path.join(OUTPUT_DIR, 'index.csv'), index=False)
    print(f'\nDone: {len(records)} success, {len(failed)} failed')
    print(f"State: {idx_df['state'].value_counts().sort_index().to_dict()}")
    print(f'Output: {OUTPUT_DIR}')
if __name__ == '__main__':
    main()
