from __future__ import annotations
import argparse
import json
import math
import os
import re
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Tuple
import numpy as np
import pandas as pd
from sklearn.ensemble import GradientBoostingClassifier, RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, average_precision_score, brier_score_loss, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
try:
    from sklearn.model_selection import StratifiedGroupKFold
except Exception:
    StratifiedGroupKFold = None
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_LABELS = PROJECT_ROOT / 'dataset' / 'roi_v4' / 'labels_clinical_expanded_262.csv'
DEFAULT_INDEX = PROJECT_ROOT / 'dataset' / 'roi_v4' / 'index.csv'
DEFAULT_PATIENT_INDEX = PROJECT_ROOT / 'dataset' / 'patient_index.csv'
DEFAULT_ROI_DIR = PROJECT_ROOT / 'dataset' / 'roi_v4'
DEFAULT_FUSION_OOF = PROJECT_ROOT / 'training_results' / 'fast_evidence_fusion_aug262_supplementary_2cls' / 'aligned_predictions.csv'
DEFAULT_OUTPUT = PROJECT_ROOT / 'training_results' / 'standard_baselines_aug262'
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']
CLINICAL_MINIMAL = ['src279_length', 'src279_CEA']
CLINICAL_EXTENDED = ['g_Gender', 'g_Age', 'g_BMI', 'g_Height', 'g_Weight', 'src279_length', 'src279_CEA']

def normalize_id(value) -> str:
    return re.sub('\\.0$', '', str(value)).strip()

def base_patient_id(value) -> str:
    return re.sub('_2$', '', normalize_id(value))

def parse_range(value) -> Tuple[float, float, float, float]:
    if pd.isna(value):
        return (np.nan, np.nan, np.nan, np.nan)
    text = str(value).replace('_', '-').strip()
    if '-' in text:
        a, b = text.split('-', 1)
        try:
            start = float(a)
            end = float(b)
        except ValueError:
            return (np.nan, np.nan, np.nan, np.nan)
        length = max(0.0, end - start + 1.0)
        center = (start + end) / 2.0
        return (start, end, length, center)
    try:
        val = float(text)
        return (val, val, 0.0, val)
    except ValueError:
        return (np.nan, np.nan, np.nan, np.nan)

def safe_auc(y: np.ndarray, score: np.ndarray) -> float:
    if len(np.unique(y)) < 2:
        return float('nan')
    return float(roc_auc_score(y, score))

def safe_ap(y: np.ndarray, score: np.ndarray) -> float:
    if len(np.unique(y)) < 2:
        return float('nan')
    return float(average_precision_score(y, score))

def ece_score(y: np.ndarray, score: np.ndarray, n_bins: int=10) -> float:
    y = np.asarray(y, dtype=int)
    score = np.asarray(score, dtype=float)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    for i in range(n_bins):
        lo, hi = (bins[i], bins[i + 1])
        if i == n_bins - 1:
            mask = (score >= lo) & (score <= hi)
        else:
            mask = (score >= lo) & (score < hi)
        if not mask.any():
            continue
        ece += mask.mean() * abs(score[mask].mean() - y[mask].mean())
    return float(ece)

def calibration_slope_intercept(y: np.ndarray, score: np.ndarray) -> Tuple[float, float]:
    eps = 1e-06
    score = np.clip(np.asarray(score, dtype=float), eps, 1.0 - eps)
    logit = np.log(score / (1.0 - score)).reshape(-1, 1)
    y = np.asarray(y, dtype=int)
    if len(np.unique(y)) < 2:
        return (float('nan'), float('nan'))
    try:
        lr = LogisticRegression(solver='lbfgs', max_iter=2000)
        lr.fit(logit, y)
        return (float(lr.intercept_[0]), float(lr.coef_[0, 0]))
    except Exception:
        return (float('nan'), float('nan'))

def binary_metrics(y: np.ndarray, score: np.ndarray, threshold: float=0.5) -> Dict[str, float]:
    y = np.asarray(y, dtype=int)
    score = np.asarray(score, dtype=float)
    pred = (score >= threshold).astype(int)
    cm = confusion_matrix(y, pred, labels=[0, 1])
    tn, fp, fn, tp = cm.ravel()
    intercept, slope = calibration_slope_intercept(y, score)
    prevalence = float(y.mean())
    return {'n': int(len(y)), 'positive_n': int(y.sum()), 'negative_n': int((y == 0).sum()), 'prevalence': prevalence, 'auc': safe_auc(y, score), 'ap': safe_ap(y, score), 'acc': float(accuracy_score(y, pred)), 'f1': float(f1_score(y, pred, zero_division=0)), 'precision': float(precision_score(y, pred, zero_division=0)), 'recall': float(recall_score(y, pred, zero_division=0)), 'sensitivity': float(tp / (tp + fn)) if tp + fn else float('nan'), 'specificity': float(tn / (tn + fp)) if tn + fp else float('nan'), 'brier': float(brier_score_loss(y, score)), 'ece': ece_score(y, score), 'calibration_intercept': intercept, 'calibration_slope': slope, 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp), 'threshold': float(threshold)}

def grouped_bootstrap_ci(y: np.ndarray, score: np.ndarray, groups: np.ndarray, n_boot: int, seed: int) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    unique_groups = np.asarray(pd.unique(groups))
    group_to_idx = {g: np.flatnonzero(groups == g) for g in unique_groups}
    rows = []
    for _ in range(n_boot):
        sampled_groups = rng.choice(unique_groups, size=len(unique_groups), replace=True)
        idx = np.concatenate([group_to_idx[g] for g in sampled_groups])
        yy = y[idx]
        ss = score[idx]
        if len(np.unique(yy)) < 2:
            continue
        bm = binary_metrics(yy, ss)
        rows.append({'auc': safe_auc(yy, ss), 'acc': bm['acc'], 'sensitivity': bm['sensitivity'], 'specificity': bm['specificity'], 'brier': float(brier_score_loss(yy, ss)), 'ece': ece_score(yy, ss)})
    if not rows:
        return {}
    boot = pd.DataFrame(rows)
    out = {}
    for col in boot.columns:
        out[f'{col}_ci_low'] = float(boot[col].quantile(0.025))
        out[f'{col}_ci_high'] = float(boot[col].quantile(0.975))
    return out

def paired_group_bootstrap_diff(y: np.ndarray, score_a: np.ndarray, score_b: np.ndarray, groups: np.ndarray, n_boot: int, seed: int) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    unique_groups = np.asarray(pd.unique(groups))
    group_to_idx = {g: np.flatnonzero(groups == g) for g in unique_groups}
    diffs = []
    for _ in range(n_boot):
        sampled_groups = rng.choice(unique_groups, size=len(unique_groups), replace=True)
        idx = np.concatenate([group_to_idx[g] for g in sampled_groups])
        yy = y[idx]
        if len(np.unique(yy)) < 2:
            continue
        diffs.append(safe_auc(yy, score_a[idx]) - safe_auc(yy, score_b[idx]))
    if not diffs:
        return {'auc_diff': float('nan'), 'auc_diff_ci_low': float('nan'), 'auc_diff_ci_high': float('nan')}
    diffs = np.asarray(diffs, dtype=float)
    return {'auc_diff': float(safe_auc(y, score_a) - safe_auc(y, score_b)), 'auc_diff_ci_low': float(np.quantile(diffs, 0.025)), 'auc_diff_ci_high': float(np.quantile(diffs, 0.975)), 'bootstrap_p_two_sided': float(2 * min(np.mean(diffs <= 0), np.mean(diffs >= 0)))}

def load_geometry(index_path: Path, patient_index_path: Path) -> pd.DataFrame:
    index = pd.read_csv(index_path)
    index['id'] = index['id'].map(normalize_id)
    index['_base_id'] = index['id'].map(base_patient_id)
    if 'label' not in index.columns:
        index['label'] = (index['state'].astype(int) == 3).astype(int)
    meta = pd.read_csv(patient_index_path)
    meta['id'] = meta['id'].map(normalize_id)
    meta['_base_id'] = meta['id'].map(base_patient_id)
    meta = meta.drop_duplicates(['_base_id', 'state'])
    merged = index.merge(meta.drop(columns=['id']), on=['_base_id', 'state'], how='left')
    features = {'id': merged['id'].astype(str), 'label': merged['label'].astype(int)}
    for mod in MODALITIES:
        features[f'geo_{mod}_max'] = pd.to_numeric(merged.get(f'{mod}_max'), errors='coerce')
        for axis in ['x', 'y', 'z']:
            parsed = [parse_range(v) for v in merged.get(f'{mod}_{axis}')]
            features[f'geo_{mod}_{axis}_start'] = [v[0] for v in parsed]
            features[f'geo_{mod}_{axis}_end'] = [v[1] for v in parsed]
            features[f'geo_{mod}_{axis}_len'] = [v[2] for v in parsed]
            features[f'geo_{mod}_{axis}_center'] = [v[3] for v in parsed]
        features[f'geo_{mod}_xy_area'] = np.asarray(features[f'geo_{mod}_x_len'], dtype=float) * np.asarray(features[f'geo_{mod}_y_len'], dtype=float)
        features[f'geo_{mod}_vol_approx'] = np.asarray(features[f'geo_{mod}_xy_area'], dtype=float) * np.asarray(features[f'geo_{mod}_z_len'], dtype=float)
        features[f'geo_{mod}_aspect_xy'] = np.asarray(features[f'geo_{mod}_x_len'], dtype=float) / np.clip(np.asarray(features[f'geo_{mod}_y_len'], dtype=float), 1e-06, None)
    for key in ['max', 'x_len', 'y_len', 'z_len', 'xy_area', 'vol_approx']:
        cols = [f'geo_{mod}_{key}' for mod in MODALITIES if f'geo_{mod}_{key}' in features]
        arr = np.vstack([np.asarray(features[col], dtype=float) for col in cols]).T
        features[f'geo_cross_{key}_mean'] = np.nanmean(arr, axis=1)
        features[f'geo_cross_{key}_std'] = np.nanstd(arr, axis=1)
        features[f'geo_cross_{key}_range'] = np.nanmax(arr, axis=1) - np.nanmin(arr, axis=1)
    return pd.DataFrame(features)

def simple_intensity_features(volume: np.ndarray, prefix: str) -> Dict[str, float]:
    arr = np.asarray(volume, dtype=float)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        finite = np.array([0.0])
    nonzero = finite[np.abs(finite) > 1e-08]
    roi = nonzero if nonzero.size >= 8 else finite
    hist, _ = np.histogram(roi, bins=32, density=False)
    probs = hist.astype(float) / max(float(hist.sum()), 1.0)
    entropy = -float(np.sum(probs[probs > 0] * np.log2(probs[probs > 0])))
    std = float(np.std(roi))
    if std > 0:
        z = (roi - float(np.mean(roi))) / std
        skew = float(np.mean(z ** 3))
        kurt = float(np.mean(z ** 4))
    else:
        skew = 0.0
        kurt = 0.0
    return {f'{prefix}_mean': float(np.mean(roi)), f'{prefix}_std': std, f'{prefix}_min': float(np.min(roi)), f'{prefix}_max': float(np.max(roi)), f'{prefix}_p10': float(np.percentile(roi, 10)), f'{prefix}_p25': float(np.percentile(roi, 25)), f'{prefix}_p50': float(np.percentile(roi, 50)), f'{prefix}_p75': float(np.percentile(roi, 75)), f'{prefix}_p90': float(np.percentile(roi, 90)), f'{prefix}_iqr': float(np.percentile(roi, 75) - np.percentile(roi, 25)), f'{prefix}_energy': float(np.mean(roi ** 2)), f'{prefix}_entropy': entropy, f'{prefix}_skew': skew, f'{prefix}_kurtosis': kurt, f'{prefix}_nonzero_fraction': float(nonzero.size / max(finite.size, 1)), f'{prefix}_nonzero_count': float(nonzero.size)}

def extract_simple_radiomics(labels: pd.DataFrame, roi_dir: Path) -> pd.DataFrame:
    import nibabel as nib
    rows = []
    for _, row in labels.iterrows():
        pid = str(row['id'])
        record = {'id': pid}
        for mod in MODALITIES:
            fp = roi_dir / pid / f'{mod}.nii.gz'
            if not fp.exists():
                for key in simple_intensity_features(np.array([np.nan]), f'rad_{mod}'):
                    record[key] = np.nan
                continue
            data = nib.load(str(fp)).get_fdata().astype(np.float32)
            record.update(simple_intensity_features(data, f'rad_{mod}'))
        rows.append(record)
    return pd.DataFrame(rows)

def extract_pyradiomics(labels: pd.DataFrame, roi_dir: Path, output_cache: Path) -> pd.DataFrame:
    try:
        import SimpleITK as sitk
        from radiomics import featureextractor
    except Exception as exc:
        raise RuntimeError(f'PyRadiomics is unavailable: {exc}') from exc
    import nibabel as nib
    extractor = featureextractor.RadiomicsFeatureExtractor()
    extractor.disableAllFeatures()
    extractor.enableFeatureClassByName('firstorder')
    extractor.enableFeatureClassByName('glcm')
    extractor.enableFeatureClassByName('glrlm')
    extractor.enableFeatureClassByName('glszm')
    extractor.enableFeatureClassByName('shape')
    extractor.settings['binWidth'] = 25
    extractor.settings['normalize'] = True
    extractor.settings['removeOutliers'] = 3
    rows = []
    for _, row in labels.iterrows():
        pid = str(row['id'])
        record = {'id': pid}
        for mod in MODALITIES:
            fp = roi_dir / pid / f'{mod}.nii.gz'
            if not fp.exists():
                continue
            data = nib.load(str(fp)).get_fdata().astype(np.float32)
            mask = (np.abs(data) > 1e-08).astype(np.uint8)
            if mask.sum() < 8:
                mask = np.ones_like(mask, dtype=np.uint8)
            image = sitk.GetImageFromArray(np.transpose(data, (2, 1, 0)))
            mask_img = sitk.GetImageFromArray(np.transpose(mask, (2, 1, 0)))
            try:
                feats = extractor.execute(image, mask_img)
            except Exception:
                feats = {}
            for k, v in feats.items():
                if k.startswith('diagnostics_'):
                    continue
                try:
                    record[f'pyrad_{mod}_{k}'] = float(v)
                except Exception:
                    continue
        rows.append(record)
    df = pd.DataFrame(rows)
    output_cache.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_cache, index=False)
    return df

def make_splits(y: np.ndarray, groups: np.ndarray, n_splits: int, seed: int, split_strategy: str):
    if split_strategy == 'stratified':
        splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        return list(splitter.split(np.zeros_like(y), y))
    if StratifiedGroupKFold is None:
        raise ImportError('StratifiedGroupKFold is unavailable in this scikit-learn.')
    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(splitter.split(np.zeros_like(y), y, groups=groups))

def model_factories(seed: int):
    return {'elastic_net_logistic': Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler()), ('clf', LogisticRegression(penalty='elasticnet', solver='saga', l1_ratio=0.5, C=1.0, max_iter=6000, class_weight='balanced', random_state=seed))]), 'ridge_logistic': Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler()), ('clf', LogisticRegression(penalty='l2', solver='lbfgs', C=1.0, max_iter=4000, class_weight='balanced', random_state=seed))]), 'gradient_boosting': Pipeline([('impute', SimpleImputer(strategy='median')), ('clf', GradientBoostingClassifier(random_state=seed, n_estimators=120, max_depth=2))]), 'random_forest': Pipeline([('impute', SimpleImputer(strategy='median')), ('clf', RandomForestClassifier(n_estimators=500, max_depth=4, min_samples_leaf=5, class_weight='balanced_subsample', random_state=seed, n_jobs=-1))])}

def run_oof(frame: pd.DataFrame, feature_cols: List[str], feature_set: str, model_name: str, model, splits) -> Tuple[Dict[str, float], pd.DataFrame, pd.DataFrame]:
    y = frame['label'].to_numpy(dtype=int)
    X = frame[feature_cols].to_numpy(dtype=float)
    score = np.zeros(len(frame), dtype=float)
    pred = np.zeros(len(frame), dtype=int)
    fold_rows = []
    for fold, (train_idx, val_idx) in enumerate(splits, start=1):
        model.fit(X[train_idx], y[train_idx])
        proba = model.predict_proba(X[val_idx])[:, 1]
        score[val_idx] = proba
        pred[val_idx] = (proba >= 0.5).astype(int)
        m = binary_metrics(y[val_idx], proba)
        m.update({'feature_set': feature_set, 'model': model_name, 'fold': fold, 'n_features': len(feature_cols)})
        fold_rows.append(m)
    row = binary_metrics(y, score)
    fold_auc = [r['auc'] for r in fold_rows if not math.isnan(r['auc'])]
    row.update({'feature_set': feature_set, 'model': model_name, 'n_features': len(feature_cols), 'fold_auc_mean': float(np.mean(fold_auc)) if fold_auc else float('nan'), 'fold_auc_std': float(np.std(fold_auc, ddof=1)) if len(fold_auc) > 1 else float('nan'), 'fold_acc_mean': float(np.mean([r['acc'] for r in fold_rows])), 'fold_acc_std': float(np.std([r['acc'] for r in fold_rows], ddof=1))})
    pred_df = frame[['id', 'base_id', 'label', 'state']].copy()
    pred_df['feature_set'] = feature_set
    pred_df['model'] = model_name
    pred_df['prob_pos'] = score
    pred_df['pred'] = pred
    return (row, pred_df, pd.DataFrame(fold_rows))

def markdown_table(df: pd.DataFrame, max_rows: Optional[int]=None) -> str:
    if max_rows is not None:
        df = df.head(max_rows)
    lines = ['| ' + ' | '.join(df.columns) + ' |', '| ' + ' | '.join(['---'] * len(df.columns)) + ' |']
    for _, row in df.iterrows():
        vals = []
        for col in df.columns:
            v = row[col]
            if isinstance(v, (float, np.floating)):
                vals.append('' if math.isnan(float(v)) else f'{float(v):.3f}')
            else:
                vals.append(str(v))
        lines.append('| ' + ' | '.join(vals) + ' |')
    return '\n'.join(lines)

def build_selected_fusion_score(df: pd.DataFrame) -> Optional[np.ndarray]:
    for col in ['selected_fusion_auc', 'selected_fusion_best_acc', 'fusion_selected_auc']:
        if col in df.columns:
            return df[col].to_numpy(dtype=float)
    cols = ['single_T2W', 'single_DWI', 'mara', 'gmara_auc', 'gmara_burden_w004']
    if all((c in df.columns for c in cols)):
        return df[cols].mean(axis=1).to_numpy(dtype=float)
    return None

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--labels', default=str(DEFAULT_LABELS))
    parser.add_argument('--index', default=str(DEFAULT_INDEX))
    parser.add_argument('--patient_index', default=str(DEFAULT_PATIENT_INDEX))
    parser.add_argument('--roi_dir', default=str(DEFAULT_ROI_DIR))
    parser.add_argument('--fusion_oof', default=str(DEFAULT_FUSION_OOF))
    parser.add_argument('--output', default=str(DEFAULT_OUTPUT))
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--n_splits', type=int, default=5)
    parser.add_argument('--n_boot', type=int, default=1000)
    parser.add_argument('--split_strategy', choices=['group', 'stratified'], default='group')
    parser.add_argument('--models', default='elastic_net_logistic,ridge_logistic,gradient_boosting', help='Comma-separated models to run. Available: elastic_net_logistic,ridge_logistic,gradient_boosting,random_forest.')
    parser.add_argument('--radiomics', choices=['none', 'simple', 'pyradiomics'], default='none', help='Optional NIfTI radiomics extraction. Use pyradiomics only if radiomics/SimpleITK are installed.')
    args = parser.parse_args()
    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    labels = pd.read_csv(args.labels)
    labels['id'] = labels['id'].map(normalize_id)
    labels['base_id'] = labels['id'].map(base_patient_id)
    labels['label'] = labels['label'].astype(int)
    labels['state'] = labels['state'].astype(int)
    frame = labels[['id', 'base_id', 'state', 'label']].copy()
    feature_sets: Dict[str, List[str]] = {}
    available_min = [c for c in CLINICAL_MINIMAL if c in labels.columns]
    available_ext = [c for c in CLINICAL_EXTENDED if c in labels.columns]
    for c in sorted(set(available_min + available_ext)):
        frame[c] = pd.to_numeric(labels[c], errors='coerce')
    if available_min:
        feature_sets['clinical_minimal_length_cea'] = available_min
    if available_ext:
        feature_sets['clinical_extended_no_tnmq'] = available_ext
    geo = load_geometry(Path(args.index), Path(args.patient_index))
    geo['id'] = geo['id'].map(normalize_id)
    geo_cols = [c for c in geo.columns if c.startswith('geo_')]
    frame = frame.merge(geo[['id'] + geo_cols], on='id', how='left')
    feature_sets['roi_geometry'] = geo_cols
    if available_min:
        feature_sets['clinical_minimal_plus_geometry'] = available_min + geo_cols
    if available_ext:
        feature_sets['clinical_extended_plus_geometry'] = available_ext + geo_cols
    radiomics_note = 'Radiomics extraction was not requested.'
    if args.radiomics != 'none':
        cache = out / f'{args.radiomics}_radiomics_features.csv'
        if cache.exists():
            rad = pd.read_csv(cache)
            radiomics_note = f'Loaded cached {args.radiomics} radiomics features from {cache}.'
        elif args.radiomics == 'simple':
            rad = extract_simple_radiomics(labels, Path(args.roi_dir))
            rad.to_csv(cache, index=False)
            radiomics_note = 'Extracted simple first-order crop-intensity radiomics-like features with nibabel.'
        else:
            rad = extract_pyradiomics(labels, Path(args.roi_dir), cache)
            radiomics_note = 'Extracted PyRadiomics first-order, texture, and shape features from nonzero crop masks.'
        rad['id'] = rad['id'].map(normalize_id)
        rad_cols = [c for c in rad.columns if c != 'id']
        frame = frame.merge(rad, on='id', how='left')
        feature_sets[f'{args.radiomics}_radiomics'] = rad_cols
        if available_min:
            feature_sets[f'{args.radiomics}_radiomics_plus_clinical_minimal'] = rad_cols + available_min
    y = frame['label'].to_numpy(dtype=int)
    groups = frame['base_id'].to_numpy()
    splits = make_splits(y, groups, args.n_splits, args.seed, args.split_strategy)
    requested_models = [m.strip() for m in args.models.split(',') if m.strip()]
    all_factories = model_factories(args.seed)
    unknown = [m for m in requested_models if m not in all_factories]
    if unknown:
        raise ValueError(f'Unknown model(s): {unknown}. Available: {sorted(all_factories)}')
    factories = {m: all_factories[m] for m in requested_models}
    rows = []
    pred_frames = []
    fold_frames = []
    for feature_set, cols in feature_sets.items():
        cols = [c for c in cols if c in frame.columns]
        if not cols:
            continue
        for model_name, model in factories.items():
            row, pred_df, fold_df = run_oof(frame, cols, feature_set, model_name, model, splits)
            row.update(grouped_bootstrap_ci(y, pred_df['prob_pos'].to_numpy(), groups, args.n_boot, args.seed))
            rows.append(row)
            pred_frames.append(pred_df)
            fold_frames.append(fold_df)
    summary = pd.DataFrame(rows).sort_values(['auc', 'acc'], ascending=[False, False])
    preds = pd.concat(pred_frames, ignore_index=True)
    folds = pd.concat(fold_frames, ignore_index=True)
    summary.to_csv(out / 'standard_baseline_summary.csv', index=False)
    preds.to_csv(out / 'standard_baseline_oof_predictions.csv', index=False)
    folds.to_csv(out / 'standard_baseline_fold_metrics.csv', index=False)
    prevalence = pd.DataFrame([{'record_n': int(len(frame)), 'base_patient_n': int(pd.Series(groups).nunique()), 'positive_n': int(y.sum()), 'negative_n': int((y == 0).sum()), 'prevalence': float(y.mean()), 'split_strategy': args.split_strategy}])
    prevalence.to_csv(out / 'cohort_prevalence.csv', index=False)
    paired_rows = []
    fusion_path = Path(args.fusion_oof)
    if fusion_path.exists():
        fusion = pd.read_csv(fusion_path)
        if 'pid' in fusion.columns:
            fusion['id'] = fusion['pid'].map(normalize_id)
            fusion_score = build_selected_fusion_score(fusion)
            if fusion_score is not None:
                fusion_tmp = fusion[['id', 'label']].copy()
                fusion_tmp['fusion_selected_auc'] = fusion_score
                for _, b in summary.head(12).iterrows():
                    mask = (preds['feature_set'] == b['feature_set']) & (preds['model'] == b['model'])
                    bp = preds.loc[mask, ['id', 'label', 'base_id', 'prob_pos']]
                    merged = bp.merge(fusion_tmp, on=['id', 'label'], how='inner')
                    if len(merged) == len(bp):
                        diff = paired_group_bootstrap_diff(merged['label'].to_numpy(dtype=int), merged['fusion_selected_auc'].to_numpy(dtype=float), merged['prob_pos'].to_numpy(dtype=float), merged['base_id'].to_numpy(), args.n_boot, args.seed)
                        diff.update({'contrast': f"selected_fusion_minus_{b['feature_set']}__{b['model']}", 'baseline_auc': float(b['auc']), 'fusion_auc': safe_auc(merged['label'].to_numpy(dtype=int), merged['fusion_selected_auc'].to_numpy(dtype=float))})
                        paired_rows.append(diff)
    if paired_rows:
        pd.DataFrame(paired_rows).to_csv(out / 'paired_group_bootstrap_vs_selected_fusion.csv', index=False)
    show_cols = ['feature_set', 'model', 'n_features', 'auc', 'auc_ci_low', 'auc_ci_high', 'acc', 'f1', 'sensitivity', 'specificity', 'brier', 'ece', 'calibration_slope', 'tn', 'fp', 'fn', 'tp']
    report = ['# Standard Clinical, Geometry, and Radiomics Baselines', '', f'Records: {len(frame)}; base-patient groups: {pd.Series(groups).nunique()}; positive class records: {int(y.sum())}; negative class records: {int((y == 0).sum())}; prevalence: {y.mean():.3f}.', f'Cross-validation: {args.n_splits}-fold {args.split_strategy} split, seed {args.seed}.', f'Uncertainty: grouped bootstrap over base-patient IDs, {args.n_boot} resamples.', '', radiomics_note, '', '## Top Baselines', '', markdown_table(summary[show_cols], max_rows=30), '', '## Interpretation Notes', '', '- These are standard non-deep baselines for reviewer positioning, not additional selected components of the proposed network.', '- Clinical baselines exclude encoded T/N/M/Q variables because their relationship to the endpoint is unresolved.', '- Geometry features are based on ROI coordinate extents and remain label-adjacent if the endpoint reflects size-based staging.', '- The 0.5 threshold is reported for confusion matrices; threshold-optimized operating points should be estimated in nested training folds before clinical interpretation.', '']
    if paired_rows:
        paired = pd.DataFrame(paired_rows)
        report.extend(['## Paired Grouped Bootstrap Against Selected Fusion', '', markdown_table(paired[['contrast', 'fusion_auc', 'baseline_auc', 'auc_diff', 'auc_diff_ci_low', 'auc_diff_ci_high', 'bootstrap_p_two_sided']], max_rows=12), '', 'These contrasts remain selection-conditioned because the fusion score was chosen from a search.', ''])
    (out / 'standard_baseline_report.md').write_text('\n'.join(report), encoding='utf-8')
    print('\n'.join(report))
if __name__ == '__main__':
    main()
