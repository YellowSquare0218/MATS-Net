from _paths import project_path as _project_path
import argparse
import copy
import json
import types
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import run_heef_262_fully_nested as nested

def plain_image_features(self, volumes, intervention_mask=None):
    x = torch.cat(volumes, dim=1)
    if intervention_mask is not None:
        x = x * intervention_mask.to(x.device)
    return self.encoder.forward_features(x)

def masked_tabular_features(self, image_feats, tabular):
    if tabular is None:
        tabular = image_feats.new_zeros(image_feats.shape[0], self.tab_dim)
    tabular = tabular.to(image_feats.device, dtype=image_feats.dtype)
    return self._unmasked_fuse_tabular(image_feats, tabular * self.ablation_tabular_mask)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path(_project_path('')))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--mode', choices=['smoke', 'run'], required=True)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--max-epochs', type=int, default=80)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--workers', type=int, default=4)
    parser.add_argument('--variants', nargs='+', default=['full_matched', 'no_auxiliary_heads', 'simple_concat_with_aux'], choices=['full_matched', 'no_auxiliary_heads', 'simple_concat_with_aux', 'no_clinical', 'no_geometry', 'no_state_head', 'no_node_head'])
    args = parser.parse_args()
    torch.set_num_threads(8)
    base, configs, prepared, _, _ = nested.load_inputs(args)
    core = nested.core
    expert = 'gmara_burden_w004'
    reference = args.project / 'training_results/grouped_deep_recompute_aug262' / expert
    splits, _ = core.make_cv_splits(base, base.label.to_numpy(), 'group', 42)
    for fold, (_, iv) in enumerate(splits, 1):
        old = pd.read_csv(reference / f'fold_{fold}/predictions.csv', dtype={'pid': str})
        assert set(old.pid) == set(base.iloc[iv].id)
    columns = prepared[expert][1]
    core.CLINICAL_FEATURE_COLS = [c.removeprefix('clin_') for c in columns if c.startswith('clin_')]
    core.NUM_WORKERS = args.workers
    core.NUM_EPOCHS, core.EARLY_STOP_PATIENCE = (args.max_epochs, args.patience)
    original_factory = core.get_fusion
    variants = args.variants
    protocol = {'variants': variants, 'n': 262, 'seed': args.seed, 'reference': str(reference), 'columns': columns, 'folds': [{'fold': f, 'train': base.iloc[it].id.tolist(), 'validation': base.iloc[iv].id.tolist()} for f, (it, iv) in enumerate(splits, 1)], 'no_auxiliary_heads': 'disable nodal and state head losses; preserve supervised contrastive and perturbation regularization', 'no_state_head': 'disable only state classification loss; preserve nodal head, state-based supervised contrastive loss and perturbation regularization', 'no_node_head': 'disable only nodal classification loss; preserve state head, supervised contrastive loss and perturbation regularization', 'max_epochs': args.max_epochs, 'patience': args.patience, 'simple_concat_with_aux': 'bypass residual modality-query attention; concatenate encoder feature and unchanged tabular feature', 'initialization': 'construct identical full model before disabling components', 'no_clinical': 'zero all standardized clin_ inputs before tabular LayerNorm in training and inference; retain dimensions, auxiliary heads, and initialization', 'no_geometry': 'zero all standardized geo_ inputs before tabular LayerNorm in training and inference; image ROI crops unchanged', 'evaluation': 'historical best-validation checkpoint protocol; exploratory, not independent nested test'}
    nested.write_json(args.output / 'matched_protocol.json', protocol)
    for variant in variants:
        smoke_models = []

        def factory(kind, backbone, classes, **kwargs):
            model = original_factory(kind, backbone, classes, **kwargs)
            if variant in ['no_clinical', 'no_geometry']:
                prefix = 'clin_' if variant == 'no_clinical' else 'geo_'
                keep = torch.tensor([not c.startswith(prefix) for c in columns], dtype=torch.float32)
                assert 0 < keep.sum() < len(columns) and model.tab_dim == len(columns)
                model.register_buffer('ablation_tabular_mask', keep)
                model._unmasked_fuse_tabular = model._fuse_tabular
                model._fuse_tabular = types.MethodType(masked_tabular_features, model)
                state = torch.random.get_rng_state()
                model.eval()
                with torch.no_grad():
                    image_feats = torch.randn(2, model.feat_dim)
                    tab = torch.randn(2, model.tab_dim)
                    changed = tab + (1 - keep) * 100
                    assert torch.equal(model._fuse_tabular(image_feats, tab), model._fuse_tabular(image_feats, changed))
                model.train()
                torch.random.set_rng_state(state)
            if variant == 'no_auxiliary_heads':
                model.use_state_aux = model.use_node_aux = False
                model.aux_state_weight = model.aux_node_weight = 0.0
                for head in [model.state_head, model.node_head]:
                    for parameter in head.parameters():
                        parameter.requires_grad_(False)
            if variant in ['no_state_head', 'no_node_head']:
                removed = 'state' if variant == 'no_state_head' else 'node'
                retained = 'node' if removed == 'state' else 'state'
                assert getattr(model, f'use_{removed}_aux')
                assert getattr(model, f'use_{retained}_aux')
                setattr(model, f'use_{removed}_aux', False)
                setattr(model, f'aux_{removed}_weight', 0.0)
                for parameter in getattr(model, f'{removed}_head').parameters():
                    parameter.requires_grad_(False)
            if variant == 'simple_concat_with_aux':
                model._image_features = types.MethodType(plain_image_features, model)
                model.mod_queries.requires_grad_(False)
                model.gamma.requires_grad_(False)
                for parameter in model.pre_attn_norm.parameters():
                    parameter.requires_grad_(False)
            if args.mode == 'smoke':
                smoke_models.append(model)
            return model
        core.get_fusion = factory
        config = copy.deepcopy(configs[expert])
        config.update(train_seed=args.seed, fold_seed=42, output_dir=str(args.output / variant))
        if args.mode == 'smoke':

            def build(c, kw, device):
                return (factory(c['fusion'], c['model_name'], 2, **kw).to(device), True)
            it, iv = splits[0]
            result, _ = nested.fit_deep(args, variant, config, prepared[expert], it, iv, args.output / 'smoke' / variant, args.seed, nested.digest(protocol), epochs=1, smoke=True, model_factory=build)
            if variant in ['no_state_head', 'no_node_head']:
                model = smoke_models[-1]
                removed = 'state' if variant == 'no_state_head' else 'node'
                retained = 'node' if removed == 'state' else 'state'
                assert all((p.grad is None and (not p.requires_grad) for p in getattr(model, f'{removed}_head').parameters()))
                assert any((p.grad is not None and torch.isfinite(p.grad).all() and (p.grad.abs().sum() > 0) for p in getattr(model, f'{retained}_head').parameters()))
                result['removed_head_no_gradient'] = removed
                result['retained_head_finite_nonzero_gradient'] = retained
            nested.write_json(args.output / 'smoke' / variant / 'verified.json', result)
        else:
            assert (args.output / 'smoke_passed.json').exists()
            output = Path(config['output_dir'])
            if (output / 'cv_summary.json').exists():
                continue
            if list(output.glob('fold_*/best_model.pth')):
                raise RuntimeError('Partial run exists; preserve checkpoints and resume explicitly')
            nested.write_json(output / 'component_change.json', {'variant': variant, 'config': config})
            core.run_experiment(config)
            summary = json.loads((output / 'cv_summary.json').read_text())
            assert summary['tabular_cols'] == columns
            for fold, (_, iv) in enumerate(splits, 1):
                pred = pd.read_csv(output / f'fold_{fold}/predictions.csv', dtype={'pid': str})
                assert set(pred.pid) == set(base.iloc[iv].id)
    if args.mode == 'smoke':
        nested.write_json(args.output / 'smoke_passed.json', {'variants': variants})
    else:
        rows = []
        for variant in variants:
            d = pd.read_csv(args.output / variant / 'all_predictions.csv')
            assert len(d) == 262 and d.pid.is_unique
            rows.append({'variant': variant, **nested.fusion.metrics(d.label.to_numpy(), d.prob_pos.to_numpy())})
        pd.DataFrame(rows).to_csv(args.output / 'matched_metrics.csv', index=False)
        nested.write_json(args.output / 'complete.json', {'completed': variants})
if __name__ == '__main__':
    main()
