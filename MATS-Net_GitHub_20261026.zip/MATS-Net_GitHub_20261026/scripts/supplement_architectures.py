import torch
from torch import nn
from monai.networks.nets import resnet18
from monai.networks.nets.swin_unetr import SwinTransformer
import net_family_3d as nets

class ResNet18Features(nn.Module):

    def __init__(self, in_chans=1, num_classes=2):
        super().__init__()
        self.encoder = resnet18(pretrained=False, spatial_dims=3, n_input_channels=in_chans, feed_forward=False, shortcut_type='B')
        self.projection = nn.Linear(512, 768)
        self.head = nn.Linear(768, num_classes)

    def forward_features(self, x):
        if not torch.is_grad_enabled() and x.device.type == 'cpu' and (x.shape[0] == 1) and self.training:
            self.encoder.eval()
            z = self.encoder(x)
            self.encoder.train()
        else:
            z = self.encoder(x)
        return self.projection(z)

    def forward(self, x):
        return self.head(self.forward_features(x))

class SwinSmallFeatures(nn.Module):

    def __init__(self, in_chans=1, num_classes=2):
        super().__init__()
        self.encoder = SwinTransformer(in_chans=in_chans, embed_dim=48, window_size=(2, 4, 4), patch_size=(2, 2, 2), depths=(2, 2, 2, 2), num_heads=(3, 6, 12, 24), spatial_dims=3, downsample='mergingv2', drop_path_rate=0.1, use_checkpoint=False)
        self.norm = nn.LayerNorm(768)
        self.head = nn.Linear(768, num_classes)

    def forward_features(self, x):
        return self.norm(self.encoder(x)[-1].mean(dim=(2, 3, 4)))

    def forward(self, x):
        return self.head(self.forward_features(x))

def build_model(config, fusion_kwargs, device):
    constructors = {'resnet18_monai': ResNet18Features, 'swin_small_monai': SwinSmallFeatures, 'convnext3d_tiny': nets.MODELS['convnext3d_tiny']}
    backbone = constructors[config['model_name']]
    if config.get('fusion'):
        model = nets.FUSION_STRATEGIES[config['fusion']](backbone, 2, **fusion_kwargs)
    else:
        model = backbone(in_chans=len(config['modalities']), num_classes=2)
    return (model.to(device), bool(config.get('fusion')))
