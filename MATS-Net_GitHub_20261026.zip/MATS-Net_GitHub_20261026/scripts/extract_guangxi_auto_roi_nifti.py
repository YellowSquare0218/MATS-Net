from __future__ import annotations
import argparse
import csv
import json
import os
import shutil
import sys
import tempfile
import time
import zipfile
from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Tuple
import nibabel as nib
import numpy as np
import pandas as pd
import SimpleITK as sitk
from scipy.ndimage import gaussian_filter, zoom
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from inventory_guangxi_zip_dicoms import decode_zip_name
MOD_OUT_NAMES = {'T2W': 'T2W', 'DWI': 'DWI', 'T1C': 'T1C', 'T1W': 'T1W', 'ADC': 'ADC'}

def safe_instance_number(value: object) -> int:
    try:
        return int(float(str(value or '0').split('\\')[0]))
    except Exception:
        return 0

def truthy(value: object) -> bool:
    return str(value).strip() in {'1', '1.0', 'True', 'true', 'TRUE'}

def build_zip_name_map(zf: zipfile.ZipFile) -> Dict[str, str]:
    mapping = {}
    for info in zf.infolist():
        if not info.is_dir():
            mapping[decode_zip_name(info.filename)] = info.filename
    return mapping

def load_manifest(path: str, only_usable_column: str, max_patients: int) -> pd.DataFrame:
    manifest = pd.read_csv(path)
    manifest['patient_id'] = manifest['patient_id'].astype(str).str.upper()
    if only_usable_column:
        manifest = manifest[manifest[only_usable_column].map(truthy)].copy()
    if max_patients and max_patients > 0:
        manifest = manifest.head(max_patients).copy()
    return manifest

def load_file_index(path: str, patient_ids: Iterable[str], modalities: Iterable[str]) -> Dict[Tuple[str, str], List[Dict[str, object]]]:
    patient_set = {str(pid).upper() for pid in patient_ids}
    modality_set = set(modalities)
    grouped: Dict[Tuple[str, str], List[Dict[str, object]]] = defaultdict(list)
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            patient_id = (row.get('patient_id') or '').upper()
            modality = row.get('target_modality') or ''
            if patient_id not in patient_set or modality not in modality_set:
                continue
            grouped[patient_id, modality].append(row)
    for key in list(grouped):
        grouped[key].sort(key=lambda r: (safe_instance_number(r.get('instance_number')), r.get('zip_member') or ''))
    return grouped

def extract_one_series(zf: zipfile.ZipFile, zip_name_map: Dict[str, str], rows: List[Dict[str, object]], temp_dir: str) -> List[str]:
    os.makedirs(temp_dir, exist_ok=True)
    out_files = []
    for idx, row in enumerate(rows):
        decoded = str(row['zip_member'])
        raw = zip_name_map.get(decoded)
        if not raw:
            raise FileNotFoundError(f'ZIP member not found: {decoded}')
        out_path = os.path.join(temp_dir, f'{idx:04d}.dcm')
        with zf.open(raw) as src, open(out_path, 'wb') as dst:
            shutil.copyfileobj(src, dst)
        out_files.append(out_path)
    return out_files

def read_series_image(file_paths: List[str]) -> sitk.Image:
    reader = sitk.ImageSeriesReader()
    reader.SetFileNames(file_paths)
    return reader.Execute()

def robust_normalize(arr: np.ndarray) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float32)
    finite = arr[np.isfinite(arr)]
    if finite.size == 0:
        return np.zeros_like(arr, dtype=np.float32)
    lo, hi = np.percentile(finite, [1, 99.5])
    if hi <= lo:
        lo, hi = (float(np.min(finite)), float(np.max(finite)))
    if hi <= lo:
        return np.zeros_like(arr, dtype=np.float32)
    out = (arr - lo) / (hi - lo)
    return np.clip(out, 0, 1).astype(np.float32)

def find_hotspot_physical(image: sitk.Image, search_xy_fraction: float=0.7) -> Tuple[Tuple[float, float, float], Dict[str, object]]:
    arr = sitk.GetArrayFromImage(image).astype(np.float32)
    norm = robust_normalize(arr)
    zdim, ydim, xdim = norm.shape
    if min(norm.shape) < 3:
        center_idx = (xdim / 2.0, ydim / 2.0, zdim / 2.0)
        return (image.TransformContinuousIndexToPhysicalPoint(center_idx), {'mode': 'fallback_center_small_volume'})
    frac = float(np.clip(search_xy_fraction, 0.35, 0.95))
    x_margin = int(round((1.0 - frac) * xdim / 2.0))
    y_margin = int(round((1.0 - frac) * ydim / 2.0))
    z_margin = max(0, int(round(0.05 * zdim)))
    search = np.zeros_like(norm, dtype=bool)
    search[z_margin:zdim - z_margin or zdim, y_margin:ydim - y_margin or ydim, x_margin:xdim - x_margin or xdim] = True
    zz, yy, xx = np.indices(norm.shape)
    x0 = (xdim - 1) / 2.0
    y0 = (ydim - 1) / 2.0
    sx = max(1.0, xdim * 0.28)
    sy = max(1.0, ydim * 0.28)
    central_weight = np.exp(-(((xx - x0) / sx) ** 2 + ((yy - y0) / sy) ** 2) / 2.0).astype(np.float32)
    score = norm * central_weight
    score[~search] = 0
    score = gaussian_filter(score, sigma=(0.8, 2.0, 2.0))
    if float(np.max(score)) <= 0:
        center_idx = (xdim / 2.0, ydim / 2.0, zdim / 2.0)
        return (image.TransformContinuousIndexToPhysicalPoint(center_idx), {'mode': 'fallback_center_zero_score'})
    max_zyx = np.unravel_index(int(np.argmax(score)), score.shape)
    zc, yc, xc = [int(v) for v in max_zyx]
    z0, z1 = (max(0, zc - 3), min(zdim, zc + 4))
    y0i, y1i = (max(0, yc - 24), min(ydim, yc + 25))
    x0i, x1i = (max(0, xc - 24), min(xdim, xc + 25))
    patch = score[z0:z1, y0i:y1i, x0i:x1i]
    if patch.size and float(np.max(patch)) > 0:
        cutoff = np.percentile(patch, 90)
        weights = np.where(patch >= cutoff, patch, 0)
        if float(weights.sum()) > 0:
            pz, py, px = np.indices(patch.shape)
            zc = float((weights * (pz + z0)).sum() / weights.sum())
            yc = float((weights * (py + y0i)).sum() / weights.sum())
            xc = float((weights * (px + x0i)).sum() / weights.sum())
    continuous_idx = (float(xc), float(yc), float(zc))
    physical = image.TransformContinuousIndexToPhysicalPoint(continuous_idx)
    meta = {'mode': 'hotspot', 'hotspot_index_xyz': [float(xc), float(yc), float(zc)], 'hotspot_score': float(np.max(score)), 'locator_shape_zyx': [int(v) for v in norm.shape]}
    return (physical, meta)

def crop_with_padding(arr: np.ndarray, center_xyz: Tuple[float, float, float], spacing_xyz: Tuple[float, float, float], crop_xy_mm: float, crop_z_mm: float) -> np.ndarray:
    zdim, ydim, xdim = arr.shape
    cx, cy, cz = center_xyz
    sx, sy, sz = [max(float(v), 0.001) for v in spacing_xyz]
    half_x = max(8, int(round(crop_xy_mm / (2.0 * sx))))
    half_y = max(8, int(round(crop_xy_mm / (2.0 * sy))))
    half_z = max(2, int(round(crop_z_mm / (2.0 * sz))))
    out_shape = (2 * half_z + 1, 2 * half_y + 1, 2 * half_x + 1)
    out = np.zeros(out_shape, dtype=np.float32)

    def bounds(center: float, half: int, dim: int) -> Tuple[int, int, int]:
        size = 2 * half + 1
        raw_start = int(round(center)) - half
        if size <= dim:
            src0 = max(0, min(raw_start, dim - size))
            return (src0, src0 + size, 0)
        src0 = 0
        dst0 = max(0, (size - dim) // 2)
        return (src0, dim, dst0)
    src_z0, src_z1, dst_z0 = bounds(cz, half_z, zdim)
    src_y0, src_y1, dst_y0 = bounds(cy, half_y, ydim)
    src_x0, src_x1, dst_x0 = bounds(cx, half_x, xdim)
    out[dst_z0:dst_z0 + (src_z1 - src_z0), dst_y0:dst_y0 + (src_y1 - src_y0), dst_x0:dst_x0 + (src_x1 - src_x0)] = arr[src_z0:src_z1, src_y0:src_y1, src_x0:src_x1]
    return out

def resize_to_training_shape(arr_zyx: np.ndarray, target_z: int=16, target_xy: int=64) -> np.ndarray:
    factors = (target_z / arr_zyx.shape[0], target_xy / arr_zyx.shape[1], target_xy / arr_zyx.shape[2])
    resized = zoom(arr_zyx.astype(np.float32), factors, order=1)
    return np.transpose(resized, (2, 1, 0)).astype(np.float32)

def physical_to_index_or_center(image: sitk.Image, physical: Tuple[float, float, float]) -> Tuple[float, float, float]:
    try:
        idx = image.TransformPhysicalPointToContinuousIndex(physical)
        size = image.GetSize()
        if all((np.isfinite(idx[i]) for i in range(3))):
            return tuple((float(np.clip(idx[i], 0, max(0, size[i] - 1))) for i in range(3)))
    except Exception:
        pass
    size = image.GetSize()
    return (size[0] / 2.0, size[1] / 2.0, size[2] / 2.0)

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip-path', required=True)
    parser.add_argument('--file-index', required=True)
    parser.add_argument('--validation-manifest', required=True)
    parser.add_argument('--out-dir', required=True)
    parser.add_argument('--modalities', nargs='+', default=['T2W'])
    parser.add_argument('--locator-modality', default='DWI')
    parser.add_argument('--fallback-locator-modality', default='T2W')
    parser.add_argument('--only-usable-column', default='can_validate_t2_dwi_t_stage')
    parser.add_argument('--max-patients', type=int, default=0)
    parser.add_argument('--crop-xy-mm', type=float, default=90.0)
    parser.add_argument('--crop-z-mm', type=float, default=64.0)
    parser.add_argument('--target-xy', type=int, default=64)
    parser.add_argument('--target-z', type=int, default=16)
    parser.add_argument('--search-xy-fraction', type=float, default=0.7)
    parser.add_argument('--keep-temp', action='store_true')
    args = parser.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    started = time.time()
    manifest = load_manifest(args.validation_manifest, args.only_usable_column, args.max_patients)
    patient_ids = manifest['patient_id'].tolist()
    needed_modalities = set(args.modalities) | {args.locator_modality, args.fallback_locator_modality}
    grouped = load_file_index(args.file_index, patient_ids, needed_modalities)
    records = []
    centers = []
    failures = []
    with zipfile.ZipFile(args.zip_path) as zf:
        zip_name_map = build_zip_name_map(zf)
        for _, row in manifest.iterrows():
            patient_id = row['patient_id']
            patient_dir = os.path.join(args.out_dir, patient_id)
            os.makedirs(patient_dir, exist_ok=True)
            locator_used = args.locator_modality
            locator_rows = grouped.get((patient_id, locator_used), [])
            if not locator_rows:
                locator_used = args.fallback_locator_modality
                locator_rows = grouped.get((patient_id, locator_used), [])
            if not locator_rows:
                failures.append({'patient_id': patient_id, 'modality': 'LOCATOR', 'error': 'missing_locator'})
                continue
            locator_tmp = tempfile.mkdtemp(prefix=f'{patient_id}_{locator_used}_locator_')
            try:
                locator_files = extract_one_series(zf, zip_name_map, locator_rows, locator_tmp)
                locator_image = read_series_image(locator_files)
                physical_center, center_meta = find_hotspot_physical(locator_image, args.search_xy_fraction)
            except Exception as exc:
                failures.append({'patient_id': patient_id, 'modality': 'LOCATOR', 'error': repr(exc)})
                if not args.keep_temp:
                    shutil.rmtree(locator_tmp, ignore_errors=True)
                continue
            finally:
                if not args.keep_temp:
                    shutil.rmtree(locator_tmp, ignore_errors=True)
            patient_ok = True
            centers.append({'patient_id': patient_id, 'locator_modality': locator_used, 'physical_x': physical_center[0], 'physical_y': physical_center[1], 'physical_z': physical_center[2], **center_meta})
            for modality in args.modalities:
                rows = grouped.get((patient_id, modality), [])
                if not rows:
                    failures.append({'patient_id': patient_id, 'modality': modality, 'error': 'missing_file_index_rows'})
                    patient_ok = False
                    continue
                tmp_parent = tempfile.mkdtemp(prefix=f'{patient_id}_{modality}_')
                try:
                    dicom_files = extract_one_series(zf, zip_name_map, rows, tmp_parent)
                    image = read_series_image(dicom_files)
                    arr = sitk.GetArrayFromImage(image).astype(np.float32)
                    center_idx_xyz = physical_to_index_or_center(image, physical_center)
                    crop = crop_with_padding(arr, center_idx_xyz, image.GetSpacing(), args.crop_xy_mm, args.crop_z_mm)
                    data = resize_to_training_shape(crop, target_z=args.target_z, target_xy=args.target_xy)
                    out_name = MOD_OUT_NAMES[modality] + '.nii.gz'
                    nib.save(nib.Nifti1Image(data, np.eye(4)), os.path.join(patient_dir, out_name))
                    records.append({'patient_id': patient_id, 'modality': modality, 'locator_modality': locator_used, 'dicom_files': len(rows), 'raw_shape_zyx': 'x'.join((str(v) for v in arr.shape)), 'crop_shape_zyx': 'x'.join((str(v) for v in crop.shape)), 'out_shape_xyz': 'x'.join((str(v) for v in data.shape)), 'center_index_xyz': 'x'.join((f'{v:.2f}' for v in center_idx_xyz)), 'out_path': os.path.join(patient_dir, out_name)})
                except Exception as exc:
                    failures.append({'patient_id': patient_id, 'modality': modality, 'error': repr(exc)})
                    patient_ok = False
                finally:
                    if not args.keep_temp:
                        shutil.rmtree(tmp_parent, ignore_errors=True)
            if not patient_ok:
                continue
    index_rows = []
    for _, row in manifest.iterrows():
        patient_id = row['patient_id']
        expected = [os.path.join(args.out_dir, patient_id, MOD_OUT_NAMES[m] + '.nii.gz') for m in args.modalities]
        if all((os.path.exists(p) for p in expected)):
            label = int(float(row['path_T_binary']))
            index_rows.append({'id': patient_id, 'state': 3 if label == 1 else 2, 'label': label})
    pd.DataFrame(index_rows).to_csv(os.path.join(args.out_dir, 'index.csv'), index=False)
    pd.DataFrame(records).to_csv(os.path.join(args.out_dir, 'extraction_records.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(centers).to_csv(os.path.join(args.out_dir, 'roi_centers.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(failures).to_csv(os.path.join(args.out_dir, 'extraction_failures.csv'), index=False, encoding='utf-8-sig')
    summary = {'zip_path': args.zip_path, 'file_index': args.file_index, 'validation_manifest': args.validation_manifest, 'out_dir': args.out_dir, 'modalities': args.modalities, 'locator_modality': args.locator_modality, 'fallback_locator_modality': args.fallback_locator_modality, 'only_usable_column': args.only_usable_column, 'requested_patients': int(len(manifest)), 'successful_patients': int(len(index_rows)), 'extracted_series': int(len(records)), 'failures': int(len(failures)), 'crop_xy_mm': args.crop_xy_mm, 'crop_z_mm': args.crop_z_mm, 'target_shape_xyz': [args.target_xy, args.target_xy, args.target_z], 'elapsed_seconds': round(time.time() - started, 3)}
    with open(os.path.join(args.out_dir, 'extraction_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
