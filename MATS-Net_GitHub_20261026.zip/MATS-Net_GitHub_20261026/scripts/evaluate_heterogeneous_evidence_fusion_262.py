from __future__ import annotations
import argparse
import itertools
import json
import math
import time
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.optimize import minimize
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, log_loss, roc_auc_score, roc_curve
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
DEFAULT_EXPERTS = ['single_T2W', 'single_DWI', 'single_T1C', 'single_T1W', 'gmara_auc', 'gmara_clinical_only', 'geo_lr_c0_3', 'gmara_burden_w004']
DISPLAY = {'single_T2W': 'T2WI expert', 'single_DWI': 'DWI expert', 'single_T1C': 'CE-T1WI expert', 'single_T1W': 'T1WI expert', 'gmara_auc': 'Multisequence G-MARA expert', 'gmara_clinical_only': 'Clinical expert', 'geo_lr_c0_3': 'ROI-geometry expert', 'gmara_burden_w004': 'Auxiliary-task expert', 'graf_full': 'GRAF-MRI expert'}
METHODS = ['best_single', 'unweighted_mean', 'platt_mean', 'beta_mean', 'auc_weighted_mean', 'simplex_logloss', 'logistic_stacking', 'selected_subset_mean', 'rdef']
METHOD_DISPLAY = {'best_single': 'Best single expert', 'unweighted_mean': 'Unweighted mean', 'platt_mean': 'Cross-fitted Platt-calibrated mean', 'beta_mean': 'Cross-fitted beta-calibrated mean', 'auc_weighted_mean': 'AUC-weighted mean', 'simplex_logloss': 'Simplex log-loss weighting', 'logistic_stacking': 'Logistic stacking', 'selected_subset_mean': 'Nested subset mean', 'rdef': 'RDEF (exploratory)', 'selected_upper_bound': 'Selected evidence fusion (upper bound)'}

def sigmoid(value: np.ndarray) -> np.ndarray:
    value = np.clip(np.asarray(value, dtype=float), -30.0, 30.0)
    return 1.0 / (1.0 + np.exp(-value))

def logit(value: np.ndarray) -> np.ndarray:
    value = np.clip(np.asarray(value, dtype=float), 1e-05, 1.0 - 1e-05)
    return np.log(value / (1.0 - value))

def ece_score(y: np.ndarray, score: np.ndarray, n_bins: int=10) -> float:
    edges = np.linspace(0.0, 1.0, n_bins + 1)
    result = 0.0
    for index in range(n_bins):
        right = score <= edges[index + 1] if index == n_bins - 1 else score < edges[index + 1]
        mask = (score >= edges[index]) & right
        if mask.any():
            result += float(mask.mean() * abs(score[mask].mean() - y[mask].mean()))
    return result

def calibration_parameters(y: np.ndarray, score: np.ndarray) -> tuple[float, float]:
    model = LogisticRegression(C=1000000.0, solver='lbfgs', max_iter=3000)
    model.fit(logit(score).reshape(-1, 1), y)
    return (float(model.intercept_[0]), float(model.coef_[0, 0]))

def metrics(y: np.ndarray, score: np.ndarray) -> dict[str, float | int]:
    score = np.clip(np.asarray(score, dtype=float), 1e-06, 1.0 - 1e-06)
    pred = (score >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    intercept, slope = calibration_parameters(y, score)
    return {'n': int(len(y)), 'positive_n': int(y.sum()), 'negative_n': int((y == 0).sum()), 'auc': float(roc_auc_score(y, score)), 'accuracy': float(accuracy_score(y, pred)), 'sensitivity': float(tp / (tp + fn)) if tp + fn else math.nan, 'specificity': float(tn / (tn + fp)) if tn + fp else math.nan, 'f1': float(f1_score(y, pred, zero_division=0)), 'brier': float(brier_score_loss(y, score)), 'ece': float(ece_score(y, score)), 'calibration_intercept': intercept, 'calibration_slope': slope, 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

def bootstrap_indices(y: np.ndarray, n_boot: int, seed: int) -> list[np.ndarray]:
    rng = np.random.default_rng(seed)
    rows: list[np.ndarray] = []
    while len(rows) < n_boot:
        index = rng.integers(0, len(y), size=len(y))
        if np.unique(y[index]).size == 2:
            rows.append(index)
    return rows

def add_bootstrap_ci(row: dict[str, float | int | str], y: np.ndarray, score: np.ndarray, samples: list[np.ndarray]) -> None:
    aucs = np.asarray([roc_auc_score(y[index], score[index]) for index in samples])
    row['auc_ci_low'] = float(np.percentile(aucs, 2.5))
    row['auc_ci_high'] = float(np.percentile(aucs, 97.5))

def reliability_prior(y: np.ndarray, probabilities: np.ndarray) -> np.ndarray:
    margins = np.asarray([max(roc_auc_score(y, probabilities[:, index]) - 0.5, 0.005) for index in range(probabilities.shape[1])])
    return margins / margins.sum()

def residual_redundancy(y: np.ndarray, probabilities: np.ndarray) -> np.ndarray:
    residuals = probabilities - y[:, None]
    matrix = np.abs(np.corrcoef(residuals, rowvar=False))
    matrix = np.nan_to_num(matrix, nan=0.0, posinf=0.0, neginf=0.0)
    np.fill_diagonal(matrix, 0.0)
    return matrix

def fit_simplex(y: np.ndarray, probabilities: np.ndarray, lambda_diversity: float=0.0, gamma_reliability: float=0.0) -> tuple[np.ndarray, dict[str, object]]:
    n_experts = probabilities.shape[1]
    prior = reliability_prior(y, probabilities)
    redundancy = residual_redundancy(y, probabilities)

    def objective(weights: np.ndarray) -> float:
        score = np.clip(probabilities @ weights, 1e-06, 1.0 - 1e-06)
        value = log_loss(y, score, labels=[0, 1])
        value += lambda_diversity * float(weights @ redundancy @ weights)
        value += gamma_reliability * float(np.sum((weights - prior) ** 2))
        return float(value)
    result = minimize(objective, x0=prior, method='SLSQP', bounds=[(0.0, 1.0)] * n_experts, constraints=[{'type': 'eq', 'fun': lambda weights: float(weights.sum() - 1.0)}], options={'maxiter': 1000, 'ftol': 1e-10})
    if not result.success:
        weights = prior
    else:
        weights = np.clip(result.x, 0.0, 1.0)
        weights = weights / weights.sum()
    audit = {'success': bool(result.success), 'message': str(result.message), 'objective': float(objective(weights)), 'lambda_diversity': float(lambda_diversity), 'gamma_reliability': float(gamma_reliability), 'reliability_prior': prior.tolist(), 'mean_absolute_residual_correlation': float(redundancy[np.triu_indices(n_experts, 1)].mean())}
    return (weights, audit)

def select_rdef_hyperparameters(y: np.ndarray, probabilities: np.ndarray, n_splits: int, seed: int) -> tuple[float, float, pd.DataFrame]:
    lambda_grid = [0.0, 0.01, 0.03, 0.1, 0.3]
    gamma_grid = [0.0, 0.01, 0.03, 0.1]
    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    rows = []
    for lambda_value, gamma_value in itertools.product(lambda_grid, gamma_grid):
        fold_losses = []
        fold_aucs = []
        for train_index, validation_index in splitter.split(probabilities, y):
            weights, _ = fit_simplex(y[train_index], probabilities[train_index], lambda_diversity=lambda_value, gamma_reliability=gamma_value)
            score = np.clip(probabilities[validation_index] @ weights, 1e-06, 1.0 - 1e-06)
            fold_losses.append(log_loss(y[validation_index], score, labels=[0, 1]))
            fold_aucs.append(roc_auc_score(y[validation_index], score))
        rows.append({'lambda_diversity': lambda_value, 'gamma_reliability': gamma_value, 'mean_log_loss': float(np.mean(fold_losses)), 'mean_auc': float(np.mean(fold_aucs))})
    frame = pd.DataFrame(rows).sort_values(['mean_log_loss', 'mean_auc', 'lambda_diversity', 'gamma_reliability'], ascending=[True, False, True, True])
    best = frame.iloc[0]
    return (float(best['lambda_diversity']), float(best['gamma_reliability']), frame)

def select_logistic_c(y: np.ndarray, probabilities: np.ndarray, n_splits: int, seed: int) -> tuple[float, pd.DataFrame]:
    c_grid = [0.01, 0.03, 0.1, 0.3, 1.0, 3.0, 10.0]
    features = logit(probabilities)
    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    rows = []
    for c_value in c_grid:
        losses = []
        aucs = []
        for train_index, validation_index in splitter.split(features, y):
            model = make_pipeline(StandardScaler(), LogisticRegression(C=c_value, solver='lbfgs', max_iter=3000))
            model.fit(features[train_index], y[train_index])
            score = model.predict_proba(features[validation_index])[:, 1]
            losses.append(log_loss(y[validation_index], score, labels=[0, 1]))
            aucs.append(roc_auc_score(y[validation_index], score))
        rows.append({'C': c_value, 'mean_log_loss': np.mean(losses), 'mean_auc': np.mean(aucs)})
    frame = pd.DataFrame(rows).sort_values(['mean_log_loss', 'mean_auc', 'C'], ascending=[True, False, True])
    return (float(frame.iloc[0]['C']), frame)

def select_subset(y: np.ndarray, probabilities: np.ndarray) -> tuple[list[int], pd.DataFrame]:
    rows = []
    n_experts = probabilities.shape[1]
    for size in range(1, n_experts + 1):
        for subset in itertools.combinations(range(n_experts), size):
            score = probabilities[:, subset].mean(axis=1)
            rows.append({'indices': list(subset), 'n_experts': size, 'auc': roc_auc_score(y, score), 'brier': brier_score_loss(y, score)})
    frame = pd.DataFrame(rows).sort_values(['auc', 'n_experts', 'brier'], ascending=[False, True, True])
    return (list(frame.iloc[0]['indices']), frame)

def holm_adjust(p_values: list[float]) -> list[float]:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    adjusted = np.empty_like(values)
    running = 0.0
    total = len(values)
    for rank, index in enumerate(order):
        current = min(1.0, (total - rank) * values[index])
        running = max(running, current)
        adjusted[index] = running
    return adjusted.tolist()

def paired_auc_contrasts(y: np.ndarray, predictions: pd.DataFrame, reference: str, candidates: list[str], samples: list[np.ndarray]) -> pd.DataFrame:
    rows = []
    ref_score = predictions[reference].to_numpy(dtype=float)
    ref_auc = roc_auc_score(y, ref_score)
    for candidate in candidates:
        score = predictions[candidate].to_numpy(dtype=float)
        delta = roc_auc_score(y, ref_score) - roc_auc_score(y, score)
        boot = np.asarray([roc_auc_score(y[index], ref_score[index]) - roc_auc_score(y[index], score[index]) for index in samples])
        p_value = min(1.0, 2.0 * min(float((boot <= 0).mean()), float((boot >= 0).mean())))
        rows.append({'candidate': METHOD_DISPLAY[reference], 'reference': METHOD_DISPLAY[candidate], 'candidate_auc': ref_auc, 'reference_auc': roc_auc_score(y, score), 'delta_auc': delta, 'ci_low': float(np.percentile(boot, 2.5)), 'ci_high': float(np.percentile(boot, 97.5)), 'p_raw': p_value})
    frame = pd.DataFrame(rows)
    frame['p_holm'] = holm_adjust(frame['p_raw'].tolist())
    return frame

def decision_curve(y: np.ndarray, predictions: pd.DataFrame, methods: list[str]) -> pd.DataFrame:
    rows = []
    prevalence = float(y.mean())
    n = len(y)
    for threshold in np.arange(0.05, 0.76, 0.01):
        odds = threshold / (1.0 - threshold)
        rows.append({'threshold': threshold, 'method': 'treat_none', 'net_benefit': 0.0})
        rows.append({'threshold': threshold, 'method': 'treat_all', 'net_benefit': prevalence - (1.0 - prevalence) * odds})
        for method in methods:
            pred = predictions[method].to_numpy(dtype=float) >= threshold
            tp = int(((pred == 1) & (y == 1)).sum())
            fp = int(((pred == 1) & (y == 0)).sum())
            rows.append({'threshold': threshold, 'method': method, 'net_benefit': tp / n - fp / n * odds})
    return pd.DataFrame(rows)

def save_figures(output: Path, y: np.ndarray, predictions: pd.DataFrame, correlation: pd.DataFrame, weights: pd.DataFrame, contrasts: pd.DataFrame) -> None:
    plt.rcParams.update({'font.family': 'DejaVu Sans', 'font.size': 9, 'axes.spines.top': False, 'axes.spines.right': False})
    colors = ['#2374AB', '#2A9D8F', '#E9C46A', '#E76F51', '#7B2CBF', '#555555', '#D62828']
    fig, ax = plt.subplots(figsize=(7.2, 6.1))
    image = ax.imshow(correlation.to_numpy(), vmin=-1, vmax=1, cmap='coolwarm')
    ax.set_xticks(range(len(correlation)), [DISPLAY.get(item, item) for item in correlation], rotation=45, ha='right')
    ax.set_yticks(range(len(correlation)), [DISPLAY.get(item, item) for item in correlation])
    fig.colorbar(image, ax=ax, fraction=0.046, pad=0.04, label='Spearman correlation')
    ax.set_title('OOF expert score correlation')
    fig.tight_layout()
    fig.savefig(output / 'expert_correlation.png', dpi=300)
    fig.savefig(output / 'expert_correlation.tiff', dpi=300)
    plt.close(fig)
    pivot = weights.pivot(index='outer_fold', columns='expert', values='weight').fillna(0.0)
    fig, ax = plt.subplots(figsize=(8.2, 4.6))
    bottom = np.zeros(len(pivot))
    for color, expert in zip(colors + ['#8D99AE'], pivot.columns):
        values = pivot[expert].to_numpy()
        ax.bar(pivot.index.astype(str), values, bottom=bottom, label=DISPLAY.get(expert, expert), color=color)
        bottom += values
    ax.set_ylim(0, 1)
    ax.set_xlabel('Outer meta-fold')
    ax.set_ylabel('RDEF weight')
    ax.legend(frameon=False, bbox_to_anchor=(1.02, 1), loc='upper left')
    fig.tight_layout()
    fig.savefig(output / 'rdef_fold_weights.png', dpi=300)
    fig.savefig(output / 'rdef_fold_weights.tiff', dpi=300)
    plt.close(fig)
    figure, axes = plt.subplots(1, 3, figsize=(15.0, 4.3))
    plot_methods = ['best_single', 'unweighted_mean', 'platt_mean', 'logistic_stacking', 'rdef']
    for color, method in zip(colors, plot_methods):
        false_positive, true_positive, _ = roc_curve(y, predictions[method])
        auc = roc_auc_score(y, predictions[method])
        axes[0].plot(false_positive, true_positive, color=color, lw=1.8, label=f'{METHOD_DISPLAY[method]} ({auc:.3f})')
    axes[0].plot([0, 1], [0, 1], color='#999999', ls='--', lw=1)
    axes[0].set(xlabel='1 - specificity', ylabel='Sensitivity', title='Nested score-level ROC')
    axes[0].legend(frameon=False, fontsize=7)
    bins = np.linspace(0, 1, 7)
    for color, method in zip(colors, ['unweighted_mean', 'platt_mean', 'logistic_stacking']):
        score = predictions[method].to_numpy(dtype=float)
        mean_pred = []
        observed = []
        for index in range(len(bins) - 1):
            right = score <= bins[index + 1] if index == len(bins) - 2 else score < bins[index + 1]
            mask = (score >= bins[index]) & right
            if mask.any():
                mean_pred.append(score[mask].mean())
                observed.append(y[mask].mean())
        axes[1].plot(mean_pred, observed, marker='o', color=color, label=METHOD_DISPLAY[method])
    axes[1].plot([0, 1], [0, 1], color='#999999', ls='--', lw=1)
    axes[1].set(xlabel='Mean predicted probability', ylabel='Observed frequency', title='Calibration')
    axes[1].legend(frameon=False, fontsize=7)
    display = contrasts.sort_values('delta_auc')
    positions = np.arange(len(display))
    axes[2].errorbar(display['delta_auc'], positions, xerr=np.vstack([display['delta_auc'] - display['ci_low'], display['ci_high'] - display['delta_auc']]), fmt='o', color='#D62828', ecolor='#555555', capsize=3)
    axes[2].axvline(0, color='#999999', ls='--', lw=1)
    axes[2].set_yticks(positions, display['reference'])
    axes[2].set(xlabel=f"AUC difference: {display.iloc[0]['candidate']} - comparator", title='Paired AUC contrasts')
    figure.tight_layout()
    figure.savefig(output / 'fusion_performance_panels.png', dpi=300)
    figure.savefig(output / 'fusion_performance_panels.tiff', dpi=300)
    plt.close(figure)

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--experts', default=','.join(DEFAULT_EXPERTS))
    parser.add_argument('--extra-oof', action='append', default=[], help='Optional name=CSV path with id/pid, label, and prob columns.')
    parser.add_argument('--outer-splits', type=int, default=5)
    parser.add_argument('--inner-splits', type=int, default=4)
    parser.add_argument('--seed', type=int, default=20260820)
    parser.add_argument('--n-boot', type=int, default=5000)
    args = parser.parse_args()
    started = time.time()
    experts = [item.strip() for item in args.experts.split(',') if item.strip()]
    frame = pd.read_csv(args.input, dtype={'pid': str})
    for specification in args.extra_oof:
        if '=' not in specification:
            raise ValueError('--extra-oof must use name=path')
        name, path_text = specification.split('=', 1)
        name = name.strip()
        extra = pd.read_csv(Path(path_text.strip()), dtype={'id': str, 'pid': str})
        id_column = 'pid' if 'pid' in extra else 'id'
        if not {id_column, 'label', 'prob'}.issubset(extra.columns):
            raise ValueError(f'Extra OOF file for {name} must contain {id_column}, label, and prob')
        extra = extra[[id_column, 'label', 'prob']].rename(columns={id_column: 'pid', 'prob': name, 'label': f'{name}_label'})
        frame = frame.merge(extra, on='pid', how='left', validate='one_to_one')
        if frame[name].isna().any():
            raise ValueError(f'Extra OOF file for {name} did not cover all 262 cases')
        if not np.array_equal(frame['label'].to_numpy(dtype=int), frame[f'{name}_label'].to_numpy(dtype=int)):
            raise ValueError(f'Label mismatch while merging extra OOF expert {name}')
        frame = frame.drop(columns=[f'{name}_label'])
    required = ['pid', 'label', *experts]
    missing = [column for column in required if column not in frame]
    if missing:
        raise ValueError(f'Missing required columns: {missing}')
    if len(frame) != 262:
        raise ValueError(f'Expected the locked 262-case evidence matrix, got {len(frame)} rows')
    if frame[required].isna().any().any():
        raise ValueError('The locked evidence matrix contains missing required values')
    if frame['pid'].duplicated().any():
        raise ValueError('Case identifiers must be unique in the 262-case evidence matrix')
    args.output.mkdir(parents=True, exist_ok=True)
    y = frame['label'].to_numpy(dtype=int)
    probabilities = frame[experts].to_numpy(dtype=float)
    if not np.all((probabilities >= 0.0) & (probabilities <= 1.0)):
        raise ValueError('Expert evidence must contain probabilities in [0,1]')
    outer = StratifiedKFold(n_splits=args.outer_splits, shuffle=True, random_state=args.seed)
    predictions = frame[['pid', 'label']].copy()
    predictions['outer_fold'] = 0
    for method in METHODS:
        predictions[method] = np.nan
    audit_rows = []
    weight_rows = []
    hyperparameter_rows = []
    for outer_fold, (train_index, test_index) in enumerate(outer.split(probabilities, y), start=1):
        train_y, test_y = (y[train_index], y[test_index])
        train_p, test_p = (probabilities[train_index], probabilities[test_index])
        predictions.loc[test_index, 'outer_fold'] = outer_fold
        train_aucs = np.asarray([roc_auc_score(train_y, train_p[:, index]) for index in range(len(experts))])
        best_index = int(np.argmax(train_aucs))
        predictions.loc[test_index, 'best_single'] = test_p[:, best_index]
        train_mean = train_p.mean(axis=1)
        test_mean = test_p.mean(axis=1)
        predictions.loc[test_index, 'unweighted_mean'] = test_mean
        platt = LogisticRegression(C=1000000.0, solver='lbfgs', max_iter=3000)
        platt.fit(logit(train_mean).reshape(-1, 1), train_y)
        predictions.loc[test_index, 'platt_mean'] = platt.predict_proba(logit(test_mean).reshape(-1, 1))[:, 1]
        beta_train = np.column_stack([np.log(np.clip(train_mean, 1e-06, 1.0)), -np.log(np.clip(1.0 - train_mean, 1e-06, 1.0))])
        beta_test = np.column_stack([np.log(np.clip(test_mean, 1e-06, 1.0)), -np.log(np.clip(1.0 - test_mean, 1e-06, 1.0))])
        beta = LogisticRegression(C=1000000.0, solver='lbfgs', max_iter=3000)
        beta.fit(beta_train, train_y)
        predictions.loc[test_index, 'beta_mean'] = beta.predict_proba(beta_test)[:, 1]
        auc_weights = np.maximum(train_aucs - 0.5, 0.005) ** 2
        auc_weights = auc_weights / auc_weights.sum()
        predictions.loc[test_index, 'auc_weighted_mean'] = test_p @ auc_weights
        simplex_weights, simplex_audit = fit_simplex(train_y, train_p)
        predictions.loc[test_index, 'simplex_logloss'] = test_p @ simplex_weights
        selected_indices, subset_ranking = select_subset(train_y, train_p)
        predictions.loc[test_index, 'selected_subset_mean'] = test_p[:, selected_indices].mean(axis=1)
        logistic_c, logistic_grid = select_logistic_c(train_y, train_p, args.inner_splits, args.seed + outer_fold * 101)
        logistic = make_pipeline(StandardScaler(), LogisticRegression(C=logistic_c, solver='lbfgs', max_iter=3000))
        logistic.fit(logit(train_p), train_y)
        predictions.loc[test_index, 'logistic_stacking'] = logistic.predict_proba(logit(test_p))[:, 1]
        lambda_value, gamma_value, rdef_grid = select_rdef_hyperparameters(train_y, train_p, args.inner_splits, args.seed + outer_fold * 211)
        rdef_weights, rdef_audit = fit_simplex(train_y, train_p, lambda_diversity=lambda_value, gamma_reliability=gamma_value)
        predictions.loc[test_index, 'rdef'] = test_p @ rdef_weights
        for expert, weight, prior, auc_value in zip(experts, rdef_weights, rdef_audit['reliability_prior'], train_aucs):
            weight_rows.append({'outer_fold': outer_fold, 'expert': expert, 'display': DISPLAY.get(expert, expert), 'weight': float(weight), 'reliability_prior': float(prior), 'outer_train_auc': float(auc_value)})
        hyperparameter_rows.extend(({'outer_fold': outer_fold, 'method': 'RDEF', **row} for row in rdef_grid.to_dict('records')))
        hyperparameter_rows.extend(({'outer_fold': outer_fold, 'method': 'Logistic stacking', **row} for row in logistic_grid.to_dict('records')))
        audit_rows.append({'outer_fold': outer_fold, 'n_train': int(len(train_index)), 'n_test': int(len(test_index)), 'best_single_expert': experts[best_index], 'selected_subset': '+'.join((experts[index] for index in selected_indices)), 'selected_subset_train_auc': float(subset_ranking.iloc[0]['auc']), 'logistic_C': logistic_c, 'rdef_lambda': lambda_value, 'rdef_gamma': gamma_value, 'rdef_optimizer_success': bool(rdef_audit['success']), 'simplex_optimizer_success': bool(simplex_audit['success'])})
    if predictions[METHODS].isna().any().any():
        raise AssertionError('At least one outer-test fusion probability is missing')
    if 'selected_fusion_auc' in frame:
        predictions['selected_upper_bound'] = frame['selected_fusion_auc'].to_numpy(dtype=float)
    bootstrap = bootstrap_indices(y, args.n_boot, args.seed)
    metric_rows = []
    for method in METHODS + (['selected_upper_bound'] if 'selected_upper_bound' in predictions else []):
        score = predictions[method].to_numpy(dtype=float)
        row: dict[str, float | int | str] = {'method': method, 'display': METHOD_DISPLAY[method], 'evaluation': 'nested score-level outer CV' if method != 'selected_upper_bound' else 'selection-conditioned full OOF', **metrics(y, score)}
        add_bootstrap_ci(row, y, score, bootstrap)
        metric_rows.append(row)
    metric_frame = pd.DataFrame(metric_rows).sort_values('auc', ascending=False)
    expert_rows = []
    for expert in experts:
        score = frame[expert].to_numpy(dtype=float)
        row = {'expert': expert, 'display': DISPLAY.get(expert, expert), **metrics(y, score)}
        add_bootstrap_ci(row, y, score, bootstrap)
        expert_rows.append(row)
    expert_frame = pd.DataFrame(expert_rows).sort_values('auc', ascending=False)
    proposed_reference = 'platt_mean'
    candidates = [method for method in METHODS if method != proposed_reference]
    contrasts = paired_auc_contrasts(y, predictions, proposed_reference, candidates, bootstrap)
    score_correlation = frame[experts].corr(method='spearman')
    residual_frame = pd.DataFrame(probabilities - y[:, None], columns=experts)
    residual_correlation = residual_frame.corr(method='spearman')
    decision = decision_curve(y, predictions, ['unweighted_mean', 'platt_mean', 'logistic_stacking', 'selected_subset_mean', 'rdef'])
    predictions.to_csv(args.output / 'fusion_predictions.csv', index=False)
    metric_frame.to_csv(args.output / 'fusion_metrics.csv', index=False)
    expert_frame.to_csv(args.output / 'expert_metrics.csv', index=False)
    contrasts.to_csv(args.output / 'paired_auc_contrasts.csv', index=False)
    pd.DataFrame(audit_rows).to_csv(args.output / 'outer_fold_audit.csv', index=False)
    weights = pd.DataFrame(weight_rows)
    weights.to_csv(args.output / 'rdef_fold_weights.csv', index=False)
    pd.DataFrame(hyperparameter_rows).to_csv(args.output / 'inner_hyperparameter_search.csv', index=False)
    score_correlation.to_csv(args.output / 'expert_score_correlation.csv')
    residual_correlation.to_csv(args.output / 'expert_residual_correlation.csv')
    decision.to_csv(args.output / 'decision_curve.csv', index=False)
    save_figures(args.output, y, predictions, score_correlation, weights, contrasts)
    best_nested = metric_frame[metric_frame['evaluation'] == 'nested score-level outer CV'].iloc[0]
    calibrated = metric_frame[metric_frame['method'] == 'platt_mean'].iloc[0]
    report = ['# Heterogeneous expert evidence fusion: 262-case analysis', '', 'This is a nested score-level evaluation of fixed OOF expert probabilities; it is not end-to-end nested retraining of the image experts.', '', f'- Cases: {len(frame)} ({int(y.sum())} T3; {int((y == 0).sum())} T1-T2)', f"- Cross-fitted Platt-calibrated mean AUC: {calibrated['auc']:.3f} ({calibrated['auc_ci_low']:.3f}-{calibrated['auc_ci_high']:.3f})", f"- Highest nested score-level AUC: {best_nested['display']} {best_nested['auc']:.3f}", f'- Runtime: {time.time() - started:.1f} seconds', '', '## Fusion metrics', '', metric_frame.to_markdown(index=False, floatfmt='.3f'), '', '## Paired AUC contrasts', '', contrasts.to_markdown(index=False, floatfmt='.3f'), '', '## Outer-fold audit', '', pd.DataFrame(audit_rows).to_markdown(index=False)]
    (args.output / 'fusion_report.md').write_text('\n'.join(report) + '\n', encoding='utf-8')
    metadata = {'input': str(args.input), 'n_cases': int(len(frame)), 'experts': experts, 'outer_splits': args.outer_splits, 'inner_splits': args.inner_splits, 'seed': args.seed, 'n_boot': args.n_boot, 'evaluation_scope': 'nested score-level evaluation of fixed OOF expert probabilities', 'runtime_seconds': time.time() - started}
    (args.output / 'analysis_metadata.json').write_text(json.dumps(metadata, indent=2), encoding='utf-8')
    print(metric_frame.to_string(index=False), flush=True)
    print(contrasts.to_string(index=False), flush=True)
    print(f'Wrote {args.output}', flush=True)
if __name__ == '__main__':
    main()
