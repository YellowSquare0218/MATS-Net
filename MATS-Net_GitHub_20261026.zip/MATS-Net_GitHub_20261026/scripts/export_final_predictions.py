import argparse
import os
import numpy as np
import pandas as pd
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_INPUT = os.path.join(PROJECT_ROOT, 'training_results', 'fast_evidence_fusion_distill_2cls', 'aligned_predictions.csv')
DEFAULT_INDEX = os.path.join(PROJECT_ROOT, 'dataset', 'roi_v4', 'index.csv')
DEFAULT_OUTPUT = os.path.join(PROJECT_ROOT, 'training_results', 'fast_evidence_fusion_distill_2cls', 'final_patient_predictions.csv')

def compute_scores(df):
    distill_core = df[['mara', 'early', 'cif', 'gmara_acc', 'gmara_distill_w030']].mean(axis=1)
    score = 0.8 * distill_core + 0.2 * df['geo_lr_c0_1']
    score_auc = 0.85 * distill_core + 0.15 * df['geo_lr_c1_0']
    model_cols = [c for c in ['mara', 'early', 'cif', 'cmara', 'gmara_auc', 'gmara_acc', 'tripath_acc', 'cqof_acc', 'omara_acc', 'gmara_distill_w015', 'gmara_distill_w030'] if c in df.columns]
    disagreement = df[model_cols].std(axis=1)
    return (score, score_auc, disagreement)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default=DEFAULT_INPUT)
    parser.add_argument('--index', default=DEFAULT_INDEX)
    parser.add_argument('--output', default=DEFAULT_OUTPUT)
    args = parser.parse_args()
    df = pd.read_csv(args.input)
    df['pid'] = df['pid'].astype(str)
    score, score_auc, disagreement = compute_scores(df)
    out = df[['pid', 'label']].copy()
    if os.path.exists(args.index):
        index = pd.read_csv(args.index)
        index['pid'] = index['id'].astype(str)
        keep = [c for c in ['pid', 'state'] if c in index.columns]
        out = out.merge(index[keep], on='pid', how='left')
    out['evidence_prob'] = score
    out['evidence_auc_prob'] = score_auc
    out['pred_0p50'] = (score >= 0.5).astype(int)
    out['pred_nested_0p48'] = (score >= 0.48).astype(int)
    out['auc_prob_pred_0p46'] = (score_auc >= 0.46).astype(int)
    out['confidence'] = np.abs(score - 0.5)
    out['auc_confidence'] = np.abs(score_auc - 0.5)
    out['model_disagreement'] = disagreement
    out['correct_0p50'] = (out['pred_0p50'] == out['label']).astype(int)
    out['correct_nested_0p48'] = (out['pred_nested_0p48'] == out['label']).astype(int)
    rank_conf = out['confidence'].rank(method='first', ascending=False)
    rank_auc_conf = out['auc_confidence'].rank(method='first', ascending=False)
    n = len(out)
    for coverage in [0.5, 0.6, 0.8, 0.9]:
        k = int(round(n * coverage))
        out[f'keep_conf_top_{int(coverage * 100)}'] = (rank_conf <= k).astype(int)
        out[f'keep_auc_conf_top_{int(coverage * 100)}'] = (rank_auc_conf <= k).astype(int)
    out = out.sort_values(['auc_confidence', 'confidence'], ascending=False)
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    out.to_csv(args.output, index=False)
    summary = []
    for col in ['pred_0p50', 'pred_nested_0p48', 'auc_prob_pred_0p46']:
        summary.append({'prediction': col, 'acc': float((out[col] == out['label']).mean()), 'n': len(out)})
    summary_df = pd.DataFrame(summary)
    summary_df.to_csv(os.path.splitext(args.output)[0] + '_summary.csv', index=False)
    print(summary_df.to_string(index=False))
    print(f'Wrote {args.output}')
if __name__ == '__main__':
    main()
