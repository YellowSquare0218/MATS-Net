from __future__ import annotations
import argparse
import inspect
import json
import os
import sys
from typing import Dict, Iterable, List, Optional, Sequence, Tuple
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, balanced_accuracy_score, brier_score_loss, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from train import BATCH_SIZE, FOLDS, MODALITIES, NUM_WORKERS, ROI_DIR, MRIDataset, add_clinical_features, add_roi_geometry_features, collate_fn, get_num_classes, make_cv_splits, resolve_project_path
from net_family_3d import get_fusion, get_fusion_v2, get_model
REGION_CHOICES = ('whole', 'core', 'periphery', 'slice_band')
REPLACEMENT_CHOICES = ('mean', 'zero')

def load_json(path: str) -> Dict[str, object]:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)

def load_state(path: str, device: torch.device) -> Dict[str, torch.Tensor]:
    state = torch.load(path, map_location=device)
    if isinstance(state, dict) and 'state_dict' in state:
        state = state['state_dict']
    if isinstance(state, dict) and any((k.startswith('module.') for k in state)):
        state = {k.replace('module.', '', 1): v for k, v in state.items()}
    return state

def resolve_existing_index(config: Dict[str, object]) -> str:
    candidates = [config.get('index_csv'), os.path.join(ROI_DIR, 'index.csv'), os.path.join(ROI_DIR, 'labels_clinical_expanded_262.csv')]
    for candidate in candidates:
        if not candidate:
            continue
        path = resolve_project_path(str(candidate))
        if os.path.exists(path):
            return path
    raise FileNotFoundError('No usable index CSV found from config or ROI_DIR.')

def resolve_existing_clinical(config: Dict[str, object]) -> Optional[str]:
    candidates = [config.get('clinical_csv'), os.path.join(ROI_DIR, 'labels_clinical_expanded_262.csv'), config.get('index_csv')]
    for candidate in candidates:
        if not candidate:
            continue
        path = resolve_project_path(str(candidate))
        if os.path.exists(path):
            return path
    return None

def prepare_index_and_tabular(config: Dict[str, object], index: pd.DataFrame) -> Tuple[pd.DataFrame, List[str], Dict[str, object], str]:
    fusion_kwargs = dict(config.get('fusion_kwargs') or {})
    use_geometry = bool(config.get('use_geometry'))
    tabular_source = str(config.get('tabular_source') or 'auto')
    if tabular_source == 'auto':
        tabular_source = 'geometry' if use_geometry else 'none'
    clinical_csv = resolve_existing_clinical(config)
    geometry_cols: List[str] = []
    clinical_cols: List[str] = []
    if tabular_source in ('geometry', 'clinical_geometry'):
        index, geometry_cols = add_roi_geometry_features(index)
    if tabular_source in ('clinical', 'clinical_geometry'):
        index, clinical_cols = add_clinical_features(index, clinical_csv)
    tabular_cols = geometry_cols + clinical_cols
    if tabular_cols:
        fusion_kwargs['tab_dim'] = len(tabular_cols)
    aux_node_task = bool(config.get('aux_node_task'))
    if aux_node_task and 'aux_node_classes' not in fusion_kwargs:
        fusion_kwargs['aux_node_classes'] = 2
    if aux_node_task and float(config.get('aux_node_weight') or 0.0) > 0 and ('aux_node_weight' not in fusion_kwargs):
        fusion_kwargs['aux_node_weight'] = float(config.get('aux_node_weight') or 0.0)
    return (index, tabular_cols, fusion_kwargs, tabular_source)

def build_model(config: Dict[str, object], fusion_kwargs: Dict[str, object], device: torch.device) -> torch.nn.Module:
    model_name = str(config.get('model_name') or 'convnext3d_tiny')
    modal = str(config.get('modal') or 'all')
    fusion = config.get('fusion')
    task = int(config.get('task') or 2)
    num_classes = get_num_classes(task)
    if fusion == 'causal_v2':
        model = get_fusion_v2(model_name, num_classes=num_classes)
    elif fusion is not None and modal == 'all' and (fusion != 'early'):
        model = get_fusion(str(fusion), model_name, num_classes=num_classes, **fusion_kwargs)
    else:
        in_chans = 4 if modal == 'all' else 1
        model = get_model(model_name, in_chans=in_chans, num_classes=num_classes)
    return model.to(device)

def safe_load_model(model: torch.nn.Module, checkpoint_path: str, device: torch.device) -> Tuple[List[str], List[str]]:
    state = load_state(checkpoint_path, device)
    try:
        model.load_state_dict(state, strict=True)
        return ([], [])
    except RuntimeError:
        result = model.load_state_dict(state, strict=False)
        return (list(result.missing_keys), list(result.unexpected_keys))

def _bounds(size: int, lo: float, hi: float) -> Tuple[int, int]:
    start = int(np.floor(size * lo))
    end = int(np.ceil(size * hi))
    start = max(0, min(start, size - 1))
    end = max(start + 1, min(end, size))
    return (start, end)

def region_mask_like(volume: torch.Tensor, region: str) -> torch.Tensor:
    if volume.ndim != 5:
        raise ValueError(f'Expected volume shape (B,1,D,H,W), got {tuple(volume.shape)}')
    _, _, depth, height, width = volume.shape
    mask = torch.zeros_like(volume, dtype=torch.bool)
    d0, d1 = _bounds(depth, 0.25, 0.75)
    h0, h1 = _bounds(height, 0.25, 0.75)
    w0, w1 = _bounds(width, 0.25, 0.75)
    if region == 'whole':
        mask[:] = True
    elif region == 'core':
        mask[:, :, d0:d1, h0:h1, w0:w1] = True
    elif region == 'periphery':
        mask[:] = True
        mask[:, :, d0:d1, h0:h1, w0:w1] = False
    elif region == 'slice_band':
        sd0, sd1 = _bounds(depth, 0.375, 0.625)
        mask[:, :, sd0:sd1, :, :] = True
    else:
        raise ValueError(f'Unsupported region: {region}')
    return mask

def apply_counterfactual(volumes: Sequence[torch.Tensor], modality_idx: int, region: str, replacement: str) -> List[torch.Tensor]:
    out = [v.clone() for v in volumes]
    target = out[modality_idx]
    mask = region_mask_like(target, region)
    if replacement == 'mean':
        baseline = target.mean(dim=(2, 3, 4), keepdim=True).expand_as(target)
    elif replacement == 'zero':
        baseline = torch.zeros_like(target)
    else:
        raise ValueError(f'Unsupported replacement: {replacement}')
    out[modality_idx] = torch.where(mask, baseline, target)
    return out

def logits_from_output(result) -> torch.Tensor:
    if isinstance(result, tuple):
        return result[0]
    return result

def forward_model(model: torch.nn.Module, volumes: Sequence[torch.Tensor], tabular: Optional[torch.Tensor]=None) -> torch.Tensor:
    params = inspect.signature(model.forward).parameters
    if 'tabular' in params:
        result = model(list(volumes), tabular=tabular)
    else:
        try:
            result = model(list(volumes))
        except TypeError:
            result = model(torch.cat(list(volumes), dim=1))
    return logits_from_output(result)

def positive_probs(logits: torch.Tensor) -> np.ndarray:
    if logits.shape[1] == 1:
        return torch.sigmoid(logits[:, 0]).detach().cpu().numpy()
    return F.softmax(logits, dim=1)[:, 1].detach().cpu().numpy()

def binary_metrics(labels: np.ndarray, scores: np.ndarray, threshold: float=0.5) -> Dict[str, object]:
    preds = (scores >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(labels, preds, labels=[0, 1]).ravel()
    return {'auc': float(roc_auc_score(labels, scores)) if len(np.unique(labels)) == 2 else np.nan, 'acc': float(accuracy_score(labels, preds)), 'balanced_acc': float(balanced_accuracy_score(labels, preds)), 'precision': float(precision_score(labels, preds, zero_division=0)), 'recall': float(recall_score(labels, preds, zero_division=0)), 'sensitivity': float(tp / (tp + fn)) if tp + fn else np.nan, 'specificity': float(tn / (tn + fp)) if tn + fp else np.nan, 'f1': float(f1_score(labels, preds, zero_division=0)), 'brier': float(brier_score_loss(labels, scores)), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

def bootstrap_mean_ci(values: Iterable[float], bootstraps: int, seed: int) -> Tuple[float, float]:
    arr = np.asarray(list(values), dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return (np.nan, np.nan)
    if bootstraps <= 0 or len(arr) == 1:
        return (float(arr.mean()), float(arr.mean()))
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, len(arr), size=(bootstraps, len(arr)))
    means = arr[idx].mean(axis=1)
    return (float(np.quantile(means, 0.025)), float(np.quantile(means, 0.975)))

def summarize_effects(df: pd.DataFrame, bootstraps: int, seed: int) -> pd.DataFrame:
    rows = []
    group_cols = ['modality', 'region', 'replacement']
    for key, group in df.groupby(group_cols):
        modality, region, replacement = key
        cie = group['cie'].to_numpy(dtype=float)
        abs_cie = np.abs(cie)
        ci_low, ci_high = bootstrap_mean_ci(cie, bootstraps, seed)
        rows.append({'modality': modality, 'region': region, 'replacement': replacement, 'n': int(len(group)), 'mean_cie': float(np.mean(cie)), 'median_cie': float(np.median(cie)), 'std_cie': float(np.std(cie, ddof=1)) if len(cie) > 1 else 0.0, 'mean_abs_cie': float(np.mean(abs_cie)), 'fraction_positive_cie': float(np.mean(cie > 0)), 'mean_cie_ci_low': ci_low, 'mean_cie_ci_high': ci_high})
    return pd.DataFrame(rows).sort_values(['replacement', 'modality', 'region']).reset_index(drop=True)

def make_heatmap(summary: pd.DataFrame, output_dir: str, replacement: str) -> Optional[Dict[str, str]]:
    try:
        import matplotlib.pyplot as plt
    except Exception as exc:
        print(f'[WARN] matplotlib unavailable, skipping heatmap: {exc}')
        return None
    display_mods = ['T2W', 'DWI', 'T1C', 'T1W']
    display_regions = ['whole', 'core', 'periphery', 'slice_band']
    sub = summary[summary['replacement'] == replacement]
    pivot = sub.pivot(index='modality', columns='region', values='mean_cie')
    matrix = np.full((len(display_mods), len(display_regions)), np.nan, dtype=float)
    for i, mod in enumerate(display_mods):
        for j, region in enumerate(display_regions):
            if mod in pivot.index and region in pivot.columns:
                matrix[i, j] = pivot.loc[mod, region]
    finite = matrix[np.isfinite(matrix)]
    vmax = max(abs(float(finite.min())), abs(float(finite.max()))) if finite.size else 1.0
    vmax = max(vmax, 1e-06)
    fig, ax = plt.subplots(figsize=(7.2, 4.6), dpi=220)
    im = ax.imshow(matrix, cmap='RdBu_r', vmin=-vmax, vmax=vmax, aspect='auto')
    ax.set_xticks(np.arange(len(display_regions)))
    ax.set_xticklabels(['Whole ROI', 'Core', 'Periphery', 'Central slices'], rotation=20, ha='right')
    ax.set_yticks(np.arange(len(display_mods)))
    ax.set_yticklabels(['T2WI', 'DWI', 'CE-T1WI', 'T1WI'])
    ax.set_title('Counterfactual Image-Region Intervention Effect')
    ax.set_xlabel('Neutralized image region')
    ax.set_ylabel('Intervened modality')
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            value = matrix[i, j]
            label = 'NA' if not np.isfinite(value) else f'{value:.3f}'
            ax.text(j, i, label, ha='center', va='center', fontsize=8, color='black')
    cbar = fig.colorbar(im, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label('Mean CIE: p(original) - p(counterfactual)')
    fig.tight_layout()
    png = os.path.join(output_dir, 'Fig12_counterfactual_image_region_effect_heatmap.png')
    svg = os.path.join(output_dir, 'Fig12_counterfactual_image_region_effect_heatmap.svg')
    fig.savefig(png, bbox_inches='tight')
    fig.savefig(svg, bbox_inches='tight')
    plt.close(fig)
    return {'png': png, 'svg': svg}

@torch.no_grad()
def evaluate_fold(model: torch.nn.Module, loader: DataLoader, fold_idx: int, modality_indices: Sequence[int], regions: Sequence[str], replacement: str, device: torch.device) -> Tuple[pd.DataFrame, pd.DataFrame]:
    model.eval()
    prediction_rows = []
    effect_rows = []
    for batch in loader:
        volumes = [v.to(device, non_blocking=True) for v in batch['volumes']]
        labels_tensor = batch['label'].to(device, non_blocking=True)
        tabular = batch.get('tabular')
        if tabular is not None:
            tabular = tabular.to(device, non_blocking=True)
        logits = forward_model(model, volumes, tabular=tabular)
        original_probs = positive_probs(logits)
        labels = labels_tensor.detach().cpu().numpy().astype(int)
        pids = batch['pid']
        for pid, label, prob in zip(pids, labels, original_probs):
            prediction_rows.append({'pid': pid, 'fold': int(fold_idx), 'label': int(label), 'original_prob': float(prob)})
        for modality_idx in modality_indices:
            modality = MODALITIES[modality_idx]
            for region in regions:
                cf_volumes = apply_counterfactual(volumes, modality_idx, region, replacement)
                cf_logits = forward_model(model, cf_volumes, tabular=tabular)
                cf_probs = positive_probs(cf_logits)
                for pid, label, orig, cf in zip(pids, labels, original_probs, cf_probs):
                    effect_rows.append({'pid': pid, 'fold': int(fold_idx), 'label': int(label), 'modality': modality, 'region': region, 'replacement': replacement, 'original_prob': float(orig), 'counterfactual_prob': float(cf), 'cie': float(orig - cf), 'abs_cie': float(abs(orig - cf))})
    return (pd.DataFrame(prediction_rows), pd.DataFrame(effect_rows))

def parse_modalities(values: Sequence[str]) -> List[int]:
    mapping = {name.lower(): idx for idx, name in enumerate(MODALITIES)}
    if len(values) == 1 and values[0].lower() == 'all':
        return list(range(len(MODALITIES)))
    indices = []
    for value in values:
        key = value.lower()
        if key not in mapping:
            raise ValueError(f"Unknown modality '{value}'. Valid: {', '.join(MODALITIES)}")
        indices.append(mapping[key])
    return sorted(set(indices))

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-dir', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--regions', nargs='+', default=list(REGION_CHOICES), choices=REGION_CHOICES)
    parser.add_argument('--modalities', nargs='+', default=['all'])
    parser.add_argument('--replacement', default='mean', choices=REPLACEMENT_CHOICES)
    parser.add_argument('--batch-size', type=int, default=8)
    parser.add_argument('--num-workers', type=int, default=NUM_WORKERS)
    parser.add_argument('--bootstraps', type=int, default=1000)
    parser.add_argument('--seed', type=int, default=42)
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    parser.add_argument('--max-cases', type=int, default=None)
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    config_path = os.path.join(args.model_dir, 'config.json')
    config = load_json(config_path)
    device = torch.device(args.device if args.device == 'cpu' or torch.cuda.is_available() else 'cpu')
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    index_csv = resolve_existing_index(config)
    index = pd.read_csv(index_csv)
    index['id'] = index['id'].astype(str)
    index, tabular_cols, fusion_kwargs, tabular_source = prepare_index_and_tabular(config, index)
    if args.max_cases:
        index = index.iloc[:int(args.max_cases)].copy()
    task = int(config.get('task') or 2)
    labels_for_split = index['label'].values if task == 2 else index['state'].values
    split_strategy = str(config.get('split_strategy') or 'group')
    fold_seed = int(config.get('fold_seed') or args.seed)
    splits, groups = make_cv_splits(index, labels_for_split, split_strategy, fold_seed)
    modality_indices = parse_modalities(args.modalities)
    all_predictions = []
    all_effects = []
    load_warnings = []
    for fold_idx, (train_idx, val_idx) in enumerate(splits, start=1):
        checkpoint = os.path.join(args.model_dir, f'fold_{fold_idx}', 'best_model.pth')
        if not os.path.exists(checkpoint):
            raise FileNotFoundError(checkpoint)
        train_df = index.iloc[train_idx].copy()
        val_df = index.iloc[val_idx].copy()
        tabular_col = None
        if tabular_cols:
            imputer = SimpleImputer(strategy='median')
            scaler = StandardScaler()
            train_tab = imputer.fit_transform(train_df[tabular_cols])
            val_tab = imputer.transform(val_df[tabular_cols])
            train_tab = scaler.fit_transform(train_tab).astype(np.float32)
            val_tab = scaler.transform(val_tab).astype(np.float32)
            tabular_col = 'tabular_features'
            train_df[tabular_col] = list(train_tab)
            val_df[tabular_col] = list(val_tab)
        val_ds = MRIDataset(ROI_DIR, val_df, MODALITIES, augment=False, task=task, tabular_col=tabular_col)
        batch_size = max(1, min(int(args.batch_size), len(val_ds), BATCH_SIZE))
        loader = DataLoader(val_ds, batch_size=batch_size, shuffle=False, num_workers=max(0, int(args.num_workers)), pin_memory=device.type == 'cuda', collate_fn=collate_fn)
        model = build_model(config, fusion_kwargs, device)
        missing, unexpected = safe_load_model(model, checkpoint, device)
        if missing or unexpected:
            load_warnings.append({'fold': fold_idx, 'missing_keys': missing[:20], 'unexpected_keys': unexpected[:20], 'missing_count': len(missing), 'unexpected_count': len(unexpected)})
        pred_df, effect_df = evaluate_fold(model=model, loader=loader, fold_idx=fold_idx, modality_indices=modality_indices, regions=args.regions, replacement=args.replacement, device=device)
        all_predictions.append(pred_df)
        all_effects.append(effect_df)
        del model
        if device.type == 'cuda':
            torch.cuda.empty_cache()
        print(f'[OK] fold {fold_idx}/{FOLDS}: predictions={len(pred_df)}, effects={len(effect_df)}')
    predictions = pd.concat(all_predictions, ignore_index=True)
    effects = pd.concat(all_effects, ignore_index=True)
    summary = summarize_effects(effects, args.bootstraps, args.seed)
    metrics = binary_metrics(predictions['label'].to_numpy(dtype=int), predictions['original_prob'].to_numpy(dtype=float))
    heatmap_paths = make_heatmap(summary, args.output_dir, args.replacement)
    pred_path = os.path.join(args.output_dir, 'counterfactual_region_original_predictions.csv')
    effects_path = os.path.join(args.output_dir, 'counterfactual_region_effects.csv')
    summary_path = os.path.join(args.output_dir, 'counterfactual_region_summary.csv')
    json_path = os.path.join(args.output_dir, 'counterfactual_region_summary.json')
    predictions.to_csv(pred_path, index=False)
    effects.to_csv(effects_path, index=False)
    summary.to_csv(summary_path, index=False)
    run_summary = {'model_dir': args.model_dir, 'config_path': config_path, 'output_dir': args.output_dir, 'index_csv': index_csv, 'split_strategy': split_strategy, 'fold_seed': fold_seed, 'n_records': int(len(index)), 'n_groups': int(len(set(groups))) if groups is not None else None, 'modalities': [MODALITIES[i] for i in modality_indices], 'regions': list(args.regions), 'replacement': args.replacement, 'tabular_source': tabular_source, 'tabular_dim': int(len(tabular_cols)), 'original_metrics': metrics, 'predictions_csv': pred_path, 'effects_csv': effects_path, 'summary_csv': summary_path, 'heatmap': heatmap_paths, 'load_warnings': load_warnings}
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(run_summary, f, ensure_ascii=False, indent=2)
    print(summary.sort_values('mean_abs_cie', ascending=False).to_string(index=False))
    print(json.dumps(run_summary['original_metrics'], ensure_ascii=False, indent=2))
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
