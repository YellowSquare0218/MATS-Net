from __future__ import annotations
import argparse
import copy
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional
import nibabel as nib
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, precision_score, recall_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold
from torch.utils.data import DataLoader, Dataset
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import count_params, get_model

def normalize_id(value: object) -> str:
    return str(value).strip().replace('.0', '')

class ExternalT2Dataset(Dataset):

    def __init__(self, roi_dir: str, frame: pd.DataFrame, modality: str='T2W', augment: bool=False, teacher_col: Optional[str]=None, intensity_mode: str='minmax') -> None:
        self.roi_dir = roi_dir
        self.df = frame.reset_index(drop=True).copy()
        self.df['id'] = self.df['id'].map(normalize_id)
        self.modality = modality
        self.augment = augment
        self.teacher_col = teacher_col
        self.intensity_mode = intensity_mode

    def __len__(self) -> int:
        return len(self.df)

    def _normalize(self, data: np.ndarray) -> np.ndarray:
        if self.intensity_mode == 'zscore':
            mask = np.isfinite(data)
            vals = data[mask]
            if vals.size > 0:
                mean = float(vals.mean())
                std = float(vals.std())
                if std > 1e-06:
                    data = (data - mean) / std
                    data = np.clip(data, -5.0, 5.0)
                    data = (data + 5.0) / 10.0
                    return data.astype(np.float32)
        if self.intensity_mode == 'percentile':
            lo, hi = np.percentile(data, [1, 99])
            if hi > lo:
                data = np.clip(data, lo, hi)
                data = (data - lo) / (hi - lo)
                return data.astype(np.float32)
        vmin, vmax = (float(np.nanmin(data)), float(np.nanmax(data)))
        if vmax > vmin:
            data = (data - vmin) / (vmax - vmin)
        return data.astype(np.float32)

    def _load_volume(self, pid: str) -> np.ndarray:
        path = os.path.join(self.roi_dir, pid, f'{self.modality}.nii.gz')
        data = nib.load(path).get_fdata().astype(np.float32)
        data = np.transpose(data, (2, 0, 1))
        return self._normalize(data)

    def _augment(self, vol: np.ndarray) -> np.ndarray:
        if np.random.rand() < 0.5:
            vol = np.flip(vol, axis=1).copy()
        if np.random.rand() < 0.5:
            vol = np.flip(vol, axis=2).copy()
        if np.random.rand() < 0.35:
            vol = vol + np.random.normal(0, 0.025, vol.shape).astype(np.float32)
        if np.random.rand() < 0.35:
            gamma = np.random.uniform(0.75, 1.35)
            vol = np.power(np.clip(vol, 0, 1), gamma)
        if np.random.rand() < 0.35:
            vol = vol * np.random.uniform(0.85, 1.2) + np.random.uniform(-0.08, 0.08)
        return np.clip(vol, 0, 1).astype(np.float32)

    def __getitem__(self, idx: int) -> Dict[str, object]:
        row = self.df.iloc[idx]
        pid = normalize_id(row['id'])
        vol = self._load_volume(pid)
        if self.augment:
            vol = self._augment(vol)
        item: Dict[str, object] = {'pid': pid, 'volume': torch.from_numpy(vol).unsqueeze(0), 'label': int(row['label'])}
        if self.teacher_col:
            item['teacher_prob'] = torch.tensor(float(row[self.teacher_col]), dtype=torch.float32)
        return item

def collate(batch: List[Dict[str, object]]) -> Dict[str, object]:
    out: Dict[str, object] = {'pid': [item['pid'] for item in batch], 'volume': torch.stack([item['volume'] for item in batch], dim=0), 'label': torch.tensor([item['label'] for item in batch], dtype=torch.long)}
    if 'teacher_prob' in batch[0]:
        out['teacher_prob'] = torch.stack([item['teacher_prob'] for item in batch], dim=0)
    return out

def load_state(path: str, device: torch.device) -> Dict[str, torch.Tensor]:
    state = torch.load(path, map_location=device)
    if isinstance(state, dict) and 'state_dict' in state:
        state = state['state_dict']
    if isinstance(state, dict) and any((k.startswith('module.') for k in state)):
        state = {k.replace('module.', '', 1): v for k, v in state.items()}
    return state

def source_checkpoint_for_fold(source_dir: Optional[str], fold_idx: int) -> Optional[str]:
    if not source_dir:
        return None
    direct = Path(source_dir) / f'fold_{fold_idx}' / 'best_model.pth'
    if direct.exists():
        return str(direct)
    paths = sorted(Path(source_dir).glob('fold_*/best_model.pth'))
    if not paths:
        raise FileNotFoundError(f'No fold checkpoints under {source_dir}')
    return str(paths[(fold_idx - 1) % len(paths)])

def freeze_for_linear_probe(model: nn.Module) -> None:
    for name, param in model.named_parameters():
        trainable = any((key in name.lower() for key in ['head', 'classifier', 'fc', 'norm']))
        param.requires_grad = trainable

def distillation_loss(logits: torch.Tensor, teacher_prob: torch.Tensor, temperature: float=2.0) -> torch.Tensor:
    teacher_prob = teacher_prob.to(logits.device).float().clamp(0.0001, 1 - 0.0001)
    target = torch.stack([1.0 - teacher_prob, teacher_prob], dim=1)
    log_probs = F.log_softmax(logits / temperature, dim=1)
    return F.kl_div(log_probs, target, reduction='batchmean') * temperature ** 2

def metrics_from_prob(y_true: np.ndarray, prob: np.ndarray, threshold: float=0.5) -> Dict[str, object]:
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {'auc': float(roc_auc_score(y_true, prob)) if len(np.unique(y_true)) == 2 else None, 'accuracy': float(accuracy_score(y_true, pred)), 'precision': float(precision_score(y_true, pred, zero_division=0)), 'recall': float(recall_score(y_true, pred, zero_division=0)), 'sensitivity': float(tp / (tp + fn)) if tp + fn else None, 'specificity': float(tn / (tn + fp)) if tn + fp else None, 'f1': float(f1_score(y_true, pred, zero_division=0)), 'brier': float(brier_score_loss(y_true, prob)), 'threshold': float(threshold), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

@torch.no_grad()
def evaluate(model: nn.Module, loader: DataLoader, device: torch.device) -> Dict[str, object]:
    model.eval()
    probs: List[float] = []
    labels: List[int] = []
    pids: List[str] = []
    for batch in loader:
        x = batch['volume'].to(device)
        logits = model(x)
        prob = torch.softmax(logits, dim=1)[:, 1].detach().cpu().numpy()
        probs.extend(prob.tolist())
        labels.extend(batch['label'].numpy().tolist())
        pids.extend(batch['pid'])
    y = np.asarray(labels, dtype=int)
    p = np.asarray(probs, dtype=np.float32)
    out = metrics_from_prob(y, p)
    out['predictions'] = [{'pid': pid, 'label': int(label), 'prob_pos': float(prob)} for pid, label, prob in zip(pids, labels, probs)]
    return out

def train_one_epoch(model: nn.Module, loader: DataLoader, optimizer: torch.optim.Optimizer, criterion: nn.Module, device: torch.device, teacher_weight: float, teacher_temperature: float) -> Dict[str, float]:
    model.train()
    losses: List[float] = []
    labels: List[int] = []
    preds: List[int] = []
    for batch in loader:
        x = batch['volume'].to(device)
        y = batch['label'].to(device)
        logits = model(x)
        loss = criterion(logits, y)
        if teacher_weight > 0 and 'teacher_prob' in batch:
            loss = loss + teacher_weight * distillation_loss(logits, batch['teacher_prob'], teacher_temperature)
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        losses.append(float(loss.detach().cpu()))
        labels.extend(y.detach().cpu().numpy().tolist())
        preds.extend(logits.argmax(dim=1).detach().cpu().numpy().tolist())
    return {'loss': float(np.mean(losses)), 'acc': float(accuracy_score(labels, preds))}

def add_teacher_predictions(index: pd.DataFrame, path: Optional[str]) -> tuple[pd.DataFrame, Optional[str]]:
    if not path:
        return (index, None)
    teacher = pd.read_csv(path)
    teacher['pid'] = teacher['pid'].map(normalize_id)
    score_col = 'teacher_prob'
    if score_col not in teacher.columns:
        if 'ensemble_prob' in teacher.columns:
            score_col = 'ensemble_prob'
        elif 'prob_pos' in teacher.columns:
            score_col = 'prob_pos'
        else:
            raise ValueError(f'Teacher prediction CSV lacks teacher_prob/ensemble_prob/prob_pos: {path}')
    merged = index.merge(teacher[['pid', score_col]].rename(columns={'pid': '_teacher_pid', score_col: 'teacher_prob'}), left_on='id', right_on='_teacher_pid', how='left').drop(columns=['_teacher_pid'])
    if merged['teacher_prob'].isna().any():
        missing = merged.loc[merged['teacher_prob'].isna(), 'id'].head(5).tolist()
        raise ValueError(f"Missing teacher predictions for {merged['teacher_prob'].isna().sum()} rows, e.g. {missing}")
    merged['teacher_prob'] = pd.to_numeric(merged['teacher_prob'], errors='raise').clip(0.0001, 1 - 0.0001)
    return (merged, 'teacher_prob')

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--roi-dir', required=True)
    parser.add_argument('--index-csv', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--model-name', default='convnext3d_tiny')
    parser.add_argument('--modality', default='T2W')
    parser.add_argument('--source-model-dir', default=None)
    parser.add_argument('--teacher-pred-csv', default=None)
    parser.add_argument('--teacher-weight', type=float, default=0.0)
    parser.add_argument('--teacher-temperature', type=float, default=2.0)
    parser.add_argument('--adaptation-mode', choices=['scratch', 'finetune', 'linear_probe'], default='finetune')
    parser.add_argument('--intensity-mode', choices=['minmax', 'percentile', 'zscore'], default='minmax')
    parser.add_argument('--epochs', type=int, default=40)
    parser.add_argument('--patience', type=int, default=10)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--num-workers', type=int, default=2)
    parser.add_argument('--lr', type=float, default=0.0001)
    parser.add_argument('--weight-decay', type=float, default=0.0001)
    parser.add_argument('--folds', type=int, default=5)
    parser.add_argument('--seed', type=int, default=20260619)
    parser.add_argument('--class-balanced', action='store_true')
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device if args.device == 'cpu' or torch.cuda.is_available() else 'cpu')
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    index = pd.read_csv(args.index_csv)
    index['id'] = index['id'].map(normalize_id)
    index['label'] = index['label'].astype(int)
    index, teacher_col = add_teacher_predictions(index, args.teacher_pred_csv)
    splitter = StratifiedKFold(n_splits=args.folds, shuffle=True, random_state=args.seed)
    splits = list(splitter.split(index, index['label'].to_numpy()))
    all_predictions: List[pd.DataFrame] = []
    fold_metrics: List[Dict[str, object]] = []
    start = time.time()
    with open(os.path.join(args.output_dir, 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(vars(args), f, ensure_ascii=False, indent=2)
    for fold_idx, (train_idx, val_idx) in enumerate(splits, start=1):
        print(f"\n{'=' * 60}\nExternal adaptation fold {fold_idx}/{args.folds}\n{'=' * 60}", flush=True)
        train_df = index.iloc[train_idx].copy()
        val_df = index.iloc[val_idx].copy()
        train_ds = ExternalT2Dataset(args.roi_dir, train_df, modality=args.modality, augment=True, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
        val_ds = ExternalT2Dataset(args.roi_dir, val_df, modality=args.modality, augment=False, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
        train_loader = DataLoader(train_ds, batch_size=min(args.batch_size, len(train_ds)), shuffle=True, num_workers=args.num_workers, collate_fn=collate)
        val_loader = DataLoader(val_ds, batch_size=min(args.batch_size, len(val_ds)), shuffle=False, num_workers=args.num_workers, collate_fn=collate)
        model = get_model(args.model_name, in_chans=1, num_classes=2).to(device)
        source_ckpt = source_checkpoint_for_fold(args.source_model_dir, fold_idx)
        if args.adaptation_mode in ('finetune', 'linear_probe') and source_ckpt:
            model.load_state_dict(load_state(source_ckpt, device), strict=True)
            print(f'Loaded source checkpoint: {source_ckpt}', flush=True)
        if args.adaptation_mode == 'linear_probe':
            freeze_for_linear_probe(model)
        trainable = sum((p.numel() for p in model.parameters() if p.requires_grad))
        print(f'Params={count_params(model) / 1000000.0:.2f}M, trainable={trainable / 1000000.0:.2f}M, train={len(train_ds)}, val={len(val_ds)}', flush=True)
        if args.class_balanced:
            counts = train_df['label'].value_counts().sort_index()
            weights = torch.tensor([len(train_df) / (2.0 * counts.get(0, 1)), len(train_df) / (2.0 * counts.get(1, 1))], dtype=torch.float32, device=device)
            criterion = nn.CrossEntropyLoss(weight=weights)
        else:
            criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
        best_auc = -np.inf
        best_state = copy.deepcopy(model.state_dict())
        best_metrics: Optional[Dict[str, object]] = None
        best_epoch = 0
        stale = 0
        for epoch in range(1, args.epochs + 1):
            train_metrics = train_one_epoch(model, train_loader, optimizer, criterion, device, teacher_weight=args.teacher_weight, teacher_temperature=args.teacher_temperature)
            val_metrics = evaluate(model, val_loader, device)
            scheduler.step()
            val_auc = float(val_metrics['auc'] or 0.0)
            if val_auc > best_auc:
                best_auc = val_auc
                best_state = copy.deepcopy(model.state_dict())
                best_metrics = val_metrics
                best_epoch = epoch
                stale = 0
            else:
                stale += 1
            if epoch <= 3 or epoch % 5 == 0 or epoch == best_epoch:
                print(f"  Epoch {epoch:03d}: loss={train_metrics['loss']:.4f}, train_acc={train_metrics['acc']:.4f}, val_auc={val_auc:.4f}, val_acc={val_metrics['accuracy']:.4f}, best_auc={best_auc:.4f}@{best_epoch}", flush=True)
            if stale >= args.patience:
                print(f'  Early stop at epoch {epoch}', flush=True)
                break
        assert best_metrics is not None
        fold_dir = os.path.join(args.output_dir, f'fold_{fold_idx}')
        os.makedirs(fold_dir, exist_ok=True)
        torch.save(best_state, os.path.join(fold_dir, 'best_model.pth'))
        pred_df = pd.DataFrame(best_metrics.pop('predictions'))
        pred_df['fold'] = fold_idx
        pred_df.to_csv(os.path.join(fold_dir, 'predictions.csv'), index=False)
        all_predictions.append(pred_df)
        rec = dict(best_metrics)
        rec.update({'fold': fold_idx, 'best_epoch': best_epoch, 'source_checkpoint': source_ckpt, 'n_train': int(len(train_ds)), 'n_val': int(len(val_ds))})
        fold_metrics.append(rec)
        print(f"  Fold {fold_idx} best AUC={rec['auc']:.4f}, ACC={rec['accuracy']:.4f}", flush=True)
    oof = pd.concat(all_predictions, ignore_index=True)
    oof.to_csv(os.path.join(args.output_dir, 'oof_predictions.csv'), index=False)
    y_true = oof['label'].astype(int).to_numpy()
    prob = oof['prob_pos'].astype(float).to_numpy()
    pooled = metrics_from_prob(y_true, prob)
    metric_df = pd.DataFrame(fold_metrics)
    metric_df.to_csv(os.path.join(args.output_dir, 'fold_metrics.csv'), index=False)
    summary = {'output_dir': args.output_dir, 'roi_dir': args.roi_dir, 'index_csv': args.index_csv, 'n': int(len(index)), 'label_counts': {str(k): int(v) for k, v in index['label'].value_counts().sort_index().items()}, 'adaptation_mode': args.adaptation_mode, 'source_model_dir': args.source_model_dir, 'teacher_pred_csv': args.teacher_pred_csv, 'teacher_weight': args.teacher_weight, 'intensity_mode': args.intensity_mode, 'class_balanced': bool(args.class_balanced), 'pooled_oof_metrics': pooled, 'fold_mean_metrics': {key: float(metric_df[key].mean()) for key in ['auc', 'accuracy', 'sensitivity', 'specificity', 'f1', 'brier'] if key in metric_df}, 'fold_std_metrics': {key: float(metric_df[key].std(ddof=0)) for key in ['auc', 'accuracy', 'sensitivity', 'specificity', 'f1', 'brier'] if key in metric_df}, 'elapsed_minutes': (time.time() - start) / 60.0}
    with open(os.path.join(args.output_dir, 'external_adaptation_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
