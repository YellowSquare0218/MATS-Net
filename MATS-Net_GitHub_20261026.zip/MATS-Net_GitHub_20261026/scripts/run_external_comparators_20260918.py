from _paths import project_path as _project_path
import argparse
import json
import logging
from pathlib import Path
import random
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedShuffleSplit, StratifiedKFold, GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
import joblib
import adapt_external_holdout_t2 as h
import supplement_architectures as arch
import net_family_3d as nets
SEED = 20260824
MODELS = {'resnet18': ('resnet18_monai', 'heef_historical_resnet18_panel_20260915/single_T2W'), 'swin': ('swin_small_monai', 'heef_historical_swin_panel_20260915/single_T2W'), 'convnext_no_distillation': ('convnext3d_tiny', 'grouped_deep_recompute_aug262/single_T2W')}

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

def model_for(name, path):
    nets.MODELS['resnet18_monai'] = arch.ResNet18Features
    nets.MODELS['swin_small_monai'] = arch.SwinSmallFeatures
    model = nets.get_model(name, in_chans=1, num_classes=2)
    model.load_state_dict(h.load_state(str(path), torch.device('cpu')), strict=True)
    return model.cuda()

def load(args):
    root = args.project
    roi = root / 'dataset/guangxi_external_roi_t2_center_crop_f0p45'
    index = pd.read_csv(roi / 'index.csv', dtype={'id': str}).reset_index(drop=True)
    ref = root / 'work/external_t2_adapt_stratified280_20260824/ma_cmara_student'
    manifest = json.loads((ref / 'all_case_training_manifest.json').read_text())
    assert len(index) == 352 and index.id.is_unique
    training = set(manifest['training_ids'])
    heldout = set(manifest['heldout_ids'])
    assert len(training) == 280 and len(heldout) == 72 and (not training & heldout)
    assert set(index.id) == training | heldout
    ti, _ = next(StratifiedShuffleSplit(n_splits=1, train_size=280, random_state=SEED).split(index, index.label))
    assert set(index.iloc[ti].id) == training
    train = index.iloc[ti].reset_index(drop=True)
    assert all(((roi / pid / 'T2W.nii.gz').is_file() for pid in index.id))
    protocol = {'n': 352, 'training_n': 280, 'heldout_n': 72, 'training_ids': manifest['training_ids'], 'heldout_ids': manifest['heldout_ids'], 'roi': str(roi), 'intensity': 'minmax', 'epoch_plan': manifest['epoch_plan'], 'seed': SEED, 'batch_size': 16, 'lr': 8e-05, 'weight_decay': 0.0001, 'teacher_weight': 0, 'class_balanced': True, 'scope': 'full352 mixed apparent; adaptation280; heldout72 separately; NOT independent validation of all352', 'epoch_budget_caveat': 'Fixed historical student budgets reused; prior external OOF epoch-plan tuning may have used current heldout labels. No new heldout tuning, but not a pristine test set.', 'radiomics': 'T2 crop-level PyRadiomics + elastic-net fit on same280; no lesion segmentation available; NOT tumor-mask radiomics; no internal radiomics pretraining', 'delta': 'method AUC minus historical distilled student AUC; paired fixed-score bootstrap', 'original_comparator': 'Historical original T2 comparator kept as reference; used a different crop and epoch plan; not a fully matched distillation control', 'models': {key: list(value) for key, value in MODELS.items()}}
    target = args.output / 'protocol.json'
    if target.exists():
        assert json.loads(target.read_text()) == protocol
    else:
        save(target, protocol)
    return (roi, index, train, manifest)

def datasets(roi, index, train):
    return (h.ExternalT2Dataset(str(roi), train, 'T2W', augment=True, intensity_mode='minmax'), h.ExternalT2Dataset(str(roi), index, 'T2W', augment=False, intensity_mode='minmax'))

def smoke(args, roi, index, train):
    td, ed = datasets(roi, index, train)
    batch = h.collate([td[0], td[1]])
    assert torch.isfinite(batch['volume']).all()
    result = {}
    for key, (name, folder) in MODELS.items():
        paths = h.list_checkpoints(str(args.project / 'training_results' / folder))
        assert len(paths) == 5
        model = model_for(name, paths[0])
        model.train()
        out = model(batch['volume'].cuda())
        loss = torch.nn.functional.cross_entropy(out, batch['label'].cuda())
        assert out.shape == (2, 2) and torch.isfinite(loss)
        loss.backward()
        assert any((p.grad is not None and torch.isfinite(p.grad).all() and (p.grad.abs().sum() > 0) for p in model.parameters()))
        result[key] = {'shape': list(batch['volume'].shape), 'loss': float(loss.detach()), 'checkpoints': paths}
        del model, out, loss
        torch.cuda.empty_cache()
    import radiomics, SimpleITK
    result['radiomics_version'] = radiomics.__version__
    save(args.output / 'smoke_passed.json', result)
    print('SMOKE_PASSED', flush=True)

def neural(args, roi, index, train, manifest):
    td, ed = datasets(roi, index, train)
    ev = DataLoader(ed, batch_size=16, num_workers=2, shuffle=False, collate_fn=h.collate)
    for key, (name, folder) in MODELS.items():
        dest = args.output / key
        dest.mkdir(exist_ok=True)
        sources = h.list_checkpoints(str(args.project / 'training_results' / folder))
        pred = index[['id', 'label']].rename(columns={'id': 'pid'}).copy()
        for fold, (source, epochs) in enumerate(zip(sources, manifest['epoch_plan']), 1):
            cached = dest / f'fold_{fold}/predictions.csv'
            if cached.exists():
                part = pd.read_csv(cached, dtype={'pid': str})
                assert part.pid.tolist() == pred.pid.tolist()
                pred[f'source_{fold}'] = part.source_prob
                pred[f'adapted_{fold}'] = part.adapted_prob
                continue
            torch.manual_seed(SEED + fold)
            np.random.seed(SEED + fold)
            random.seed(SEED + fold)
            model = model_for(name, source)
            before = h.predict_prob(model, ev, torch.device('cuda'))
            loader = DataLoader(td, batch_size=16, shuffle=True, generator=torch.Generator().manual_seed(SEED + fold), num_workers=2, collate_fn=h.collate)
            counts = train.label.value_counts()
            weights = torch.tensor([len(train) / (2 * counts[i]) for i in [0, 1]], dtype=torch.float32, device='cuda')
            criterion = torch.nn.CrossEntropyLoss(weight=weights)
            opt = torch.optim.AdamW(model.parameters(), lr=8e-05, weight_decay=0.0001)
            sch = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=int(epochs))
            fd = cached.parent
            fd.mkdir(exist_ok=True)
            print(f'START {key} fold={fold} epochs={epochs}', flush=True)
            for epoch in range(1, int(epochs) + 1):
                metrics = h.train_epoch(model, loader, opt, criterion, torch.device('cuda'), 0.0, 2.0)
                assert np.isfinite(metrics['loss'])
                sch.step()
                if epoch <= 3 or epoch % 5 == 0 or epoch == epochs:
                    print(key, fold, epoch, metrics, flush=True)
            torch.save(model.state_dict(), fd / 'final_model.pth')
            after = h.predict_prob(model, ev, torch.device('cuda'))
            part = pred[['pid', 'label']].copy()
            part['source_prob'] = before
            part['adapted_prob'] = after
            part.to_csv(cached, index=False)
            save(fd / 'provenance.json', {'source_checkpoint': source, 'epochs': int(epochs), 'seed': SEED + fold, 'no_external_score_selection': True})
            pred[f'source_{fold}'] = before
            pred[f'adapted_{fold}'] = after
            del model, opt, sch
            torch.cuda.empty_cache()
        pred['source_ensemble_prob'] = pred[[f'source_{i}' for i in range(1, 6)]].mean(axis=1)
        pred['adapted_ensemble_prob'] = pred[[f'adapted_{i}' for i in range(1, 6)]].mean(axis=1)
        pred['scope'] = np.where(pred.pid.isin(set(train.id)), 'adaptation', 'heldout')
        pred.to_csv(dest / 'all_case_predictions.csv', index=False)
        print('MODEL_COMPLETE', key, flush=True)

def radiomics_fit(args, roi, index, train):
    import nibabel as nib
    import SimpleITK as sitk
    from radiomics import featureextractor
    logging.getLogger('radiomics').setLevel(logging.ERROR)
    dest = args.output / 'radiomics'
    dest.mkdir(exist_ok=True)
    cache = dest / 'crop_features.csv'
    if not cache.exists():
        ex = featureextractor.RadiomicsFeatureExtractor(normalize=True, normalizeScale=100, binWidth=25, removeOutliers=3)
        ex.disableAllFeatures()
        for c in ['firstorder', 'glcm', 'glrlm', 'glszm']:
            ex.enableFeatureClassByName(c)
        rows = []
        for i, pid in enumerate(index.id):
            n = nib.load(str(roi / pid / 'T2W.nii.gz'))
            arr = n.get_fdata().astype(np.float32)
            assert np.isfinite(arr).all()
            mask = (np.abs(arr) > 1e-08).astype(np.uint8)
            assert mask.sum() >= 8
            im = sitk.GetImageFromArray(np.pad(arr.transpose(2, 1, 0), 1))
            ma = sitk.GetImageFromArray(np.pad(mask.transpose(2, 1, 0), 1))
            spacing = tuple((float(v) for v in n.header.get_zooms()[:3]))
            im.SetSpacing(spacing)
            ma.CopyInformation(im)
            feats = ex.execute(im, ma)
            record = {'pid': pid}
            record.update({k: float(v) for k, v in feats.items() if k.startswith('original_')})
            assert len(record) > 30
            rows.append(record)
            if i % 20 == 0:
                print('RADIOMICS', i + 1, len(index), flush=True)
        pd.DataFrame(rows).to_csv(cache, index=False)
    feats = pd.read_csv(cache, dtype={'pid': str}).set_index('pid').reindex(index.id)
    assert feats.notna().all(axis=1).all()
    x = feats.to_numpy()
    y = index.label.to_numpy()
    mask = index.id.isin(set(train.id)).to_numpy()
    pipe = make_pipeline(SimpleImputer(strategy='median'), StandardScaler(), LogisticRegression(penalty='elasticnet', solver='saga', class_weight='balanced', max_iter=10000, random_state=SEED))
    search = GridSearchCV(pipe, {'logisticregression__C': [0.01, 0.1, 1.0], 'logisticregression__l1_ratio': [0.1, 0.5, 0.9]}, scoring='roc_auc', cv=StratifiedKFold(5, shuffle=True, random_state=SEED), n_jobs=4, error_score='raise')
    search.fit(x[mask], y[mask])
    joblib.dump(search, dest / 'elastic_net.joblib')
    pred = pd.DataFrame({'pid': index.id, 'label': y, 'adapted_ensemble_prob': search.predict_proba(x)[:, 1], 'scope': np.where(mask, 'adaptation', 'heldout')})
    pred.to_csv(dest / 'all_case_predictions.csv', index=False)
    save(dest / 'feature_protocol.json', {'features': list(feats.columns), 'params': search.best_params_, 'normalizeScale': 100, 'binWidth': 25, 'mask': 'nonzero cropped volume with zero padding; not tumor mask', 'spacing': 'NIfTI zooms', 'fit': 'same280; innerCV280 only; not internally pretrained'})

def summarize(args):
    from sklearn.metrics import accuracy_score, recall_score, f1_score, brier_score_loss, confusion_matrix
    ref = args.project / 'work/external_t2_adapt_stratified280_20260824'
    frames = {'Distilled T2WI student': pd.read_csv(ref / 'ma_cmara_student/all_case_predictions.csv'), 'Original T2WI comparator': pd.read_csv(ref / 'original_t2_control/all_case_predictions.csv')}
    for key in list(MODELS) + ['radiomics']:
        path = args.output / key / 'all_case_predictions.csv'
        if path.exists():
            frames[key] = pd.read_csv(path)
    reference = frames['Distilled T2WI student'].set_index('pid')
    rows = []
    for name, d in frames.items():
        d = d.set_index('pid').reindex(reference.index)
        assert d.label.equals(reference.label)
        assert d.scope.equals(reference.scope)
        for scope in ['full_mixed_352', 'adaptation_280', 'heldout_72']:
            mask = np.ones(len(d), bool) if scope == 'full_mixed_352' else d.scope.eq('adaptation' if scope == 'adaptation_280' else 'heldout').to_numpy()
            y = d.label.to_numpy()[mask]
            p = d.adapted_ensemble_prob.to_numpy()[mask]
            rp = reference.adapted_ensemble_prob.to_numpy()[mask]
            predicted = p >= 0.5
            tn, fp, fn, tp = confusion_matrix(y, predicted).ravel()
            auc = roc_auc_score(y, p)
            rng = np.random.default_rng(20260918)
            neg = np.flatnonzero(y == 0)
            pos = np.flatnonzero(y == 1)
            aa = []
            dd = []
            for _ in range(2000):
                ix = np.r_[rng.choice(neg, len(neg)), rng.choice(pos, len(pos))]
                v = roc_auc_score(y[ix], p[ix])
                aa.append(v)
                dd.append(v - roc_auc_score(y[ix], rp[ix]))
            lo, hi = np.quantile(aa, [0.025, 0.975])
            dl, dh = np.quantile(dd, [0.025, 0.975])
            ece = 0
            for k in range(10):
                b = (p >= k / 10) & (p < (k + 1) / 10 if k < 9 else p <= 1)
                if b.any():
                    ece += b.mean() * abs(p[b].mean() - y[b].mean())
            rows.append(dict(model=name, scope=scope, n=len(y), auc=auc, auc_ci_low=lo, auc_ci_high=hi, delta_auc_vs_student=auc - roc_auc_score(y, rp), delta_ci_low=dl, delta_ci_high=dh, accuracy=accuracy_score(y, predicted), sensitivity=recall_score(y, predicted), specificity=tn / (tn + fp), f1=f1_score(y, predicted), brier=brier_score_loss(y, p), ece=ece, tn=int(tn), fp=int(fp), fn=int(fn), tp=int(tp)))
    pd.DataFrame(rows).to_csv(args.output / 'external_comparison_metrics.csv', index=False)
    print('SUMMARY_COMPLETE', list(frames), flush=True)

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project', type=Path, default=Path(_project_path('')))
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--mode', choices=['smoke', 'run', 'summary'], required=True)
    args = p.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(8)
    roi, index, train, manifest = load(args)
    if args.mode == 'smoke':
        smoke(args, roi, index, train)
        return
    if args.mode == 'summary':
        summarize(args)
        return
    assert (args.output / 'smoke_passed.json').exists()
    radiomics_fit(args, roi, index, train)
    neural(args, roi, index, train, manifest)
    summarize(args)
    save(args.output / 'complete.json', {'finished': True})
if __name__ == '__main__':
    main()
