import os
from pathlib import Path


def project_path(relative=""):
    root = Path(os.environ.get("MATSNET_ROOT", Path(__file__).resolve().parents[1])).expanduser()
    return str(root / relative)
