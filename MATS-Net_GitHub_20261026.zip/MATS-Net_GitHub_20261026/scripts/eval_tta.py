from _paths import project_path as _project_path
import os, sys, json, argparse, warnings
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, recall_score
import nibabel as nib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import get_fusion, get_model, count_params
warnings.filterwarnings('ignore')
ROI_DIR = _project_path('dataset/roi_v4')
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']
BATCH_SIZE = 16
NUM_WORKERS = 4
TTA_FLIPS = [(False, False, False), (True, False, False), (False, True, False), (False, False, True), (True, True, False), (True, False, True), (False, True, True), (True, True, True)]
TTA_FLIPS_LIGHT = [(False, False, False), (False, True, False), (False, False, True), (False, True, True)]

def apply_flip(vol, flip_d, flip_h, flip_w):
    if flip_d:
        vol = torch.flip(vol, dims=[2])
    if flip_h:
        vol = torch.flip(vol, dims=[3])
    if flip_w:
        vol = torch.flip(vol, dims=[4])
    return vol

class MRIInferenceDataset(Dataset):

    def __init__(self, root_dir, index_df, modalities=None, task=2):
        self.root_dir = root_dir
        self.df = index_df.reset_index(drop=True)
        self.modalities = modalities or MODALITIES
        self.task = task

    def __len__(self):
        return len(self.df)

    def _load_volume(self, pid, mod):
        fp = os.path.join(self.root_dir, str(pid), f'{mod}.nii.gz')
        img = nib.load(fp)
        data = img.get_fdata().astype(np.float32)
        data = np.transpose(data, (2, 0, 1))
        vmin, vmax = (data.min(), data.max())
        if vmax > vmin:
            data = (data - vmin) / (vmax - vmin)
        return data

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        pid = str(row['id'])
        volumes = []
        for mod in self.modalities:
            vol = self._load_volume(pid, mod)
            volumes.append(torch.from_numpy(vol).unsqueeze(0))
        label = int(row['label']) if self.task == 2 else int(row['state']) - 1
        return {'pid': pid, 'volumes': volumes, 'label': label}

def collate_fn(batch):
    n_mods = len(batch[0]['volumes'])
    volumes = []
    for i in range(n_mods):
        vols = [item['volumes'][i] for item in batch]
        volumes.append(torch.stack(vols, dim=0))
    return {'pid': [item['pid'] for item in batch], 'volumes': volumes, 'label': torch.tensor([item['label'] for item in batch], dtype=torch.long)}

@torch.no_grad()
def predict_tta(model, vols, device, use_fusion=False, no_depth=False):
    flip_list = TTA_FLIPS_LIGHT if no_depth else TTA_FLIPS
    all_probs = []
    for flip_d, flip_h, flip_w in flip_list:
        if use_fusion:
            flip_vols = [apply_flip(v, flip_d, flip_h, flip_w) for v in vols]
            result = model(flip_vols)
        else:
            x = torch.cat(vols, dim=1).to(device)
            x = apply_flip(x, flip_d, flip_h, flip_w)
            result = model(x)
        if isinstance(result, tuple):
            logits = result[0]
        else:
            logits = result
        probs = F.softmax(logits, dim=1).cpu()
        all_probs.append(probs)
    return torch.stack(all_probs).mean(dim=0)

def evaluate_fold(model, val_loader, device, num_classes, use_fusion, no_depth=False):
    model.eval()
    all_probs, all_labels, all_pids = ([], [], [])
    for batch in val_loader:
        vols = [v.to(device) for v in batch['volumes']]
        probs = predict_tta(model, vols, device, use_fusion, no_depth)
        all_probs.append(probs)
        all_labels.append(batch['label'])
        all_pids.extend(batch['pid'])
    probs = torch.cat(all_probs, dim=0).numpy()
    labels = torch.cat(all_labels, dim=0).numpy()
    preds = probs.argmax(axis=1)
    metrics = {'acc': accuracy_score(labels, preds)}
    if num_classes == 2:
        try:
            metrics['auc'] = roc_auc_score(labels, probs[:, 1])
        except ValueError:
            metrics['auc'] = 0
        metrics['f1'] = f1_score(labels, preds, zero_division=0)
        metrics['recall'] = recall_score(labels, preds, zero_division=0)
    else:
        try:
            metrics['auc'] = roc_auc_score(labels, probs, multi_class='ovr', average='macro')
        except ValueError:
            metrics['auc'] = 0
        metrics['f1'] = f1_score(labels, preds, average='macro', zero_division=0)
        metrics['recall'] = recall_score(labels, preds, average='macro', zero_division=0)
    return metrics

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_dir', type=str, required=True, help='Path to experiment output dir (contains fold_*/best_model.pth)')
    parser.add_argument('--model', type=str, default='convnext3d_tiny')
    parser.add_argument('--modal', type=str, default='all')
    parser.add_argument('--task', type=int, default=2)
    parser.add_argument('--fusion', type=str, default='early')
    parser.add_argument('--no_depth_flip', action='store_true', help='Skip depth-axis flips (4 views instead of 8)')
    args = parser.parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'Device: {device}')
    print(f'Model dir: {args.model_dir}')
    index = pd.read_csv(os.path.join(ROI_DIR, 'index.csv'))
    if args.modal == 'all':
        modalities = MODALITIES
    else:
        modalities = [args.modal]
    num_classes = args.task
    use_fusion = args.fusion not in (None, '', 'early') and args.modal == 'all'
    if args.task == 2:
        labels_for_split = index['label'].values
    else:
        labels_for_split = index['state'].values
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    fold_results = []
    for fold_idx, (train_idx, val_idx) in enumerate(skf.split(index, labels_for_split)):
        fold_dir = os.path.join(args.model_dir, f'fold_{fold_idx + 1}')
        ckpt_path = os.path.join(fold_dir, 'best_model.pth')
        if not os.path.exists(ckpt_path):
            print(f'  Fold {fold_idx + 1}: no checkpoint, skipping')
            continue
        if use_fusion:
            model = get_fusion(args.fusion, args.model, num_classes).to(device)
        else:
            model = get_model(args.model, in_chans=4, num_classes=num_classes).to(device)
        model.load_state_dict(torch.load(ckpt_path, map_location=device))
        n_params = count_params(model)
        val_df = index.iloc[val_idx]
        val_ds = MRIInferenceDataset(ROI_DIR, val_df, modalities, task=args.task)
        val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, collate_fn=collate_fn)
        print(f"\nFold {fold_idx + 1}: {n_params / 1000000.0:.1f}M params, {len(val_ds)} val samples, TTA {('4' if args.no_depth_flip else '8')}-view")
        metrics = evaluate_fold(model, val_loader, device, num_classes, use_fusion, args.no_depth_flip)
        fold_results.append(metrics)
        print(f"  ACC={metrics['acc']:.4f}, AUC={metrics.get('auc', 0):.4f}, F1={metrics['f1']:.4f}")
    print(f"\n{'=' * 60}")
    print(f'TTA CV Summary ({args.task}-class):')
    for key in ['acc', 'auc', 'f1', 'recall']:
        if key in fold_results[0]:
            vals = [r[key] for r in fold_results]
            print(f'  {key}: {np.mean(vals):.4f} ± {np.std(vals):.4f}')
if __name__ == '__main__':
    main()
