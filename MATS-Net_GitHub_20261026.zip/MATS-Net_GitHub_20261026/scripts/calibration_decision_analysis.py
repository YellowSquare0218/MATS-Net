import argparse
import math
import os
import numpy as np
import pandas as pd
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss, roc_auc_score
try:
    from sklearn.model_selection import StratifiedGroupKFold
except ImportError:
    StratifiedGroupKFold = None
from sklearn.model_selection import StratifiedKFold
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_INPUT = os.path.join(PROJECT_ROOT, 'training_results', 'fast_evidence_fusion_distill_2cls', 'aligned_predictions.csv')
DEFAULT_OUTPUT = os.path.join(PROJECT_ROOT, 'training_results', 'fast_evidence_fusion_distill_2cls', 'calibration_decision')

def base_patient_id(value):
    text = str(value).strip()
    if text.endswith('.0'):
        text = text[:-2]
    if text.endswith('_2'):
        text = text[:-2]
    return text

def make_splits(y, groups=None, n_splits=5, seed=42, split_strategy='group'):
    y = np.asarray(y, dtype=int)
    if split_strategy == 'group' and groups is not None:
        if StratifiedGroupKFold is None:
            raise ImportError('StratifiedGroupKFold unavailable; use --split_strategy stratified.')
        splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
        return list(splitter.split(np.zeros((len(y), 1)), y, groups=groups))
    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(splitter.split(np.zeros((len(y), 1)), y))

def clip_prob(p):
    return np.clip(np.asarray(p, dtype=float), 1e-05, 1 - 1e-05)

def logit(p):
    p = clip_prob(p)
    return np.log(p / (1 - p))

def build_candidates(df):
    candidates = {}
    for col in ['selected_fusion_auc', 'selected_fusion_best_acc']:
        if col in df.columns:
            candidates[col] = df[col].to_numpy(float)
    core_cols = [c for c in ['mara', 'early', 'cif', 'cmara', 'gmara_acc'] if c in df.columns]
    if core_cols:
        weights = {'mara': 0.3, 'early': 0.2, 'cif': 0.2, 'cmara': 0.15, 'gmara_acc': 0.15}
        total = sum((weights[c] for c in core_cols))
        deep_core = sum((weights[c] / total * df[c].to_numpy(float) for c in core_cols))
        if 'geo_lr_c0_1' in df.columns:
            candidates['EvidenceFusion-main'] = 0.75 * deep_core + 0.25 * df['geo_lr_c0_1'].to_numpy(float)
        else:
            candidates['EvidenceFusion-main'] = deep_core
        candidates['DeepCore-weighted'] = deep_core
    if 'gmara_distill_w030' in df.columns:
        distill_cols = [c for c in ['mara', 'early', 'cif', 'gmara_acc', 'gmara_distill_w030'] if c in df.columns]
        distill_core = df[distill_cols].mean(axis=1)
        if 'geo_lr_c0_1' in df.columns:
            candidates['EvidenceFusion-distill'] = 0.8 * distill_core + 0.2 * df['geo_lr_c0_1']
        else:
            candidates['EvidenceFusion-distill'] = distill_core
        if 'geo_lr_c1_0' in df.columns:
            candidates['EvidenceFusion-distill-auc'] = 0.85 * distill_core + 0.15 * df['geo_lr_c1_0']
        candidates['DistillCore-mean'] = distill_core
    for col in ['mara', 'gmara_acc', 'gmara_distill_w030', 'tripath_acc', 'geo_lr_c0_1']:
        if col in df.columns:
            candidates[col] = df[col]
    return {k: clip_prob(v) for k, v in candidates.items()}

def binary_metrics(y, score, threshold=0.5):
    y = np.asarray(y, dtype=int)
    pred = (score >= threshold).astype(int)
    pos = y == 1
    neg = y == 0
    tp = int(np.sum((pred == 1) & pos))
    fn = int(np.sum((pred == 0) & pos))
    tn = int(np.sum((pred == 0) & neg))
    fp = int(np.sum((pred == 1) & neg))
    precision = tp / (tp + fp) if tp + fp else 0.0
    recall = tp / (tp + fn) if tp + fn else 0.0
    specificity = tn / (tn + fp) if tn + fp else 0.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {'auc': roc_auc_score(y, score), 'acc': (tp + tn) / len(y), 'f1': f1, 'precision': precision, 'recall': recall, 'specificity': specificity, 'threshold': float(threshold)}

def ece_score(y, score, n_bins=10):
    y = np.asarray(y, dtype=int)
    score = clip_prob(score)
    bins = np.linspace(0.0, 1.0, n_bins + 1)
    ece = 0.0
    mce = 0.0
    rows = []
    for i in range(n_bins):
        lo = bins[i]
        hi = bins[i + 1]
        if i == n_bins - 1:
            mask = (score >= lo) & (score <= hi)
        else:
            mask = (score >= lo) & (score < hi)
        if not np.any(mask):
            continue
        conf = float(np.mean(score[mask]))
        obs = float(np.mean(y[mask]))
        gap = abs(conf - obs)
        weight = float(np.mean(mask))
        ece += weight * gap
        mce = max(mce, gap)
        rows.append({'bin': i + 1, 'lo': lo, 'hi': hi, 'n': int(np.sum(mask)), 'mean_pred': conf, 'observed_rate': obs, 'abs_gap': gap})
    return (ece, mce, pd.DataFrame(rows))

def calibration_slope_intercept(y, score):
    x = logit(score).reshape(-1, 1)
    model = LogisticRegression(C=1000000.0, solver='lbfgs', max_iter=1000)
    model.fit(x, y)
    return (float(model.intercept_[0]), float(model.coef_[0, 0]))

def platt_oof(y, score, n_splits=5, seed=42, groups=None, split_strategy='group'):
    y = np.asarray(y, dtype=int)
    x = logit(score).reshape(-1, 1)
    out = np.zeros(len(y), dtype=float)
    splits = make_splits(y, groups=groups, n_splits=n_splits, seed=seed, split_strategy=split_strategy)
    for tr, va in splits:
        model = LogisticRegression(C=1.0, solver='lbfgs', max_iter=1000)
        model.fit(x[tr], y[tr])
        out[va] = model.predict_proba(x[va])[:, 1]
    return clip_prob(out)

def isotonic_oof(y, score, n_splits=5, seed=42, groups=None, split_strategy='group'):
    y = np.asarray(y, dtype=int)
    score = clip_prob(score)
    out = np.zeros(len(y), dtype=float)
    splits = make_splits(y, groups=groups, n_splits=n_splits, seed=seed, split_strategy=split_strategy)
    for tr, va in splits:
        model = IsotonicRegression(out_of_bounds='clip')
        model.fit(score[tr], y[tr])
        out[va] = model.predict(score[va])
    return clip_prob(out)

def decision_curve(y, score, thresholds):
    y = np.asarray(y, dtype=int)
    score = clip_prob(score)
    n = len(y)
    prevalence = float(np.mean(y))
    rows = []
    for pt in thresholds:
        pred = score >= pt
        tp = int(np.sum(pred & (y == 1)))
        fp = int(np.sum(pred & (y == 0)))
        nb = tp / n - fp / n * (pt / (1 - pt))
        nb_all = prevalence - (1 - prevalence) * (pt / (1 - pt))
        rows.append({'threshold_probability': float(pt), 'net_benefit_model': float(nb), 'net_benefit_treat_all': float(nb_all), 'net_benefit_treat_none': 0.0, 'standardized_net_benefit': float(nb / prevalence) if prevalence else np.nan, 'tp': tp, 'fp': fp})
    return pd.DataFrame(rows)

def bootstrap_calibration(y, score, n_boot=2000, seed=42, groups=None):
    rng = np.random.default_rng(seed)
    if groups is None:
        pos = np.where(y == 1)[0]
        neg = np.where(y == 0)[0]
        group_items = None
    else:
        group_frame = pd.DataFrame({'idx': np.arange(len(y)), 'group': groups, 'label': y})
        group_labels = group_frame.groupby('group')['label'].first()
        pos_groups = group_labels[group_labels == 1].index.to_numpy()
        neg_groups = group_labels[group_labels == 0].index.to_numpy()
        group_items = {g: v['idx'].to_numpy() for g, v in group_frame.groupby('group')}
    rows = []
    for _ in range(n_boot):
        if group_items is None:
            idx = np.concatenate([rng.choice(pos, len(pos), replace=True), rng.choice(neg, len(neg), replace=True)])
        else:
            sampled_groups = np.concatenate([rng.choice(pos_groups, len(pos_groups), replace=True), rng.choice(neg_groups, len(neg_groups), replace=True)])
            idx = np.concatenate([group_items[g] for g in sampled_groups])
        ece, _, _ = ece_score(y[idx], score[idx])
        rows.append({'auc': roc_auc_score(y[idx], score[idx]), 'brier': brier_score_loss(y[idx], score[idx]), 'ece': ece})
    boot = pd.DataFrame(rows)
    return {'auc_ci_low': float(boot['auc'].quantile(0.025)), 'auc_ci_high': float(boot['auc'].quantile(0.975)), 'brier_ci_low': float(boot['brier'].quantile(0.025)), 'brier_ci_high': float(boot['brier'].quantile(0.975)), 'ece_ci_low': float(boot['ece'].quantile(0.025)), 'ece_ci_high': float(boot['ece'].quantile(0.975))}

def markdown_table(df):
    cols = list(df.columns)
    lines = ['| ' + ' | '.join(cols) + ' |', '| ' + ' | '.join(['---'] * len(cols)) + ' |']
    for _, row in df.iterrows():
        vals = []
        for col in cols:
            val = row[col]
            if isinstance(val, (float, np.floating)):
                vals.append(f'{float(val):.4f}')
            else:
                vals.append(str(val))
        lines.append('| ' + ' | '.join(vals) + ' |')
    return '\n'.join(lines)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', default=DEFAULT_INPUT)
    parser.add_argument('--output', default=DEFAULT_OUTPUT)
    parser.add_argument('--n_boot', type=int, default=2000)
    parser.add_argument('--split_strategy', choices=['group', 'stratified'], default='group')
    args = parser.parse_args()
    df = pd.read_csv(args.input)
    y = df['label'].to_numpy(dtype=int)
    groups = df['pid'].map(base_patient_id).to_numpy() if 'pid' in df.columns else None
    candidates = build_candidates(df)
    os.makedirs(args.output, exist_ok=True)
    rows = []
    calib_bins = []
    decision_rows = []
    thresholds = np.linspace(0.1, 0.9, 17)
    for name, score in candidates.items():
        for variant, variant_score in [('raw', score), ('platt_oof', platt_oof(y, score, groups=groups, split_strategy=args.split_strategy)), ('isotonic_oof', isotonic_oof(y, score, groups=groups, split_strategy=args.split_strategy))]:
            ece, mce, bins = ece_score(y, variant_score)
            intercept, slope = calibration_slope_intercept(y, variant_score)
            row = {'candidate': name, 'variant': variant, 'brier': brier_score_loss(y, variant_score), 'ece': ece, 'mce': mce, 'calibration_intercept': intercept, 'calibration_slope': slope}
            row.update(binary_metrics(y, variant_score, threshold=0.5))
            if name in ('EvidenceFusion-distill', 'EvidenceFusion-main') and variant == 'raw':
                row.update(bootstrap_calibration(y, variant_score, n_boot=args.n_boot, groups=groups))
            rows.append(row)
            bins.insert(0, 'variant', variant)
            bins.insert(0, 'candidate', name)
            calib_bins.append(bins)
            dca = decision_curve(y, variant_score, thresholds)
            dca.insert(0, 'variant', variant)
            dca.insert(0, 'candidate', name)
            decision_rows.append(dca)
    summary = pd.DataFrame(rows).sort_values(['brier', 'ece', 'auc'], ascending=[True, True, False])
    bins = pd.concat(calib_bins, ignore_index=True)
    dca = pd.concat(decision_rows, ignore_index=True)
    summary.to_csv(os.path.join(args.output, 'calibration_summary.csv'), index=False)
    bins.to_csv(os.path.join(args.output, 'calibration_bins.csv'), index=False)
    dca.to_csv(os.path.join(args.output, 'decision_curve.csv'), index=False)
    show = summary[summary['candidate'].isin(['EvidenceFusion-distill', 'EvidenceFusion-main', 'gmara_distill_w030', 'gmara_acc', 'mara'])].head(20)
    primary = 'EvidenceFusion-distill' if 'EvidenceFusion-distill' in candidates else 'EvidenceFusion-main'
    dca_show = dca[(dca['candidate'] == primary) & (dca['variant'] == 'raw') & dca['threshold_probability'].isin([0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8])]
    report = ['# Calibration and decision analysis', '', f'Lower Brier/ECE is better. Platt and isotonic rows are generated by {args.split_strategy} 5-fold OOF calibration on the score only.', '', '## Calibration Summary', '', markdown_table(show), '', f'## {primary} Decision Curve', '', markdown_table(dca_show), '']
    with open(os.path.join(args.output, 'calibration_decision.md'), 'w', encoding='utf-8') as f:
        f.write('\n'.join(report))
    print('\n'.join(report))
if __name__ == '__main__':
    main()
