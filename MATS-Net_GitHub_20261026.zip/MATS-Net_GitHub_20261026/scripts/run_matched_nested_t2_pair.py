from _paths import project_path as _project_path
import argparse
import copy
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from torch.utils.data import DataLoader
import run_heef_262_fully_nested as nested
from evaluate_external_roi import ExternalROIDataset, collate
import supplement_architectures as arch

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project', type=Path, default=Path(_project_path('')))
    p.add_argument('--reference', type=Path, default=Path(_project_path('training_results/heef_262_fully_nested_20260913')))
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--mode', choices=['smoke', 'run'], required=True)
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--max-epochs', type=int, default=80)
    p.add_argument('--patience', type=int, default=20)
    p.add_argument('--workers', type=int, default=4)
    args = p.parse_args()
    torch.set_num_threads(8)
    base, configs, prepared, _, _ = nested.load_inputs(args)
    cfg = copy.deepcopy(configs['single_T2W'])
    splits = json.loads((args.reference / 'split_manifest.json').read_text())
    roi = args.project / 'dataset/guangxi_external_roi_auto_dwi_t2_clamped'
    index = roi / 'index.csv'
    external = pd.read_csv(index, dtype={'id': str})
    assert len(external) == 352 and external.id.is_unique
    assert not set(base.id) & set(external.id)
    for pid in external.id:
        assert (roi / pid / 'T2W.nii.gz').is_file()
    spec = {'seeds': [42, 137, 2026], 'n_internal': 262, 'n_external': 352, 'teacher': 'fixed eight-expert equal mean of each outer-training-specific inner OOF', 'teacher_files_sha256': {str(args.reference / f'outer_{i}/inner_oof_evidence.csv'): hashlib.sha256((args.reference / f'outer_{i}/inner_oof_evidence.csv').read_bytes()).hexdigest() for i in range(1, 6)}, 'matched_epochs': 'frozen nested single_T2W training-only selected epochs, identical for both arms and all seeds', 'matched_initialization': 'same random seed per fold/seed in both arms', 'loss': 'CE + weight * T^2 * KL(teacher probability || softmax(student logits/T))', 'weights': [0.0, 0.3], 'temperature': 2.0, 'teacher_temperature_transform': False, 'external_roi': str(roi), 'external_index_sha256': hashlib.sha256(index.read_bytes()).hexdigest(), 'external_form': 'five-fold checkpoint probability average per arm per seed', 'external_fit_or_selection': False, 'primary_seed': 42, 'note': 'new matched pair, not retrospective relabeling of historical 0.770'}
    path = args.output / 'matched_protocol.json'
    if path.exists():
        assert json.loads(path.read_text()) == spec
    nested.write_json(path, spec)
    protocol_hash = nested.digest(spec)
    lookup = {v: i for i, v in enumerate(base.id)}

    def ix(ids):
        return np.array([lookup[v] for v in ids])
    for seed in [42] if args.mode == 'smoke' else spec['seeds']:
        internal = {'hard': [], 'distilled': []}
        for number in [1] if args.mode == 'smoke' else range(1, 6):
            block = next((b for b in splits if b['outer_fold'] == number))
            teacher = pd.read_csv(args.reference / f'outer_{number}/inner_oof_evidence.csv', dtype={'id': str})
            assert set(teacher.id) == set(block['outer_train_ids'])
            assert not set(teacher.id) & set(block['outer_test_ids'])
            probs = pd.Series(teacher[nested.EXPERTS].mean(axis=1).to_numpy(), index=teacher.id).clip(0.0001, 1 - 0.0001)
            df = prepared['single_T2W'][0].copy()
            df['teacher_prob'] = df.id.map(probs)
            assert np.isfinite(df.iloc[ix(block['outer_train_ids'])].teacher_prob).all()
            n_epoch = json.loads((args.reference / f'outer_{number}/epoch_selection.json').read_text())['outer_refit_epochs']['single_T2W']
            for arm, weight in [('hard', 0.0), ('distilled', 0.3)]:
                config = copy.deepcopy(cfg)
                config.update(distill_weight=weight, distill_temperature=2.0, teacher_col='teacher_prob')
                data = (df, [], None, {})
                folder = args.output / ('smoke' if args.mode == 'smoke' else f'seed_{seed}') / arm / f'outer_{number}'
                _, pred = nested.fit_deep(args, arm, config, data, ix(block['outer_train_ids']), ix(block['outer_test_ids']), folder, nested.training.stable_seed(seed, number, 'single_T2W', 'outer'), protocol_hash, epochs=1 if args.mode == 'smoke' else n_epoch, smoke=args.mode == 'smoke')
                pred['outer_fold'], pred['seed'], pred['arm'] = (number, seed, arm)
                internal[arm].append(pred)
        if args.mode == 'smoke':
            ds = ExternalROIDataset(str(roi), str(index), ['T2W'])
            batch = next(iter(DataLoader(ds, batch_size=2, collate_fn=collate)))
            assert batch['volume'].shape == (2, 1, 16, 64, 64)
            assert torch.isfinite(batch['volume']).all()
            nested.write_json(args.output / 'smoke_passed.json', {'both_arms_backward': True, 'teacher_is_outer_training_only': True, 'external_sample_shape': list(batch['volume'].shape)})
            return
        for arm, parts in internal.items():
            out = args.output / f'seed_{seed}' / arm
            pred = pd.concat(parts, ignore_index=True)
            assert len(pred) == 262 and pred.pid.is_unique
            pred.to_csv(out / 'internal_predictions_262.csv', index=False)
    ds = ExternalROIDataset(str(roi), str(index), ['T2W'])
    loader = DataLoader(ds, batch_size=32, shuffle=False, num_workers=args.workers, collate_fn=collate)
    tasks = []
    for seed in spec['seeds']:
        for arm in ['hard', 'distilled']:
            out = args.output / f'seed_{seed}' / arm
            tasks.append((out, cfg, [out / f'outer_{i}/model.pt' for i in range(1, 6)], nested.training.build_model))
    architecture_run = args.project / 'training_results/heef_architecture_supplement_20260914'
    architecture_spec = json.loads((architecture_run / 'supplement_protocol.json').read_text())
    assert (architecture_run / 'training_complete.json').exists()
    for seed in spec['seeds']:
        for name in ['B1', 'B2']:
            out = architecture_run / f'seed_{seed}' / name
            tasks.append((out, architecture_spec['models'][name], [out / f'outer_{i}/refit/model.pt' for i in range(1, 6)], arch.build_model))
    for out, config, checkpoints, factory in tasks:
        pred = pd.DataFrame({'pid': external.id, 'label': external.label})
        for number, checkpoint in enumerate(checkpoints, 1):
            model, _ = factory(config, {}, torch.device('cuda'))
            model.load_state_dict(torch.load(checkpoint, weights_only=True), strict=True)
            model.eval()
            scores = []
            with torch.no_grad():
                for batch in loader:
                    scores.extend(model(batch['volume'].cuda()).softmax(1)[:, 1].cpu().tolist())
            pred[f'fold_{number}'] = scores
            del model
        pred['prob_pos'] = pred[[f'fold_{i}' for i in range(1, 6)]].mean(axis=1)
        pred.to_csv(out / 'external_predictions_352.csv', index=False)
        measured = nested.training.binary_metrics(pred.label.to_numpy(), pred.prob_pos.to_numpy())
        measured['balanced_accuracy'] = (measured['sensitivity'] + measured['specificity']) / 2
        nested.write_json(out / 'external_metrics.json', measured)
        nested.write_json(out / 'external_provenance.json', {'roi': str(roi), 'checkpoints': [str(v) for v in checkpoints], 'rule': 'unweighted five-fold probability average; threshold=0.5; no TTA; no external fitting'})
    nested.write_json(args.output / 'complete.json', {'matched_pair_seeds': spec['seeds'], 'n_external': 352})
if __name__ == '__main__':
    main()
