from __future__ import annotations
import argparse
import hashlib
import itertools
import json
import os
import random
import re
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.preprocessing import StandardScaler
from torch.utils.data import DataLoader
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'scripts'))
import train as core
EXPERT_CONFIGS = {'single_T2W': {'modalities': ['T2W'], 'fusion': None, 'tabular_source': 'none', 'select_metric': 'auc'}, 'single_DWI': {'modalities': ['DWI'], 'fusion': None, 'tabular_source': 'none', 'select_metric': 'auc'}, 'single_T1W': {'modalities': ['T1W'], 'fusion': None, 'tabular_source': 'none', 'select_metric': 'auc'}, 'gmara_auc': {'modalities': core.MODALITIES, 'fusion': 'geometry_mara', 'tabular_source': 'geometry', 'select_metric': 'auc', 'warmup': 8, 'fusion_kwargs': {'drop_rate': 0.12, 'intervention_ce_weight': 0.15, 'consistency_weight': 0.15, 'feature_weight': 0.01, 'aux_state_weight': 0.1, 'supcon_weight': 0.01}}, 'gmara_burden_w004': {'modalities': core.MODALITIES, 'fusion': 'geometry_mara', 'tabular_source': 'clinical_geometry', 'select_metric': 'acc', 'warmup': 8, 'aux_node_task': True, 'aux_node_source': 'src279_N_burden3', 'aux_node_weight': 0.04, 'fusion_kwargs': {'drop_rate': 0.1, 'intervention_ce_weight': 0.12, 'consistency_weight': 0.12, 'feature_weight': 0.01, 'aux_state_weight': 0.12, 'supcon_weight': 0.015}}}

def markdown_table(frame: pd.DataFrame) -> str:
    display = frame.copy()
    for column in display.select_dtypes(include=['floating']).columns:
        display[column] = display[column].map(lambda value: f'{value:.3f}')
    headers = [str(column) for column in display.columns]
    rows = [[str(value) for value in row] for row in display.itertuples(index=False, name=None)]
    lines = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(('---' for _ in headers)) + ' |']
    lines.extend(('| ' + ' | '.join(row) + ' |' for row in rows))
    return '\n'.join(lines)

def normalize_id(value: object) -> str:
    return re.sub('\\.0$', '', str(value)).strip()

def base_patient_id(value: object) -> str:
    return re.sub('_\\d+$', '', normalize_id(value))

def stable_seed(*parts: object) -> int:
    digest = hashlib.sha256('|'.join(map(str, parts)).encode('utf-8')).hexdigest()
    return int(digest[:8], 16) % (2 ** 31 - 1)

def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def ece_score(y: np.ndarray, score: np.ndarray, n_bins: int=10) -> float:
    bins = np.linspace(0, 1, n_bins + 1)
    result = 0.0
    for idx in range(n_bins):
        lo, hi = (bins[idx], bins[idx + 1])
        mask = (score >= lo) & (score <= hi if idx == n_bins - 1 else score < hi)
        if mask.any():
            result += float(mask.mean() * abs(score[mask].mean() - y[mask].mean()))
    return result

def binary_metrics(y: np.ndarray, score: np.ndarray) -> dict[str, float | int]:
    pred = (score >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {'n': int(len(y)), 'positive_n': int(y.sum()), 'negative_n': int((y == 0).sum()), 'auc': float(roc_auc_score(y, score)), 'accuracy': float(accuracy_score(y, pred)), 'sensitivity': float(tp / (tp + fn)), 'specificity': float(tn / (tn + fp)), 'f1': float(f1_score(y, pred)), 'brier': float(brier_score_loss(y, score)), 'ece': float(ece_score(y, score)), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

def bootstrap_metrics(y: np.ndarray, score: np.ndarray, n_boot: int, seed: int) -> dict[str, float | int]:
    rng = np.random.default_rng(seed)
    rows = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        if np.unique(y[idx]).size == 2:
            rows.append(binary_metrics(y[idx], score[idx]))
    frame = pd.DataFrame(rows)
    result: dict[str, float | int] = {'n_boot_valid': int(len(frame))}
    for column in ['auc', 'accuracy', 'sensitivity', 'specificity', 'f1', 'brier', 'ece']:
        result[f'{column}_ci_low'] = float(frame[column].quantile(0.025))
        result[f'{column}_ci_high'] = float(frame[column].quantile(0.975))
    return result

def prepare_expert_frame(base: pd.DataFrame, config: dict, clinical_csv: Path) -> tuple[pd.DataFrame, list[str], str | None, dict]:
    frame = base.copy()
    aux_col = None
    aux_stats = None
    if config.get('aux_node_task'):
        frame, aux_col, aux_stats = core.add_aux_node_labels(frame, clinical_path=str(clinical_csv), source=config['aux_node_source'])
    geometry_cols: list[str] = []
    clinical_cols: list[str] = []
    source = config.get('tabular_source', 'none')
    if source in ('geometry', 'clinical_geometry'):
        frame, geometry_cols = core.add_roi_geometry_features(frame)
    if source in ('clinical', 'clinical_geometry'):
        frame, clinical_cols = core.add_clinical_features(frame, str(clinical_csv))
    if frame['id'].tolist() != base['id'].tolist():
        raise AssertionError('Feature merge changed index row order')
    fusion_kwargs = dict(config.get('fusion_kwargs') or {})
    tabular_cols = geometry_cols + clinical_cols
    if tabular_cols:
        fusion_kwargs['tab_dim'] = len(tabular_cols)
    if config.get('aux_node_task'):
        fusion_kwargs['aux_node_weight'] = float(config['aux_node_weight'])
        fusion_kwargs['aux_node_classes'] = max(2, int((aux_stats or {}).get('classes') or 2))
    return (frame, tabular_cols, aux_col, fusion_kwargs)

def split_frames(frame: pd.DataFrame, train_idx: np.ndarray, eval_idx: np.ndarray, tabular_cols: list[str]) -> tuple[pd.DataFrame, pd.DataFrame, str | None]:
    train_df = frame.iloc[train_idx].copy()
    eval_df = frame.iloc[eval_idx].copy()
    tabular_col = None
    if tabular_cols:
        imputer = SimpleImputer(strategy='median')
        scaler = StandardScaler()
        train_tab = scaler.fit_transform(imputer.fit_transform(train_df[tabular_cols])).astype(np.float32)
        eval_tab = scaler.transform(imputer.transform(eval_df[tabular_cols])).astype(np.float32)
        tabular_col = 'tabular_features'
        train_df[tabular_col] = list(train_tab)
        eval_df[tabular_col] = list(eval_tab)
    return (train_df, eval_df, tabular_col)

def make_loaders(train_df: pd.DataFrame, eval_df: pd.DataFrame, config: dict, tabular_col: str | None, aux_col: str | None, num_workers: int) -> tuple[DataLoader, DataLoader]:
    train_ds = core.MRIDataset(core.ROI_DIR, train_df, config['modalities'], augment=True, task=2, tabular_col=tabular_col, aux_node_col=aux_col, teacher_col=config.get('teacher_col'))
    eval_ds = core.MRIDataset(core.ROI_DIR, eval_df, config['modalities'], augment=False, task=2, tabular_col=tabular_col, aux_node_col=aux_col)
    batch_size = min(core.BATCH_SIZE, max(1, len(train_ds) // 2))
    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, num_workers=num_workers, collate_fn=core.collate_fn)
    eval_loader = DataLoader(eval_ds, batch_size=batch_size, shuffle=False, num_workers=num_workers, collate_fn=core.collate_fn)
    return (train_loader, eval_loader)

def build_model(config: dict, fusion_kwargs: dict, device: torch.device) -> tuple[nn.Module, bool]:
    if config.get('fusion'):
        model = core.get_fusion(config['fusion'], 'convnext3d_tiny', 2, **fusion_kwargs).to(device)
        return (model, True)
    model = core.get_model('convnext3d_tiny', in_chans=len(config['modalities']), num_classes=2).to(device)
    return (model, False)

def train_inner_model(expert: str, config: dict, frame: pd.DataFrame, tabular_cols: list[str], aux_col: str | None, fusion_kwargs: dict, train_idx: np.ndarray, val_idx: np.ndarray, output_dir: Path, seed: int, max_epochs: int, patience: int, num_workers: int, device: torch.device) -> tuple[pd.DataFrame, int, float]:
    pred_path = output_dir / 'predictions.csv'
    meta_path = output_dir / 'training_meta.json'
    if pred_path.exists() and meta_path.exists():
        meta = json.loads(meta_path.read_text(encoding='utf-8'))
        return (pd.read_csv(pred_path), int(meta['best_epoch']), float(meta['best_score']))
    seed_everything(seed)
    train_df, val_df, tabular_col = split_frames(frame, train_idx, val_idx, tabular_cols)
    train_loader, val_loader = make_loaders(train_df, val_df, config, tabular_col, aux_col, num_workers)
    model, use_fusion = build_model(config, fusion_kwargs, device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=core.LR, weight_decay=core.WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=max_epochs)
    best_score = None
    best_epoch = 0
    best_predictions = None
    stale = 0
    for epoch in range(1, max_epochs + 1):
        core.train_epoch(model, train_loader, optimizer, criterion, device, fusion=use_fusion, causal_enabled=epoch > int(config.get('warmup') or 0))
        evaluated = core.validate(model, val_loader, criterion, device, 2, fusion=use_fusion)
        score = float(evaluated[config.get('select_metric', 'auc')])
        if best_score is None or score > best_score:
            best_score = score
            best_epoch = epoch
            best_predictions = pd.DataFrame(evaluated['predictions'])
            stale = 0
        else:
            stale += 1
        scheduler.step()
        if epoch <= 3 or epoch % 10 == 0:
            print(f"[{expert}] epoch={epoch} val_auc={evaluated['auc']:.4f} best_{config.get('select_metric', 'auc')}={best_score:.4f}@{best_epoch}", flush=True)
        if stale >= patience:
            break
    assert best_predictions is not None and best_score is not None
    output_dir.mkdir(parents=True, exist_ok=True)
    best_predictions.to_csv(pred_path, index=False)
    meta_path.write_text(json.dumps({'expert': expert, 'seed': seed, 'best_epoch': best_epoch, 'best_score': best_score, 'selection_metric': config.get('select_metric', 'auc'), 'n_train_records': int(len(train_idx)), 'n_val_records': int(len(val_idx))}, indent=2), encoding='utf-8')
    del model
    torch.cuda.empty_cache()
    return (best_predictions, best_epoch, best_score)

def fit_outer_and_predict(expert: str, config: dict, frame: pd.DataFrame, tabular_cols: list[str], aux_col: str | None, fusion_kwargs: dict, train_idx: np.ndarray, test_idx: np.ndarray, fixed_epochs: int, output_dir: Path, seed: int, num_workers: int, device: torch.device) -> pd.DataFrame:
    pred_path = output_dir / 'predictions.csv'
    meta_path = output_dir / 'training_meta.json'
    if pred_path.exists() and meta_path.exists():
        return pd.read_csv(pred_path)
    seed_everything(seed)
    train_df, test_df, tabular_col = split_frames(frame, train_idx, test_idx, tabular_cols)
    train_loader, test_loader = make_loaders(train_df, test_df, config, tabular_col, aux_col, num_workers)
    model, use_fusion = build_model(config, fusion_kwargs, device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.AdamW(model.parameters(), lr=core.LR, weight_decay=core.WEIGHT_DECAY)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=fixed_epochs)
    for epoch in range(1, fixed_epochs + 1):
        loss, accuracy = core.train_epoch(model, train_loader, optimizer, criterion, device, fusion=use_fusion, causal_enabled=epoch > int(config.get('warmup') or 0))
        scheduler.step()
        if epoch <= 3 or epoch % 10 == 0 or epoch == fixed_epochs:
            print(f'[outer refit {expert}] epoch={epoch}/{fixed_epochs} loss={loss:.4f} acc={accuracy:.4f}', flush=True)
    evaluated = core.validate(model, test_loader, criterion, device, 2, fusion=use_fusion)
    predictions = pd.DataFrame(evaluated['predictions'])
    output_dir.mkdir(parents=True, exist_ok=True)
    predictions.to_csv(pred_path, index=False)
    torch.save(model.state_dict(), output_dir / 'final_model.pth')
    meta_path.write_text(json.dumps({'expert': expert, 'seed': seed, 'fixed_epochs': fixed_epochs, 'n_train_records': int(len(train_idx)), 'n_test_records': int(len(test_idx)), 'outer_test_metrics': {key: value for key, value in evaluated.items() if key not in ('predictions', 'cm')}}, indent=2, default=float), encoding='utf-8')
    del model
    torch.cuda.empty_cache()
    return predictions

def select_expert_subset(inner_patient: pd.DataFrame, experts: list[str]) -> pd.DataFrame:
    y = inner_patient['label'].to_numpy(dtype=int)
    rows = []
    for size in range(1, len(experts) + 1):
        for subset in itertools.combinations(experts, size):
            score = inner_patient[list(subset)].mean(axis=1).to_numpy(dtype=float)
            rows.append({'experts': '+'.join(subset), 'n_experts': size, 'auc': float(roc_auc_score(y, score)), 'brier': float(brier_score_loss(y, score))})
    return pd.DataFrame(rows).sort_values(['auc', 'n_experts', 'brier', 'experts'], ascending=[False, True, True, True])

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--index-csv', type=Path, required=True)
    parser.add_argument('--clinical-csv', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--outer-splits', type=int, default=5)
    parser.add_argument('--inner-splits', type=int, default=4)
    parser.add_argument('--outer-folds', default='all', help='all or comma-separated 1-based folds')
    parser.add_argument('--experts', default=','.join(EXPERT_CONFIGS))
    parser.add_argument('--max-epochs', type=int, default=80)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--num-workers', type=int, default=4)
    parser.add_argument('--seed', type=int, default=20260808)
    parser.add_argument('--n-boot', type=int, default=5000)
    args = parser.parse_args()
    experts = [item.strip() for item in args.experts.split(',') if item.strip()]
    unknown = sorted(set(experts) - set(EXPERT_CONFIGS))
    if unknown:
        raise ValueError(f'Unknown experts: {unknown}')
    args.output.mkdir(parents=True, exist_ok=True)
    base = pd.read_csv(args.index_csv)
    base['id'] = base['id'].map(normalize_id)
    base['base_id'] = base['id'].map(base_patient_id)
    groups = base['base_id'].to_numpy()
    labels = base['label'].to_numpy(dtype=int)
    patient_n = int(base['base_id'].nunique())
    if patient_n < max(args.outer_splits, args.inner_splits) * 2:
        raise ValueError(f'Too few patients for nested splitting: {patient_n} patients, {args.outer_splits} outer folds, {args.inner_splits} inner folds')
    print(f'records={len(base)}; unique_patients={patient_n}; outer_splits={args.outer_splits}; inner_splits={args.inner_splits}', flush=True)
    prepared = {}
    for expert in experts:
        prepared[expert] = prepare_expert_frame(base, EXPERT_CONFIGS[expert], args.clinical_csv)
    outer = StratifiedGroupKFold(n_splits=args.outer_splits, shuffle=True, random_state=args.seed)
    outer_splits = list(outer.split(base, labels, groups))
    selected_outer = set(range(1, args.outer_splits + 1)) if args.outer_folds == 'all' else {int(item) for item in args.outer_folds.split(',')}
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'device={device}; experts={experts}; outer_folds={sorted(selected_outer)}', flush=True)
    outer_patient_frames = []
    selection_rows = []
    for outer_number, (outer_train_idx, outer_test_idx) in enumerate(outer_splits, start=1):
        if outer_number not in selected_outer:
            continue
        outer_dir = args.output / f'outer_{outer_number}'
        completed = outer_dir / 'outer_patient_predictions.csv'
        selection_path = outer_dir / 'selection.json'
        if completed.exists() and selection_path.exists():
            print(f'[skip] outer fold {outer_number} already complete', flush=True)
            outer_patient_frames.append(pd.read_csv(completed))
            selection_rows.append(json.loads(selection_path.read_text(encoding='utf-8')))
            continue
        print(f'===== OUTER FOLD {outer_number}/{args.outer_splits} =====', flush=True)
        outer_train = base.iloc[outer_train_idx]
        inner_groups = outer_train['base_id'].to_numpy()
        inner_labels = outer_train['label'].to_numpy(dtype=int)
        inner = StratifiedGroupKFold(n_splits=args.inner_splits, shuffle=True, random_state=stable_seed(args.seed, 'outer', outer_number, 'inner_split'))
        inner_splits = list(inner.split(outer_train, inner_labels, inner_groups))
        inner_predictions = []
        best_epochs: dict[str, list[int]] = {expert: [] for expert in experts}
        for inner_number, (inner_train_local, inner_val_local) in enumerate(inner_splits, start=1):
            inner_train_idx = outer_train_idx[inner_train_local]
            inner_val_idx = outer_train_idx[inner_val_local]
            fold_frame = base.iloc[inner_val_idx][['id', 'base_id', 'label']].copy()
            for expert in experts:
                config = EXPERT_CONFIGS[expert]
                frame, tabular_cols, aux_col, fusion_kwargs = prepared[expert]
                pred, best_epoch, _ = train_inner_model(expert, config, frame, tabular_cols, aux_col, fusion_kwargs, inner_train_idx, inner_val_idx, outer_dir / f'inner_{inner_number}' / expert, stable_seed(args.seed, outer_number, inner_number, expert), args.max_epochs, args.patience, args.num_workers, device)
                score_map = pred.set_index('pid')['prob_pos']
                fold_frame[expert] = fold_frame['id'].map(score_map)
                if fold_frame[expert].isna().any():
                    raise ValueError(f'Missing inner predictions for {expert}')
                best_epochs[expert].append(best_epoch)
            fold_frame['inner_fold'] = inner_number
            inner_predictions.append(fold_frame)
        inner_record = pd.concat(inner_predictions, ignore_index=True)
        inner_record.to_csv(outer_dir / 'inner_record_oof_predictions.csv', index=False)
        inner_patient = inner_record.groupby('base_id', as_index=False).agg(label=('label', 'first'), **{expert: (expert, 'mean') for expert in experts})
        ranking = select_expert_subset(inner_patient, experts)
        ranking.to_csv(outer_dir / 'inner_subset_ranking.csv', index=False)
        selected = ranking.iloc[0]['experts'].split('+')
        print(f"[outer {outer_number}] selected={selected}; inner_auc={ranking.iloc[0]['auc']:.4f}", flush=True)
        outer_record = base.iloc[outer_test_idx][['id', 'base_id', 'label']].copy()
        fixed_epochs = {}
        for expert in selected:
            fixed_epochs[expert] = max(1, int(round(float(np.median(best_epochs[expert])))))
            config = EXPERT_CONFIGS[expert]
            frame, tabular_cols, aux_col, fusion_kwargs = prepared[expert]
            pred = fit_outer_and_predict(expert, config, frame, tabular_cols, aux_col, fusion_kwargs, outer_train_idx, outer_test_idx, fixed_epochs[expert], outer_dir / 'final' / expert, stable_seed(args.seed, outer_number, 'outer_refit', expert), args.num_workers, device)
            score_map = pred.set_index('pid')['prob_pos']
            outer_record[expert] = outer_record['id'].map(score_map)
            if outer_record[expert].isna().any():
                raise ValueError(f'Missing outer predictions for {expert}')
        outer_record['nested_fusion'] = outer_record[selected].mean(axis=1)
        outer_record['outer_fold'] = outer_number
        outer_record.to_csv(outer_dir / 'outer_record_predictions.csv', index=False)
        outer_patient = outer_record.groupby('base_id', as_index=False).agg(label=('label', 'first'), nested_fusion=('nested_fusion', 'mean'), outer_fold=('outer_fold', 'first'))
        outer_patient.to_csv(completed, index=False)
        selection = {'outer_fold': outer_number, 'selected_experts': selected, 'inner_selected_auc': float(ranking.iloc[0]['auc']), 'inner_selected_brier': float(ranking.iloc[0]['brier']), 'fixed_epochs': fixed_epochs, 'n_outer_train_records': int(len(outer_train_idx)), 'n_outer_test_records': int(len(outer_test_idx)), 'n_outer_train_patients': int(base.iloc[outer_train_idx]['base_id'].nunique()), 'n_outer_test_patients': int(base.iloc[outer_test_idx]['base_id'].nunique())}
        selection_path.write_text(json.dumps(selection, indent=2), encoding='utf-8')
        selection_rows.append(selection)
        outer_patient_frames.append(outer_patient)
    if len(selected_outer) != args.outer_splits:
        print('Partial outer-fold run complete; pooled metrics deferred.', flush=True)
        return
    pooled = pd.concat(outer_patient_frames, ignore_index=True).sort_values('base_id')
    expected_patients = int(base['base_id'].nunique())
    if len(pooled) != expected_patients or pooled['base_id'].duplicated().any():
        raise ValueError(f'Invalid pooled patient predictions: n={len(pooled)}, expected={expected_patients}')
    pooled.to_csv(args.output / 'fully_nested_patient_predictions.csv', index=False)
    y = pooled['label'].to_numpy(dtype=int)
    score = pooled['nested_fusion'].to_numpy(dtype=float)
    result = {**binary_metrics(y, score), **bootstrap_metrics(y, score, args.n_boot, args.seed), 'outer_splits': args.outer_splits, 'inner_splits': args.inner_splits, 'selection_rule': 'Maximum inner patient-level OOF AUC; ties prefer fewer experts then lower Brier score.', 'outer_selections': selection_rows}
    (args.output / 'fully_nested_metrics.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    report = ['# Fully nested patient-grouped evidence fusion', '', f"- Pooled outer-test AUC: {result['auc']:.3f} ({result['auc_ci_low']:.3f}-{result['auc_ci_high']:.3f})", f"- Accuracy: {result['accuracy']:.3f}", f"- Sensitivity: {result['sensitivity']:.3f}", f"- Specificity: {result['specificity']:.3f}", f"- Brier score: {result['brier']:.3f}", '', 'Each outer-test probability was generated after expert training and subset selection confined to the corresponding outer-training patients.', '', '## Outer-fold selections', '', markdown_table(pd.DataFrame(selection_rows))]
    (args.output / 'fully_nested_report.md').write_text('\n'.join(report) + '\n', encoding='utf-8')
    print(json.dumps(result, indent=2), flush=True)
if __name__ == '__main__':
    main()
