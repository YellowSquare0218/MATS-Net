from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from run_nested_geometry_comparator import load_geometry
CLINICAL = ('g_Gender', 'g_Age', 'g_BMI', 'g_Height', 'g_Weight', 'src279_length', 'src279_CEA')

def ece(y: np.ndarray, score: np.ndarray, bins: int=10) -> float:
    edges = np.linspace(0.0, 1.0, bins + 1)
    value = 0.0
    for low, high in zip(edges[:-1], edges[1:]):
        mask = (score >= low) & (score < high if high < 1.0 else score <= high)
        if mask.any():
            value += mask.mean() * abs(y[mask].mean() - score[mask].mean())
    return float(value)

def model(c_value: float, l1_ratio: float, seed: int) -> Pipeline:
    return Pipeline([('impute', SimpleImputer(strategy='median', keep_empty_features=True)), ('scale', StandardScaler()), ('classifier', LogisticRegression(solver='saga', C=c_value, l1_ratio=l1_ratio, class_weight='balanced', max_iter=12000, random_state=seed))])

def metrics(y: np.ndarray, score: np.ndarray) -> dict[str, float | int]:
    prediction = (score >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, prediction, labels=[0, 1]).ravel()
    return {'n': int(len(y)), 'positive_n': int(y.sum()), 'negative_n': int((1 - y).sum()), 'auc': float(roc_auc_score(y, score)), 'accuracy': float(accuracy_score(y, prediction)), 'sensitivity': float(tp / (tp + fn)), 'specificity': float(tn / (tn + fp)), 'f1': float(f1_score(y, prediction, zero_division=0)), 'brier': float(brier_score_loss(y, score)), 'ece': ece(y, score), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

def bootstrap_auc(y: np.ndarray, score: np.ndarray, n_boot: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    values = []
    while len(values) < n_boot:
        sample = rng.integers(0, len(y), len(y))
        if np.unique(y[sample]).size == 2:
            values.append(roc_auc_score(y[sample], score[sample]))
    return tuple((float(value) for value in np.quantile(values, (0.025, 0.975))))

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--labels', type=Path, required=True)
    parser.add_argument('--patient-index', type=Path, required=True)
    parser.add_argument('--radiomics-cache', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=20260808)
    parser.add_argument('--outer-splits', type=int, default=5)
    parser.add_argument('--inner-splits', type=int, default=4)
    parser.add_argument('--n-boot', type=int, default=5000)
    args = parser.parse_args()
    labels = pd.read_csv(args.labels)
    labels['id'] = labels['id'].astype(str).str.replace('\\.0$', '', regex=True)
    labels['base_id'] = labels['base_id'].astype(str).str.replace('\\.0$', '', regex=True)
    labels['label'] = labels['label'].astype(int)
    geometry = load_geometry(args.labels, args.patient_index)
    geometry_columns = [column for column in geometry if column.startswith('geo_')]
    frame = labels[['id', 'base_id', 'state', 'label'] + list(CLINICAL)].copy()
    frame = frame.merge(geometry[['id'] + geometry_columns], on='id', how='left')
    radiomics = pd.read_csv(args.radiomics_cache)
    radiomics['id'] = radiomics['id'].astype(str).str.replace('\\.0$', '', regex=True)
    radiomics_columns = [column for column in radiomics if column != 'id']
    frame = frame.merge(radiomics, on='id', how='left')
    for column in list(CLINICAL) + geometry_columns + radiomics_columns:
        frame[column] = pd.to_numeric(frame[column], errors='coerce')
    feature_sets = {'clinical_only': list(CLINICAL), 'crop_based_pyradiomics': radiomics_columns, 'roi_annotation_geometry': geometry_columns, 'clinical_plus_roi_annotation_geometry': list(CLINICAL) + geometry_columns}
    candidates = [(c_value, l1_ratio) for c_value in (0.01, 0.03, 0.1, 0.3, 1.0, 3.0) for l1_ratio in (0.0, 0.25, 0.5, 0.75, 1.0)]
    y = frame['label'].to_numpy(int)
    groups = frame['base_id'].to_numpy()
    outer = StratifiedGroupKFold(n_splits=args.outer_splits, shuffle=True, random_state=args.seed)
    predictions: list[dict[str, object]] = []
    selections: list[dict[str, object]] = []
    for outer_fold, (train_index, test_index) in enumerate(outer.split(frame, y, groups), start=1):
        inner = StratifiedGroupKFold(n_splits=args.inner_splits, shuffle=True, random_state=args.seed + 1000 + outer_fold)
        for feature_set, columns in feature_sets.items():
            x = frame[columns].to_numpy(float)
            ranking = []
            for c_value, l1_ratio in candidates:
                inner_y: list[int] = []
                inner_score: list[float] = []
                for inner_train, inner_validation in inner.split(x[train_index], y[train_index], groups[train_index]):
                    fitted = model(c_value, l1_ratio, args.seed + outer_fold)
                    fitted.fit(x[train_index][inner_train], y[train_index][inner_train])
                    inner_y.extend(y[train_index][inner_validation])
                    inner_score.extend(fitted.predict_proba(x[train_index][inner_validation])[:, 1])
                ranking.append({'C': c_value, 'l1_ratio': l1_ratio, 'auc': roc_auc_score(inner_y, inner_score), 'brier': brier_score_loss(inner_y, inner_score)})
            best = pd.DataFrame(ranking).sort_values(['auc', 'brier', 'C', 'l1_ratio'], ascending=[False, True, True, True]).iloc[0]
            fitted = model(float(best.C), float(best.l1_ratio), args.seed + outer_fold)
            fitted.fit(x[train_index], y[train_index])
            scores = fitted.predict_proba(x[test_index])[:, 1]
            for local_index, row_index in enumerate(test_index):
                predictions.append({'base_id': frame.iloc[row_index]['base_id'], 'state': int(frame.iloc[row_index]['state']), 'label': int(y[row_index]), 'outer_fold': outer_fold, 'model': feature_set, 'score': float(scores[local_index])})
            selections.append({'outer_fold': outer_fold, 'model': feature_set, 'selected_C': float(best.C), 'selected_l1_ratio': float(best.l1_ratio), 'inner_auc': float(best.auc), 'inner_brier': float(best.brier), 'feature_n': int(len(columns))})
    prediction_frame = pd.DataFrame(predictions)
    summary = []
    for model_name, subset in prediction_frame.groupby('model', sort=False):
        subset = subset.sort_values('base_id')
        model_y = subset['label'].to_numpy(int)
        model_score = subset['score'].to_numpy(float)
        row = {'model': model_name, **metrics(model_y, model_score)}
        row['auc_ci_low'], row['auc_ci_high'] = bootstrap_auc(model_y, model_score, args.n_boot, args.seed)
        summary.append(row)
    args.output.mkdir(parents=True, exist_ok=True)
    prediction_frame.to_csv(args.output / 'nested_structured_predictions.csv', index=False)
    pd.DataFrame(selections).to_csv(args.output / 'nested_structured_hyperparameter_selections.csv', index=False)
    summary_frame = pd.DataFrame(summary).sort_values('auc', ascending=False)
    summary_frame.to_csv(args.output / 'nested_structured_metrics.csv', index=False)
    (args.output / 'nested_structured_metrics.json').write_text(json.dumps(summary_frame.to_dict(orient='records'), indent=2), encoding='utf-8')
    print(summary_frame.to_string(index=False))
if __name__ == '__main__':
    main()
