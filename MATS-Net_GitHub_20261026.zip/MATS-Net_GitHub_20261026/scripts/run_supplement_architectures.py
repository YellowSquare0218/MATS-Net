from _paths import project_path as _project_path
import argparse
import copy
import hashlib
import json
from pathlib import Path
import time
import monai
import numpy as np
import pandas as pd
import torch
import run_heef_262_fully_nested as nested
import supplement_architectures as arch

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project', type=Path, default=Path(_project_path('')))
    p.add_argument('--reference', type=Path, default=Path(_project_path('training_results/heef_262_fully_nested_20260913')))
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--mode', choices=['smoke', 'run'], required=True)
    p.add_argument('--seeds', default='42,137,2026')
    p.add_argument('--models', default='A1,A2,A3,B1,B2')
    p.add_argument('--seed', type=int, default=42)
    p.add_argument('--max-epochs', type=int, default=80)
    p.add_argument('--patience', type=int, default=20)
    p.add_argument('--workers', type=int, default=4)
    args = p.parse_args()
    torch.set_num_threads(8)
    assert torch.cuda.is_available()
    base, configs, prepared, _, _ = nested.load_inputs(args)
    models, data = ({}, {})
    models['A1'] = copy.deepcopy(configs['gmara_burden_w004'])
    models['A1'].update(fusion='causal_mara', tabular_source='none', use_geometry=False, aux_node_task=False)
    allowed = {'drop_rate', 'intervention_ce_weight', 'consistency_weight', 'feature_weight', 'distill_temperature'}
    kw = {k: v for k, v in prepared['gmara_burden_w004'][3].items() if k in allowed}
    models['A1']['fusion_kwargs'] = kw
    models['A1']['select_metric'] = configs['gmara_burden_w004']['select_metric']
    data['A1'] = (base.copy(), [], None, kw)
    for name, backbone in [('A2', 'resnet18_monai'), ('A3', 'swin_small_monai')]:
        models[name] = copy.deepcopy(configs['gmara_burden_w004'])
        models[name]['model_name'] = backbone
        data[name] = prepared['gmara_burden_w004']
    for name, backbone in [('B1', 'resnet18_monai'), ('B2', 'swin_small_monai')]:
        models[name] = copy.deepcopy(configs['single_T2W'])
        models[name]['model_name'] = backbone
        data[name] = prepared['single_T2W']
    selected = args.models.split(',')
    assert set(selected) <= set(models)
    seeds = list(map(int, args.seeds.split(',')))
    splits = json.loads((args.reference / 'split_manifest.json').read_text())
    for b in splits:
        for key in ['outer_train_ids', 'outer_test_ids', 'stopping_train_ids', 'stopping_validation_ids']:
            assert set(b[key]) <= set(base.id)
        assert not set(b['outer_test_ids']) & (set(b['stopping_train_ids']) | set(b['stopping_validation_ids']))
    spec = {'models': models, 'seeds': seeds, 'selected': selected, 'reference': str(args.reference), 'reference_split_hash': hashlib.sha256((args.reference / 'split_manifest.json').read_bytes()).hexdigest(), 'initialization': 'random; no pretrained weights', 'monai_version': monai.__version__, 'hyperparameter_candidates_per_model': 1, 'learning_rate': nested.core.LR, 'weight_decay': nested.core.WEIGHT_DECAY, 'max_epochs': args.max_epochs, 'patience': args.patience, 'batch_size': nested.core.BATCH_SIZE, 'selection': 'four training-only stopping fits; median epoch; same splits as HEEF', 'external_evaluation': 'not launched until matched student provenance and deployment locked', 'A1': 'image MARA path and perturbation losses retained; structured/state/node/supcon removed', 'A2_A3': 'same structured fields, fusion feature width=768, heads and auxiliary loss as auxiliary G-MARA', 'primary_seed': seeds[0], 'secondary_seeds': seeds[1:], 'new_models_not_added_to_HEEF': True}
    spec_path = args.output / 'supplement_protocol.json'
    if spec_path.exists():
        assert json.loads(spec_path.read_text()) == spec
    nested.write_json(spec_path, spec)
    protocol_hash = nested.digest(spec)
    lookup = {v: i for i, v in enumerate(base.id)}

    def indices(ids):
        return np.array([lookup[v] for v in ids], dtype=int)
    if args.mode == 'smoke':
        audit = {}
        for name in selected:
            b = splits[0]
            model, _ = arch.build_model(models[name], data[name][3], torch.device('cuda'))
            nparam = sum((v.numel() for v in model.parameters() if v.requires_grad))
            model.eval()
            inputs = [torch.zeros(1, 1, 16, 64, 64, device='cuda') for _ in models[name]['modalities']]

            def predict():
                if models[name].get('fusion'):
                    if data[name][1]:
                        return model(inputs, tabular=torch.zeros(1, len(data[name][1]), device='cuda'))
                    return model(inputs)
                return model(inputs[0])
            with torch.no_grad():
                for _ in range(5):
                    predict()
                torch.cuda.synchronize()
                t = time.perf_counter()
                for _ in range(20):
                    logits = predict()
                torch.cuda.synchronize()
                ms = (time.perf_counter() - t) * 1000 / 20
                assert logits.shape == (1, 2) and torch.isfinite(logits).all()
            del model
            torch.cuda.empty_cache()
            result, _ = nested.fit_deep(args, name, models[name], data[name], indices(b['stopping_train_ids']), indices(b['stopping_validation_ids']), args.output / 'smoke' / name, 1234, protocol_hash, epochs=1, smoke=True, model_factory=arch.build_model)
            audit[name] = {'trainable_parameters': nparam, 'forward_ms_batch1_gpu_only': ms, **result}
        nested.write_json(args.output / 'smoke_passed.json', audit)
        return
    assert (args.output / 'smoke_passed.json').exists(), 'Run smoke in this output first'
    import fcntl
    lock = (args.output / 'run.lock').open('w')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    for seed in seeds:
        for name in selected:
            rows = []
            for number in range(1, 6):
                blocks = [b for b in splits if b['outer_fold'] == number]
                folder = args.output / f'seed_{seed}' / name / f'outer_{number}'
                epochs = []
                for b in blocks:
                    inner = b['inner_fold']
                    result, _ = nested.fit_deep(args, name, models[name], data[name], indices(b['stopping_train_ids']), indices(b['stopping_validation_ids']), folder / f'stopping_{inner}', nested.training.stable_seed(seed, number, inner, name, 'stop'), protocol_hash, model_factory=arch.build_model)
                    epochs.append(result['best_epoch'])
                n_epoch = max(1, int(round(np.median(epochs))))
                nested.write_json(folder / 'epoch_selection.json', {'stopping_epochs': epochs, 'refit_epoch': n_epoch})
                b = blocks[0]
                _, pred = nested.fit_deep(args, name, models[name], data[name], indices(b['outer_train_ids']), indices(b['outer_test_ids']), folder / 'refit', nested.training.stable_seed(seed, number, name, 'outer'), protocol_hash, epochs=n_epoch, model_factory=arch.build_model)
                pred['outer_fold'], pred['seed'], pred['model'] = (number, seed, name)
                pred['checkpoint'] = str(folder / 'refit/model.pt')
                rows.append(pred)
            pred = pd.concat(rows, ignore_index=True)
            assert len(pred) == 262 and pred.pid.is_unique
            out = args.output / f'seed_{seed}' / name
            pred.to_csv(out / 'predictions_262.csv', index=False)
            metrics = nested.training.binary_metrics(pred.label.to_numpy(), pred.prob_pos.to_numpy())
            metrics['balanced_accuracy'] = (metrics['sensitivity'] + metrics['specificity']) / 2
            nested.write_json(out / 'metrics.json', metrics)
            print(f"COMPLETE seed={seed} model={name} auc={metrics['auc']:.6f}", flush=True)
    nested.write_json(args.output / 'training_complete.json', {'models': selected, 'seeds': seeds, 'external_test_run': False})
if __name__ == '__main__':
    main()
