from _paths import project_path as _project_path
import os, sys, json, time, argparse, warnings, hashlib, re, random
import inspect
from pathlib import Path
from datetime import datetime
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader, Subset
try:
    from sklearn.model_selection import StratifiedGroupKFold
except ImportError:
    StratifiedGroupKFold = None
from sklearn.model_selection import StratifiedKFold
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score, roc_auc_score, confusion_matrix, roc_curve
import nibabel as nib
from tqdm import tqdm
from collections import defaultdict
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import get_model, get_fusion, count_params
warnings.filterwarnings('ignore')
ROI_DIR = _project_path('dataset/roi_v4')
OUTPUT_BASE = _project_path('training_results')
BATCH_SIZE = 32
NUM_EPOCHS = 80
LR = 0.0003
WEIGHT_DECAY = 0.0001
FOLDS = 5
NUM_WORKERS = 4
EARLY_STOP_PATIENCE = 20
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']
CLINICAL_FEATURE_COLS = ['g_Gender', 'g_Age', 'g_BMI', 'g_Height', 'g_Weight', 'src279_length', 'src279_CEA']
os.makedirs(OUTPUT_BASE, exist_ok=True)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def resolve_project_path(path):
    if not path:
        return path
    if os.path.isabs(path):
        return path
    return os.path.join(PROJECT_ROOT, path)

def normalize_id(value):
    return re.sub('\\.0$', '', str(value)).strip()

def base_patient_id(value):
    return re.sub('_2$', '', normalize_id(value))

class MRIDataset(Dataset):

    def __init__(self, root_dir, index_df, modalities=None, augment=False, task=2, tabular_col=None, teacher_col=None, aux_node_col=None, zero_images=False):
        self.root_dir = root_dir
        self.df = index_df.reset_index(drop=True)
        self.modalities = modalities or MODALITIES
        self.augment = augment
        self.task = task
        self.tabular_col = tabular_col
        self.has_tabular = tabular_col is not None and tabular_col in self.df.columns
        self.teacher_col = teacher_col
        self.has_teacher = teacher_col is not None and teacher_col in self.df.columns
        self.aux_node_col = aux_node_col
        self.has_aux_node = aux_node_col is not None and aux_node_col in self.df.columns
        self.zero_images = bool(zero_images)

    def __len__(self):
        return len(self.df)

    def _load_volume(self, pid, mod):
        if self.zero_images:
            return np.zeros((16, 64, 64), dtype=np.float32)
        fp = os.path.join(self.root_dir, str(pid), f'{mod}.nii.gz')
        img = nib.load(fp)
        data = img.get_fdata().astype(np.float32)
        data = np.transpose(data, (2, 0, 1))
        vmin, vmax = (data.min(), data.max())
        if vmax > vmin:
            data = (data - vmin) / (vmax - vmin)
        return data

    def _augment(self, vol, heavy=False):
        if np.random.rand() < 0.5:
            vol = np.flip(vol, axis=1).copy()
        if np.random.rand() < 0.5:
            vol = np.flip(vol, axis=2).copy()
        if heavy and np.random.rand() < 0.3:
            vol = np.flip(vol, axis=0).copy()
        if heavy and np.random.rand() < 0.4:
            try:
                from scipy.ndimage import rotate
                angle = np.random.uniform(-8, 8)
                axes = np.random.choice([(0, 1), (0, 2), (1, 2)])
                vol = rotate(vol, angle, axes=axes, reshape=False, order=1, mode='nearest')
            except:
                pass
        if np.random.rand() < 0.3:
            try:
                from scipy.ndimage import gaussian_filter
                alpha = np.random.uniform(2, 5)
                sigma = np.random.uniform(1, 3)
                dx = gaussian_filter(np.random.randn(*vol.shape) * alpha, sigma)
                dy = gaussian_filter(np.random.randn(*vol.shape) * alpha, sigma)
                dz = gaussian_filter(np.random.randn(*vol.shape) * alpha, sigma)
                x, y, z = np.meshgrid(np.arange(vol.shape[2]), np.arange(vol.shape[1]), np.arange(vol.shape[0]), indexing='ij')
                indices = (np.reshape(z + dz, (-1, 1)), np.reshape(y + dy, (-1, 1)), np.reshape(x + dx, (-1, 1)))
                from scipy.ndimage import map_coordinates
                vol = map_coordinates(vol, indices, order=1, mode='nearest').reshape(vol.shape)
            except:
                pass
        if np.random.rand() < 0.3:
            noise = np.random.normal(0, 0.02, vol.shape).astype(np.float32)
            vol = vol + noise
        if np.random.rand() < 0.3:
            scale = np.random.uniform(0.9, 1.1)
            vol = vol * scale
        if np.random.rand() < 0.2:
            shift = np.random.uniform(-0.05, 0.05)
            vol = vol + shift
        return np.clip(vol, 0, 1)

    def _augment_modalities(self, volumes):
        transformed = [np.asarray(volume, dtype=np.float32) for volume in volumes]
        for axis in (1, 2):
            if np.random.rand() < 0.5:
                transformed = [np.flip(volume, axis=axis).copy() for volume in transformed]
        if np.random.rand() < 0.3:
            try:
                from scipy.ndimage import gaussian_filter, map_coordinates
                shape = transformed[0].shape
                alpha = np.random.uniform(2, 5)
                sigma = np.random.uniform(1, 3)
                displacement = [gaussian_filter(np.random.randn(*shape), sigma) * alpha for _ in range(3)]
                grid = np.meshgrid(np.arange(shape[0]), np.arange(shape[1]), np.arange(shape[2]), indexing='ij')
                coordinates = tuple((grid[axis] + displacement[axis] for axis in range(3)))
                transformed = [map_coordinates(volume, coordinates, order=1, mode='nearest').astype(np.float32) for volume in transformed]
            except Exception:
                pass
        augmented = []
        for volume in transformed:
            if np.random.rand() < 0.3:
                volume = volume + np.random.normal(0, 0.02, volume.shape).astype(np.float32)
            if np.random.rand() < 0.3:
                volume = volume * np.random.uniform(0.9, 1.1)
            if np.random.rand() < 0.2:
                volume = volume + np.random.uniform(-0.05, 0.05)
            augmented.append(np.clip(volume, 0, 1).astype(np.float32))
        return augmented

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        pid = str(row['id'])
        volumes = [self._load_volume(pid, mod) for mod in self.modalities]
        if self.augment:
            volumes = self._augment_modalities(volumes)
        volumes = [torch.from_numpy(vol).unsqueeze(0) for vol in volumes]
        if self.task == 2:
            label = int(row['label'])
        elif self.task == 12:
            label = int(row['state']) - 1
        else:
            label = int(row['state']) - 1
        item = {'pid': pid, 'volumes': volumes, 'label': label, 'state': int(row['state'])}
        if self.has_tabular:
            item['tabular'] = torch.tensor(row[self.tabular_col], dtype=torch.float32)
        if self.has_teacher:
            item['teacher_prob'] = torch.tensor(float(row[self.teacher_col]), dtype=torch.float32)
        if self.has_aux_node:
            node_value = row[self.aux_node_col]
            node_valid = int(pd.notna(node_value) and int(node_value) >= 0)
            node_label = int(node_value) if node_valid else -1
            item['aux_node'] = node_label
            item['aux_node_mask'] = node_valid
        return item

def collate_fn(batch):
    n_mods = len(batch[0]['volumes'])
    volumes = []
    for i in range(n_mods):
        vols = [item['volumes'][i] for item in batch]
        volumes.append(torch.stack(vols, dim=0))
    out = {'pid': [item['pid'] for item in batch], 'volumes': volumes, 'label': torch.tensor([item['label'] for item in batch], dtype=torch.long), 'state': torch.tensor([item['state'] for item in batch], dtype=torch.long)}
    if 'tabular' in batch[0]:
        out['tabular'] = torch.stack([item['tabular'] for item in batch], dim=0)
    if 'teacher_prob' in batch[0]:
        out['teacher_prob'] = torch.stack([item['teacher_prob'] for item in batch], dim=0)
    if 'aux_node' in batch[0]:
        out['aux_node'] = torch.tensor([item['aux_node'] for item in batch], dtype=torch.long)
        out['aux_node_mask'] = torch.tensor([item['aux_node_mask'] for item in batch], dtype=torch.bool)
    return out

def _parse_range(value):
    if pd.isna(value):
        return (np.nan, np.nan, np.nan)
    match = re.match('(-?\\d+)_(-?\\d+)$', str(value))
    if match:
        start, end = map(float, match.groups())
        return (start, end, end - start + 1.0)
    try:
        val = float(value)
        return (val, val, 0.0)
    except (TypeError, ValueError):
        return (np.nan, np.nan, np.nan)

def add_roi_geometry_features(index_df):
    meta_path = os.path.join(os.path.dirname(ROI_DIR), 'patient_index.csv')
    if not os.path.exists(meta_path):
        meta_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'dataset', 'patient_index.csv')
    if not os.path.exists(meta_path):
        raise FileNotFoundError(f'ROI geometry metadata not found: {meta_path}')
    base = index_df.copy()
    base['id'] = base['id'].map(normalize_id)
    base['_base_id'] = base['id'].map(base_patient_id)
    meta = pd.read_csv(meta_path)
    meta['id'] = meta['id'].map(normalize_id)
    meta['_base_id'] = meta['id'].map(base_patient_id)
    meta = meta.drop_duplicates(['_base_id', 'state'])
    merged = base.merge(meta.drop(columns=['id']), on=['_base_id', 'state'], how='left')
    geometry = {}
    for mod in MODALITIES:
        geometry[f'geo_{mod}_max'] = pd.to_numeric(merged.get(f'{mod}_max'), errors='coerce')
        for axis in ['x', 'y', 'z']:
            parsed = [_parse_range(v) for v in merged.get(f'{mod}_{axis}')]
            geometry[f'geo_{mod}_{axis}_start'] = [v[0] for v in parsed]
            geometry[f'geo_{mod}_{axis}_end'] = [v[1] for v in parsed]
            geometry[f'geo_{mod}_{axis}_len'] = [v[2] for v in parsed]
        geometry[f'geo_{mod}_xy_area'] = np.asarray(geometry[f'geo_{mod}_x_len']) * np.asarray(geometry[f'geo_{mod}_y_len'])
        geometry[f'geo_{mod}_vol_approx'] = np.asarray(geometry[f'geo_{mod}_xy_area']) * np.asarray(geometry[f'geo_{mod}_z_len'])
    geometry_df = pd.DataFrame(geometry)
    geometry_cols = list(geometry_df.columns)
    out = pd.concat([base.reset_index(drop=True), geometry_df], axis=1)
    return (out, geometry_cols)

def add_clinical_features(index_df, clinical_path=None):
    base = index_df.copy()
    base['id'] = base['id'].map(normalize_id)
    if clinical_path and os.path.exists(clinical_path):
        clinical = pd.read_csv(clinical_path)
        clinical['id'] = clinical['id'].map(normalize_id)
        keep = ['id'] + [c for c in CLINICAL_FEATURE_COLS if c in clinical.columns]
        missing = [c for c in CLINICAL_FEATURE_COLS if c not in base.columns]
        if missing:
            base = base.merge(clinical[keep].drop_duplicates('id'), on='id', how='left', suffixes=('', '_clin'))
            for col in CLINICAL_FEATURE_COLS:
                alt = f'{col}_clin'
                if alt in base.columns:
                    if col in base.columns:
                        base[col] = base[col].combine_first(base[alt])
                        base = base.drop(columns=[alt])
                    else:
                        base = base.rename(columns={alt: col})
    clinical = {}
    for col in CLINICAL_FEATURE_COLS:
        if col in base.columns:
            clinical[f'clin_{col}'] = pd.to_numeric(base[col], errors='coerce')
    if not clinical:
        raise ValueError('No clinical feature columns were found for tabular_source=clinical/clinical_geometry.')
    clinical_df = pd.DataFrame(clinical)
    clinical_cols = list(clinical_df.columns)
    out = pd.concat([base.reset_index(drop=True), clinical_df], axis=1)
    return (out, clinical_cols)

def add_aux_node_labels(index_df, clinical_path=None, source='g_N'):
    base = index_df.copy()
    base['id'] = base['id'].map(normalize_id)
    source = source or 'g_N'
    source_col = 'src279_N' if source == 'src279_N_burden3' else source
    if source_col not in base.columns and clinical_path and os.path.exists(clinical_path):
        clinical = pd.read_csv(clinical_path)
        clinical['id'] = clinical['id'].map(normalize_id)
        if source_col in clinical.columns:
            base = base.merge(clinical[['id', source_col]].drop_duplicates('id'), on='id', how='left', suffixes=('', '_aux'))
            aux_col = f'{source_col}_aux'
            if aux_col in base.columns:
                base[source_col] = base[aux_col]
                base = base.drop(columns=[aux_col])
    if source_col not in base.columns:
        raise ValueError(f'Auxiliary node source column not found: {source}')
    raw = pd.to_numeric(base[source_col], errors='coerce')
    target = pd.Series(-1, index=base.index, dtype='int64')
    valid = raw.notna()
    if source == 'g_N':
        valid = valid & raw.isin([0, 1])
        target.loc[valid] = raw.loc[valid].astype(int)
    elif source == 'src279_N':
        target.loc[valid] = (raw.loc[valid] > 0).astype(int)
    elif source == 'src279_N_burden3':
        target.loc[valid & raw.eq(0)] = 0
        target.loc[valid & raw.isin([1, 2])] = 1
        target.loc[valid & raw.ge(3)] = 2
    else:
        target.loc[valid] = (raw.loc[valid] > 0).astype(int)
    out = base.reset_index(drop=True).copy()
    out['aux_node_label'] = target.reset_index(drop=True)
    class_counts = out.loc[out['aux_node_label'] >= 0, 'aux_node_label'].value_counts().sort_index()
    stats = {'source': source, 'source_col': source_col, 'valid': int((out['aux_node_label'] >= 0).sum()), 'missing': int((out['aux_node_label'] < 0).sum()), 'classes': int(class_counts.size), 'class_counts': {str(int(k)): int(v) for k, v in class_counts.items()}, 'positive': int((out['aux_node_label'] == 1).sum()), 'negative': int((out['aux_node_label'] == 0).sum())}
    return (out, 'aux_node_label', stats)

def add_teacher_probabilities(index_df, teacher_path):
    if not teacher_path:
        return (index_df, None)
    if not os.path.exists(teacher_path):
        raise FileNotFoundError(f'Teacher OOF file not found: {teacher_path}')
    teacher = pd.read_csv(teacher_path)
    if 'pid' not in teacher.columns:
        raise ValueError(f'Teacher file must contain pid column: {teacher_path}')
    teacher['pid'] = teacher['pid'].astype(str)
    if 'teacher_prob' not in teacher.columns:
        required = ['mara', 'early', 'cif', 'cmara', 'gmara_acc', 'geo_lr_c0_1']
        missing = [c for c in required if c not in teacher.columns]
        if missing:
            score_col = None
            for col in ['prob_pos', 'prob_1', 'score']:
                if col in teacher.columns:
                    score_col = col
                    break
            if score_col is None:
                raise ValueError(f'Teacher file lacks teacher_prob, required evidence columns {missing}, and prob_pos/prob_1/score fallback.')
            teacher['teacher_prob'] = pd.to_numeric(teacher[score_col], errors='coerce')
        else:
            deep_core = 0.3 * pd.to_numeric(teacher['mara'], errors='coerce') + 0.2 * pd.to_numeric(teacher['early'], errors='coerce') + 0.2 * pd.to_numeric(teacher['cif'], errors='coerce') + 0.15 * pd.to_numeric(teacher['cmara'], errors='coerce') + 0.15 * pd.to_numeric(teacher['gmara_acc'], errors='coerce')
            teacher['teacher_prob'] = 0.75 * deep_core + 0.25 * pd.to_numeric(teacher['geo_lr_c0_1'], errors='coerce')
    base = index_df.copy()
    base['id'] = base['id'].astype(str)
    merged = base.merge(teacher[['pid', 'teacher_prob']], left_on='id', right_on='pid', how='left')
    missing_count = int(merged['teacher_prob'].isna().sum())
    if missing_count:
        raise ValueError(f'Teacher probabilities missing for {missing_count} patients')
    merged['teacher_prob'] = merged['teacher_prob'].clip(0.0001, 1 - 0.0001).astype(np.float32)
    merged = merged.drop(columns=['pid'])
    return (merged, 'teacher_prob')

def distillation_loss(logits, teacher_prob, temperature=2.0):
    if logits.shape[1] != 2:
        raise ValueError('Evidence distillation currently supports binary logits only.')
    teacher_prob = teacher_prob.to(logits.device).float().clamp(0.0001, 1 - 0.0001)
    target = torch.stack([1.0 - teacher_prob, teacher_prob], dim=1)
    temperature = max(float(temperature), 1e-06)
    return F.kl_div(F.log_softmax(logits / temperature, dim=1), target, reduction='batchmean') * temperature ** 2

def train_epoch(model, loader, optimizer, criterion, device, fusion=False, causal_l1=False, causal_enabled=True, distill_weight=0.0, distill_temperature=2.0):
    model.train()
    total_loss = 0
    all_preds, all_labels = ([], [])
    has_causal_loss = hasattr(model, 'causal_loss')
    has_causal_drop = hasattr(model, 'sample_drop_mask') and hasattr(model, 'consis_weight')
    has_contrastive = hasattr(model, 'contrastive_loss') and hasattr(model, 'lambda_contrast')
    has_auxiliary = hasattr(model, 'use_auxiliary') and model.use_auxiliary
    for batch in loader:
        if fusion:
            vols = [v.to(device) for v in batch['volumes']]
            labels = batch['label'].to(device)
            if has_causal_loss and causal_enabled:
                causal_kwargs = {}
                try:
                    causal_params = inspect.signature(model.causal_loss).parameters
                    if 'states' in causal_params:
                        causal_kwargs['states'] = batch['state'].to(device)
                    if 'tabular' in causal_params and 'tabular' in batch:
                        causal_kwargs['tabular'] = batch['tabular'].to(device)
                    if 'node_labels' in causal_params and 'aux_node' in batch:
                        causal_kwargs['node_labels'] = batch['aux_node'].to(device)
                    if 'node_mask' in causal_params and 'aux_node_mask' in batch:
                        causal_kwargs['node_mask'] = batch['aux_node_mask'].to(device)
                except (TypeError, ValueError):
                    pass
                logits, loss, _ = model.causal_loss(vols, labels, criterion, **causal_kwargs)
            elif has_causal_loss:
                if 'tabular' in batch and 'tabular' in inspect.signature(model.forward).parameters:
                    logits = model(vols, tabular=batch['tabular'].to(device))
                else:
                    logits = model(vols)
                loss = criterion(logits, labels)
            elif has_causal_drop:
                B = vols[0].shape[0]
                mask = model.sample_drop_mask(B, device)
                logits = model(vols, mod_drop_mask=mask)
                loss_ce = criterion(logits, labels)
                with torch.no_grad():
                    logits_clean = model(vols, mod_drop_mask=None)
                loss_consis = F.kl_div(F.log_softmax(logits, dim=-1), F.softmax(logits_clean, dim=-1), reduction='batchmean')
                loss = loss_ce + model.consis_weight * loss_consis
            elif has_contrastive:
                logits, proj_feats = model(vols, return_proj=True)
                loss_ce = criterion(logits, labels)
                loss_contrast = model.contrastive_loss(proj_feats)
                loss = loss_ce + model.lambda_contrast * loss_contrast
            elif has_auxiliary:
                logits, aux_logits = model(vols)
                loss = criterion(logits, labels)
                aux_weight = 0.3
                for aux_logit in aux_logits:
                    loss = loss + aux_weight * criterion(aux_logit, labels)
            else:
                if 'tabular' in batch and 'tabular' in inspect.signature(model.forward).parameters:
                    logits = model(vols, tabular=batch['tabular'].to(device))
                else:
                    logits = model(vols)
                loss = criterion(logits, labels)
        else:
            vols = batch['volumes']
            if len(vols) == 1:
                x = vols[0].to(device)
            else:
                x = torch.cat(vols, dim=1).to(device)
            logits = model(x)
            labels = batch['label'].to(device)
            loss = criterion(logits, labels)
        if causal_l1 and hasattr(model, 'get_l1_loss'):
            loss = loss + model.get_l1_loss()
        if distill_weight and 'teacher_prob' in batch:
            loss = loss + float(distill_weight) * distillation_loss(logits, batch['teacher_prob'], temperature=distill_temperature)
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        total_loss += loss.item()
        preds = logits.argmax(dim=1).cpu().numpy()
        all_preds.extend(preds)
        all_labels.extend(labels.cpu().numpy())
    acc = accuracy_score(all_labels, all_preds)
    return (total_loss / len(loader), acc)

@torch.no_grad()
def validate(model, loader, criterion, device, num_classes, fusion=False, tta=False):
    model.eval()
    total_loss = 0
    all_probs_list, all_labels, all_pids = ([], [], [])
    all_node_probs_list, all_node_labels, all_node_masks = ([], [], [])
    tta_configs = [(False, False)] if not tta else [(False, False), (True, False), (False, True), (True, True)]
    for batch in loader:
        batch_probs_sum = None
        batch_node_probs_sum = None
        for flip_h, flip_w in tta_configs:
            node_logits = None
            if fusion:
                vols = [v.to(device) for v in batch['volumes']]
                if flip_h or flip_w:
                    vols = [torch.flip(v, dims=([3] if flip_h else []) + ([4] if flip_w else [])) for v in vols]
                forward_params = inspect.signature(model.forward).parameters
                wants_node = 'aux_node' in batch and hasattr(model, 'node_head') and (getattr(model, 'node_head') is not None) and ('return_features' in forward_params)
                forward_kwargs = {}
                if 'tabular' in batch and 'tabular' in forward_params:
                    forward_kwargs['tabular'] = batch['tabular'].to(device)
                if wants_node:
                    forward_kwargs['return_features'] = True
                result = model(vols, **forward_kwargs)
                if wants_node:
                    logits, feats = result[:2]
                    node_logits = model.node_head(feats)
                elif isinstance(result, tuple):
                    logits = result[0]
                else:
                    logits = result
            else:
                vols = batch['volumes']
                if len(vols) == 1:
                    x = vols[0].to(device)
                else:
                    x = torch.cat(vols, dim=1).to(device)
                if flip_h or flip_w:
                    x = torch.flip(x, dims=([3] if flip_h else []) + ([4] if flip_w else []))
                logits = model(x)
            probs = F.softmax(logits, dim=1)
            if batch_probs_sum is None:
                batch_probs_sum = probs
            else:
                batch_probs_sum = batch_probs_sum + probs
            if node_logits is not None:
                node_probs = F.softmax(node_logits, dim=1)
                if batch_node_probs_sum is None:
                    batch_node_probs_sum = node_probs
                else:
                    batch_node_probs_sum = batch_node_probs_sum + node_probs
        batch_probs = (batch_probs_sum / len(tta_configs)).cpu().numpy()
        all_probs_list.append(batch_probs)
        if batch_node_probs_sum is not None:
            batch_node_probs = (batch_node_probs_sum / len(tta_configs)).cpu().numpy()
            all_node_probs_list.append(batch_node_probs)
            all_node_labels.extend(batch['aux_node'].cpu().numpy().tolist())
            all_node_masks.extend(batch['aux_node_mask'].cpu().numpy().astype(bool).tolist())
        labels = batch['label'].to(device)
        all_labels.extend(labels.cpu().numpy())
        all_pids.extend(batch['pid'])
    all_probs = np.concatenate(all_probs_list, axis=0)
    all_labels = np.array(all_labels)
    all_preds = all_probs.argmax(axis=1)
    node_probs_all = np.concatenate(all_node_probs_list, axis=0) if all_node_probs_list else None
    node_labels_all = np.array(all_node_labels, dtype=int) if all_node_labels else None
    node_masks_all = np.array(all_node_masks, dtype=bool) if all_node_masks else None
    metrics = {'loss': 0, 'acc': accuracy_score(all_labels, all_preds)}
    if num_classes == 2:
        try:
            metrics['auc'] = roc_auc_score(all_labels, all_probs[:, 1])
        except ValueError:
            metrics['auc'] = 0
        metrics['f1'] = f1_score(all_labels, all_preds)
        metrics['precision'] = precision_score(all_labels, all_preds, zero_division=0)
        metrics['recall'] = recall_score(all_labels, all_preds, zero_division=0)
        cm = confusion_matrix(all_labels, all_preds)
        tn, fp, fn, tp = cm.ravel() if cm.size == 4 else (0, 0, 0, 0)
        metrics['sensitivity'] = tp / (tp + fn) if tp + fn > 0 else 0
        metrics['specificity'] = tn / (tn + fp) if tn + fp > 0 else 0
    else:
        try:
            metrics['auc'] = roc_auc_score(all_labels, all_probs, multi_class='ovr', average='macro')
        except:
            metrics['auc'] = 0
        metrics['f1'] = f1_score(all_labels, all_preds, average='macro', zero_division=0)
        metrics['precision'] = precision_score(all_labels, all_preds, average='macro', zero_division=0)
        metrics['recall'] = recall_score(all_labels, all_preds, average='macro', zero_division=0)
        cm = confusion_matrix(all_labels, all_preds, labels=list(range(num_classes)))
        for c in range(num_classes):
            tp_c = cm[c, c]
            fn_c = cm[c, :].sum() - tp_c
            metrics[f'sen_class{c + 1}'] = tp_c / (tp_c + fn_c) if tp_c + fn_c > 0 else 0
    if node_probs_all is not None and node_labels_all is not None and (node_masks_all is not None):
        valid = node_masks_all & (node_labels_all >= 0)
        metrics['node_n'] = int(valid.sum())
        if valid.any():
            node_labels_valid = node_labels_all[valid]
            node_probs_valid = node_probs_all[valid]
            node_preds = node_probs_valid.argmax(axis=1)
            node_classes = node_probs_valid.shape[1]
            metrics['node_acc'] = accuracy_score(node_labels_valid, node_preds)
            if node_classes == 2:
                metrics['node_f1'] = f1_score(node_labels_valid, node_preds, zero_division=0)
                try:
                    metrics['node_auc'] = roc_auc_score(node_labels_valid, node_probs_valid[:, 1])
                except ValueError:
                    metrics['node_auc'] = 0
            else:
                metrics['node_f1'] = f1_score(node_labels_valid, node_preds, average='macro', zero_division=0)
                try:
                    metrics['node_auc'] = roc_auc_score(node_labels_valid, node_probs_valid, labels=list(range(node_classes)), multi_class='ovr', average='macro')
                except ValueError:
                    metrics['node_auc'] = 0
        else:
            metrics['node_acc'] = 0
            metrics['node_f1'] = 0
            metrics['node_auc'] = 0
    metrics['cm'] = cm.tolist()
    predictions = []
    for i, (p, l, pr) in enumerate(zip(all_pids, all_labels, all_preds)):
        row = {'pid': p, 'label': int(l), 'pred': int(pr), 'prob': float(all_probs[i, pr])}
        for c in range(num_classes):
            row[f'prob_{c}'] = float(all_probs[i, c])
        if num_classes == 2:
            row['prob_pos'] = float(all_probs[i, 1])
        if node_probs_all is not None and i < len(node_probs_all):
            row['aux_node_valid'] = bool(node_masks_all[i])
            row['aux_node_label'] = int(node_labels_all[i])
            row['aux_node_pred'] = int(node_probs_all[i].argmax())
            for c in range(node_probs_all.shape[1]):
                row[f'aux_node_prob_{c}'] = float(node_probs_all[i, c])
            if node_probs_all.shape[1] == 2:
                row['aux_node_prob_pos'] = float(node_probs_all[i, 1])
        predictions.append(row)
    metrics['predictions'] = predictions
    return metrics

def get_selection_metric(task, requested=None):
    if requested:
        return requested
    return 'auc' if task in (2, 12) else 'f1'

def get_num_classes(task):
    return 2 if task in (2, 12) else 3

def get_task_label(task):
    if task == 12:
        return 'stage12'
    return f'{task}cls'

def metric_is_better(value, best_value):
    if best_value is None:
        return True
    return value > best_value

def clone_state_dict(model):
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}

def set_random_seed(seed):
    if seed is None:
        return
    seed = int(seed)
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

def make_cv_splits(index, labels_for_split, split_strategy, seed):
    if split_strategy == 'stratified':
        splitter = StratifiedKFold(n_splits=FOLDS, shuffle=True, random_state=seed)
        return (list(splitter.split(index, labels_for_split)), None)
    groups = index['id'].map(base_patient_id).to_numpy()
    if StratifiedGroupKFold is None:
        raise ImportError('StratifiedGroupKFold is unavailable; upgrade scikit-learn or use --split_strategy stratified for legacy runs.')
    splitter = StratifiedGroupKFold(n_splits=FOLDS, shuffle=True, random_state=seed)
    splits = list(splitter.split(index, labels_for_split, groups=groups))
    return (splits, groups)

def run_experiment(config):
    model_name = config['model_name']
    modal = config['modal']
    task = config['task']
    fusion = config.get('fusion', None)
    fold_seed = config.get('fold_seed', 42)
    train_seed = config.get('train_seed')
    output_dir = config['output_dir']
    roi_dir = resolve_project_path(config.get('roi_dir') or ROI_DIR)
    select_metric = get_selection_metric(task, config.get('select_metric'))
    fusion_kwargs = config.get('fusion_kwargs') or {}
    causal_warmup_epochs = int(config.get('causal_warmup_epochs') or 0)
    use_geometry = bool(config.get('use_geometry'))
    teacher_oof = config.get('teacher_oof')
    distill_weight = float(config.get('distill_weight') or 0.0)
    distill_temperature = float(config.get('distill_temperature') or 2.0)
    split_strategy = config.get('split_strategy') or 'group'
    aux_node_task = bool(config.get('aux_node_task'))
    aux_node_source = config.get('aux_node_source') or 'g_N'
    aux_node_weight = float(config.get('aux_node_weight') or 0.0)
    index_csv = resolve_project_path(config.get('index_csv') or os.path.join(ROI_DIR, 'index.csv'))
    clinical_csv = resolve_project_path(config.get('clinical_csv') or os.path.join(ROI_DIR, 'labels_clinical_expanded_262.csv'))
    tabular_source = config.get('tabular_source') or 'auto'
    tabular_mask = config.get('tabular_mask') or 'all'
    zero_images = bool(config.get('zero_images'))
    if tabular_source == 'auto':
        tabular_source = 'geometry' if use_geometry else 'none'
    if aux_node_task and aux_node_weight > 0:
        fusion_kwargs = dict(fusion_kwargs)
        fusion_kwargs['aux_node_weight'] = aux_node_weight
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(output_dir, exist_ok=True)
    with open(os.path.join(output_dir, 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(config, f, indent=2, default=str)
    index = pd.read_csv(index_csv)
    index['id'] = index['id'].map(normalize_id)
    if task == 12:
        index = index[index['state'].isin([1, 2])].reset_index(drop=True).copy()
    aux_node_col = None
    aux_node_stats = None
    if aux_node_task:
        index, aux_node_col, aux_node_stats = add_aux_node_labels(index, clinical_path=clinical_csv, source=aux_node_source)
        if aux_node_weight > 0 and aux_node_stats:
            fusion_kwargs = dict(fusion_kwargs)
            fusion_kwargs['aux_node_classes'] = max(2, int(aux_node_stats.get('classes') or 2))
    geometry_cols = []
    clinical_cols = []
    if tabular_source in ('geometry', 'clinical_geometry'):
        index, geometry_cols = add_roi_geometry_features(index)
    if tabular_source in ('clinical', 'clinical_geometry'):
        index, clinical_cols = add_clinical_features(index, clinical_csv)
    tabular_cols = geometry_cols + clinical_cols
    if tabular_cols:
        fusion_kwargs = dict(fusion_kwargs)
        fusion_kwargs['tab_dim'] = len(tabular_cols)
    teacher_col = None
    if teacher_oof:
        if task != 2:
            raise ValueError('Evidence distillation is currently implemented for binary task=2 only.')
        index, teacher_col = add_teacher_probabilities(index, teacher_oof)
    if modal == 'all':
        modalities = MODALITIES
        n_chans = 4
    else:
        modalities = [modal]
        n_chans = 1
    num_classes = get_num_classes(task)
    use_fusion = fusion is not None and modal == 'all' and (fusion != 'early')
    if fusion in ('adaptive', 'cgcmr', 'mara', 'marav2', 'mdn'):
        use_fusion = True
    if task == 2:
        labels_for_split = index['label'].values
    else:
        labels_for_split = index['state'].values
    splits, groups = make_cv_splits(index, labels_for_split, split_strategy, fold_seed)
    fold_results = []
    all_fold_predictions = []
    for fold_idx, (train_idx, val_idx) in enumerate(splits):
        set_random_seed(None if train_seed is None else int(train_seed) + fold_idx)
        print(f"\n{'=' * 60}")
        print(f'Fold {fold_idx + 1}/{FOLDS}')
        print(f"{'=' * 60}")
        train_ids = set(index.iloc[train_idx]['id'].values)
        val_ids = set(index.iloc[val_idx]['id'].values)
        assert len(train_ids & val_ids) == 0, 'DATA LEAKAGE: train/val overlap!'
        if groups is not None:
            train_groups = set(groups[train_idx])
            val_groups = set(groups[val_idx])
            assert len(train_groups & val_groups) == 0, 'DATA LEAKAGE: train/val base-patient overlap!'
        train_df = index.iloc[train_idx]
        val_df = index.iloc[val_idx]
        tabular_col = None
        if tabular_cols:
            imputer = SimpleImputer(strategy='median')
            scaler = StandardScaler()
            train_tab = imputer.fit_transform(train_df[tabular_cols])
            val_tab = imputer.transform(val_df[tabular_cols])
            train_tab = scaler.fit_transform(train_tab).astype(np.float32)
            val_tab = scaler.transform(val_tab).astype(np.float32)
            if tabular_mask == 'zeros':
                train_tab[:] = 0.0
                val_tab[:] = 0.0
            elif tabular_mask in ('geometry_only', 'clinical_only'):
                if tabular_mask == 'geometry_only':
                    masked = [idx for idx, col in enumerate(tabular_cols) if col.startswith('clin_')]
                else:
                    masked = [idx for idx, col in enumerate(tabular_cols) if col.startswith('geo_')]
                if masked:
                    train_tab[:, masked] = 0.0
                    val_tab[:, masked] = 0.0
            train_df = train_df.copy()
            val_df = val_df.copy()
            tabular_col = 'tabular_features'
            train_df[tabular_col] = list(train_tab)
            val_df[tabular_col] = list(val_tab)
        train_ds = MRIDataset(roi_dir, train_df, modalities, augment=True, task=task, tabular_col=tabular_col, teacher_col=teacher_col, aux_node_col=aux_node_col, zero_images=zero_images)
        val_ds = MRIDataset(roi_dir, val_df, modalities, augment=False, task=task, tabular_col=tabular_col, teacher_col=teacher_col, aux_node_col=aux_node_col, zero_images=zero_images)
        bs = min(BATCH_SIZE, len(train_ds) // 2)
        train_loader = DataLoader(train_ds, batch_size=bs, shuffle=True, num_workers=NUM_WORKERS, collate_fn=collate_fn)
        val_loader = DataLoader(val_ds, batch_size=bs, shuffle=False, num_workers=NUM_WORKERS, collate_fn=collate_fn)
        causal_l1 = False
        if use_fusion:
            if fusion == 'causal_v2':
                from net_family_3d import get_fusion_v2
                model = get_fusion_v2(model_name, num_classes).to(device)
                causal_l1 = True
            else:
                model = get_fusion(fusion, model_name, num_classes, **fusion_kwargs).to(device)
        else:
            model = get_model(model_name, in_chans=n_chans, num_classes=num_classes).to(device)
        n_params = count_params(model)
        print(f'Model: {model_name}, Params: {n_params / 1000000.0:.1f}M')
        print(f'Train: {len(train_ds)}, Val: {len(val_ds)}')
        if aux_node_col:
            print(f'Aux node labels ({aux_node_source}): train_valid={(train_df[aux_node_col] >= 0).sum()}, val_valid={(val_df[aux_node_col] >= 0).sum()}, weight={aux_node_weight}')
        if groups is not None:
            print(f'Train groups: {len(set(groups[train_idx]))}, Val groups: {len(set(groups[val_idx]))}')
        if task == 2:
            criterion = nn.CrossEntropyLoss()
        else:
            cls_counts = train_df['state'].value_counts().sort_index().values
            cls_weights = 1.0 / cls_counts
            cls_weights = cls_weights / cls_weights.sum() * num_classes
            criterion = nn.CrossEntropyLoss(weight=torch.tensor(cls_weights, dtype=torch.float32).to(device))
        optimizer = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=NUM_EPOCHS)
        best_score = None
        best_val_acc = 0
        best_epoch = 0
        patience_counter = 0
        best_state = None
        best_metrics = None
        for epoch in range(1, NUM_EPOCHS + 1):
            causal_enabled = epoch > causal_warmup_epochs
            train_loss, train_acc = train_epoch(model, train_loader, optimizer, criterion, device, use_fusion, causal_l1, causal_enabled=causal_enabled, distill_weight=distill_weight, distill_temperature=distill_temperature)
            val_metrics = validate(model, val_loader, criterion, device, num_classes, use_fusion, tta=config.get('tta', False))
            scheduler.step()
            val_acc = val_metrics['acc']
            score = val_metrics.get(select_metric, val_acc)
            if metric_is_better(score, best_score):
                best_score = score
                best_val_acc = val_acc
                best_epoch = epoch
                patience_counter = 0
                best_state = clone_state_dict(model)
                best_metrics = val_metrics
            else:
                patience_counter += 1
            if epoch <= 3 or epoch % 10 == 0 or epoch == best_epoch:
                causal_tag = ''
                if hasattr(model, 'causal_loss') and causal_warmup_epochs > 0:
                    causal_tag = f", causal={('on' if causal_enabled else 'warmup')}"
                print(f"  Epoch {epoch:3d}: train_loss={train_loss:.4f}, train_acc={train_acc:.4f}, val_acc={val_acc:.4f}, val_auc={val_metrics.get('auc', 0):.4f}, node_auc={val_metrics.get('node_auc', 0):.4f}, best_{select_metric}={best_score:.4f}@{best_epoch}{causal_tag}")
            if patience_counter >= EARLY_STOP_PATIENCE:
                print(f'  Early stop at epoch {epoch}')
                break
        fold_dir = os.path.join(output_dir, f'fold_{fold_idx + 1}')
        os.makedirs(fold_dir, exist_ok=True)
        torch.save(best_state, os.path.join(fold_dir, 'best_model.pth'))
        fold_metrics = {k: v for k, v in best_metrics.items() if k not in ['cm', 'predictions']}
        fold_metrics['best_epoch'] = best_epoch
        fold_metrics['select_metric'] = select_metric
        fold_metrics['best_score'] = best_score
        fold_metrics['n_params'] = n_params
        fold_metrics['n_train_samples'] = int(len(train_idx))
        fold_metrics['n_val_samples'] = int(len(val_idx))
        if groups is not None:
            fold_metrics['n_train_groups'] = int(len(set(groups[train_idx])))
            fold_metrics['n_val_groups'] = int(len(set(groups[val_idx])))
        fold_results.append(fold_metrics)
        pred_df = pd.DataFrame(best_metrics['predictions'])
        pred_df.to_csv(os.path.join(fold_dir, 'predictions.csv'), index=False)
        all_fold_predictions.append(pred_df)
        cm = np.array(best_metrics['cm'])
        np.savetxt(os.path.join(fold_dir, 'confusion_matrix.csv'), cm, fmt='%d', delimiter=',')
        print(f"  Fold {fold_idx + 1} best: {select_metric}={best_score:.4f}, acc={best_val_acc:.4f}, auc={best_metrics.get('auc', 0):.4f}")
    summary = {}
    for key in fold_results[0].keys():
        if key in ['best_epoch', 'n_params', 'select_metric']:
            continue
        vals = [r[key] for r in fold_results]
        summary[f'{key}_mean'] = np.mean(vals)
        summary[f'{key}_std'] = np.std(vals)
    summary['fold_results'] = fold_results
    summary['select_metric'] = select_metric
    summary['split_strategy'] = split_strategy
    summary['fold_seed'] = fold_seed
    summary['train_seed'] = train_seed
    summary['index_csv'] = index_csv
    summary['tabular_source'] = tabular_source
    summary['tabular_mask'] = tabular_mask
    summary['zero_images'] = zero_images
    summary['tabular_dim'] = len(tabular_cols)
    summary['tabular_cols'] = tabular_cols
    summary['aux_node_task'] = aux_node_task
    summary['aux_node_source'] = aux_node_source if aux_node_task else None
    summary['aux_node_weight'] = aux_node_weight if aux_node_task else 0.0
    summary['aux_node_stats'] = aux_node_stats
    summary['aux_node_classes'] = int((aux_node_stats or {}).get('classes') or 0)
    if groups is not None:
        summary['n_unique_groups'] = int(len(set(groups)))
    with open(os.path.join(output_dir, 'cv_summary.json'), 'w') as f:
        json.dump(summary, f, indent=2, default=str)
    all_preds = pd.concat(all_fold_predictions, ignore_index=True)
    all_preds.to_csv(os.path.join(output_dir, 'all_predictions.csv'), index=False)
    print(f"\n{'=' * 60}")
    print(f'CV Summary ({get_task_label(task)}, {modal}, {model_name}):')
    for key in ['acc', 'auc', 'f1', 'recall']:
        print(f"  {key}: {summary.get(f'{key}_mean', 0):.4f} ± {summary.get(f'{key}_std', 0):.4f}")
    if aux_node_task:
        print(f"  node_auc: {summary.get('node_auc_mean', 0):.4f} +/- {summary.get('node_auc_std', 0):.4f}")
    return summary

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', type=str, default='convnext3d_tiny')
    parser.add_argument('--modal', type=str, default='T2W', choices=['T2W', 'DWI', 'T1C', 'T1W', 'all'])
    parser.add_argument('--task', type=int, default=2, choices=[2, 3, 12], help='2: state3 vs state1+2; 3: state1/2/3; 12: state1 vs state2 only.')
    parser.add_argument('--fusion', type=str, default=None, choices=['early', 'adaptive', 'early_causal', 'late', 'crossattn', 'gated', 'causal', 'causal_v2', 'causal_contrast', 'causal_invariant', 'cif', 'causal_mara', 'cmara', 'ma_cif', 'ma_cmara', 'ordinal_mara', 'omara', 'geometry_mara', 'gmara', 'tripath_mara', 'tmara', 'causal_quality', 'cqof', 'sequential', 'cgcmr', 'mara', 'marav2', 'mdn', None])
    parser.add_argument('--select_metric', type=str, default=None, choices=['acc', 'auc', 'f1', 'recall', 'precision', None], help='Checkpoint metric. Default: auc for 2-class, f1 for 3-class.')
    parser.add_argument('--tta', action='store_true', help='Use 4-view TTA during validation')
    parser.add_argument('--causal_warmup_epochs', type=int, default=0, help='Train causal-loss models with plain CE for this many epochs first.')
    parser.add_argument('--causal_drop_rate', type=float, default=None, help='Override do-intervention modality drop rate for causal fusion models.')
    parser.add_argument('--causal_intervention_ce_weight', type=float, default=None, help='Override CE weight for intervened views.')
    parser.add_argument('--causal_consistency_weight', type=float, default=None, help='Override KL consistency weight for intervened views.')
    parser.add_argument('--causal_feature_weight', type=float, default=None, help='Override feature consistency weight for causal fusion models.')
    parser.add_argument('--causal_temperature', type=float, default=None, help='Override distillation temperature for causal consistency.')
    parser.add_argument('--causal_gate_scale', type=float, default=None, help='Override reliability gate scale for causal_invariant/cif/causal_quality/cqof.')
    parser.add_argument('--causal_aux_state_weight', type=float, default=None, help='Override state-auxiliary CE weight for causal_quality/cqof/ordinal_mara/omara/geometry_mara/gmara/tripath_mara/tmara.')
    parser.add_argument('--causal_supcon_weight', type=float, default=None, help='Override supervised contrastive feature loss weight for causal_quality/cqof/ordinal_mara/omara/geometry_mara/gmara/tripath_mara/tmara.')
    parser.add_argument('--teacher_oof', type=str, default=None, help='CSV with patient-level OOF teacher probabilities or evidence columns for binary distillation.')
    parser.add_argument('--distill_weight', type=float, default=0.0, help='Weight for soft teacher distillation loss.')
    parser.add_argument('--distill_temperature', type=float, default=2.0, help='Temperature for soft teacher distillation loss.')
    parser.add_argument('--split_strategy', type=str, default='group', choices=['group', 'stratified'], help='CV split strategy. group keeps repeated base-patient IDs in the same fold.')
    parser.add_argument('--fold_seed', type=int, default=42, help='Random seed for grouped fold construction. Default preserves prior runs.')
    parser.add_argument('--train_seed', type=int, default=None, help='Optional model/data-loader seed; fold index is added within a CV run.')
    parser.add_argument('--index_csv', type=str, default=None, help='Training index CSV. Default: dataset/roi_v4/index.csv.')
    parser.add_argument('--roi_dir', type=str, default=None, help='MRI ROI root directory. Default: dataset/roi_v4.')
    parser.add_argument('--clinical_csv', type=str, default=None, help='Expanded clinical CSV used when tabular_source includes clinical.')
    parser.add_argument('--tabular_source', type=str, default='auto', choices=['auto', 'none', 'geometry', 'clinical', 'clinical_geometry'], help='Tabular branch features for tabular-capable fusion models.')
    parser.add_argument('--tabular_mask', type=str, default='all', choices=['all', 'zeros', 'geometry_only', 'clinical_only'], help='Mask standardized tabular inputs while preserving the same branch dimensions.')
    parser.add_argument('--zero_images', action='store_true', help='Replace every image tensor with zeros for same-architecture negative controls.')
    parser.add_argument('--aux_node_task', action='store_true', help='Enable lymph-node metastasis auxiliary task using aux_node_source.')
    parser.add_argument('--aux_node_source', type=str, default='g_N', choices=['g_N', 'src279_N', 'src279_N_burden3', 'g_M', 'g_Q'], help='Auxiliary label source. g_N/src279_N/g_M/g_Q are binary; src279_N_burden3 maps 0,1-2,3-5.')
    parser.add_argument('--aux_node_weight', type=float, default=0.1, help='Loss weight for the lymph-node auxiliary head.')
    parser.add_argument('--output', type=str, default=None)
    args = parser.parse_args()
    if args.modal == 'all' and args.fusion is None:
        args.fusion = 'early'
    elif args.modal != 'all':
        args.fusion = None
    fusion_str = f'_{args.fusion}' if args.fusion and args.fusion != 'early' else ''
    if args.output is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        task_label = get_task_label(args.task)
        args.output = os.path.join(OUTPUT_BASE, f'{args.model}_{args.modal}_{task_label}{fusion_str}_{timestamp}')
    fusion_kwargs = {}
    if args.causal_drop_rate is not None:
        fusion_kwargs['drop_rate'] = args.causal_drop_rate
    if args.causal_intervention_ce_weight is not None:
        fusion_kwargs['intervention_ce_weight'] = args.causal_intervention_ce_weight
    if args.causal_consistency_weight is not None:
        fusion_kwargs['consistency_weight'] = args.causal_consistency_weight
    if args.causal_feature_weight is not None:
        fusion_kwargs['feature_weight'] = args.causal_feature_weight
    if args.causal_temperature is not None:
        fusion_kwargs['distill_temperature'] = args.causal_temperature
    if args.causal_gate_scale is not None:
        if args.fusion not in ('causal_invariant', 'cif', 'causal_quality', 'cqof'):
            parser.error('--causal_gate_scale is only valid for --fusion causal_invariant/cif/causal_quality/cqof')
        fusion_kwargs['gate_scale'] = args.causal_gate_scale
    if args.causal_aux_state_weight is not None:
        if args.fusion not in ('causal_quality', 'cqof', 'ordinal_mara', 'omara', 'geometry_mara', 'gmara', 'tripath_mara', 'tmara'):
            parser.error('--causal_aux_state_weight is only valid for --fusion causal_quality/cqof/ordinal_mara/omara/geometry_mara/gmara/tripath_mara/tmara')
        fusion_kwargs['aux_state_weight'] = args.causal_aux_state_weight
    if args.causal_supcon_weight is not None:
        if args.fusion not in ('causal_quality', 'cqof', 'ordinal_mara', 'omara', 'geometry_mara', 'gmara', 'tripath_mara', 'tmara'):
            parser.error('--causal_supcon_weight is only valid for --fusion causal_quality/cqof/ordinal_mara/omara/geometry_mara/gmara/tripath_mara/tmara')
        fusion_kwargs['supcon_weight'] = args.causal_supcon_weight
    if args.aux_node_task:
        if args.fusion not in ('ordinal_mara', 'omara', 'geometry_mara', 'gmara'):
            parser.error('--aux_node_task is currently supported for --fusion ordinal_mara/omara/geometry_mara/gmara')
    use_geometry = args.fusion in ('geometry_mara', 'gmara', 'tripath_mara', 'tmara')
    config = {'model_name': args.model, 'modal': args.modal, 'task': args.task, 'fusion': args.fusion if args.fusion != 'early' else None, 'output_dir': args.output, 'tta': args.tta, 'select_metric': args.select_metric, 'fusion_kwargs': fusion_kwargs, 'causal_warmup_epochs': args.causal_warmup_epochs, 'use_geometry': use_geometry, 'teacher_oof': args.teacher_oof, 'distill_weight': args.distill_weight, 'distill_temperature': args.distill_temperature, 'split_strategy': args.split_strategy, 'fold_seed': args.fold_seed, 'train_seed': args.train_seed, 'index_csv': args.index_csv, 'roi_dir': args.roi_dir, 'clinical_csv': args.clinical_csv, 'tabular_source': args.tabular_source, 'tabular_mask': args.tabular_mask, 'zero_images': args.zero_images, 'aux_node_task': args.aux_node_task, 'aux_node_source': args.aux_node_source, 'aux_node_weight': args.aux_node_weight}
    print(f"Experiment: {config['model_name']} | {config['modal']} | {get_task_label(config['task'])} | fusion={config['fusion']}")
    print(f"Output: {config['output_dir']}")
    if fusion_kwargs:
        print(f'Fusion kwargs: {fusion_kwargs}')
    if args.causal_warmup_epochs:
        print(f'Causal warmup epochs: {args.causal_warmup_epochs}')
    if args.teacher_oof:
        print(f'Evidence distillation: {args.teacher_oof}, weight={args.distill_weight}, T={args.distill_temperature}')
    if args.aux_node_task:
        print(f'Aux lymph-node task: source={args.aux_node_source}, weight={args.aux_node_weight}')
    if use_geometry:
        print('ROI geometry features: enabled')
    print(f'CV split strategy: {args.split_strategy}')
    print(f'Fold seed: {args.fold_seed}')
    print(f'Training seed: {args.train_seed}')
    print(f"Index CSV: {args.index_csv or os.path.join(ROI_DIR, 'index.csv')}")
    print(f'ROI directory: {args.roi_dir or ROI_DIR}')
    print(f'Tabular source: {args.tabular_source}')
    print(f'Tabular mask: {args.tabular_mask}; zero images: {args.zero_images}')
    start_time = time.time()
    run_experiment(config)
    elapsed = time.time() - start_time
    print(f'Total time: {elapsed / 60:.1f} min')
if __name__ == '__main__':
    main()
