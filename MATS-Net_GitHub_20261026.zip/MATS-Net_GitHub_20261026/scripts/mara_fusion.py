import torch
import torch.nn as nn
import torch.nn.functional as F

class MARAFusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, num_modalities=4):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 4, 16, 64, 64)
            self.feat_dim = self.encoder.forward_features(dummy).shape[-1]
        self.num_modalities = num_modalities
        self.mod_queries = nn.Parameter(torch.randn(num_modalities, self.feat_dim) * 0.02)
        self.attn_scale = self.feat_dim ** 0.5
        self.gamma = nn.Parameter(torch.zeros(1))
        self.pre_attn_norm = nn.LayerNorm(self.feat_dim)
        self.classifier = nn.Sequential(nn.LayerNorm(self.feat_dim), nn.Linear(self.feat_dim, self.feat_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.feat_dim // 2, num_classes))

    def forward(self, x):
        fused = torch.cat(x, dim=1)
        feats = self.encoder.forward_features(fused)
        feats_normed = self.pre_attn_norm(feats)
        attn_scores = torch.matmul(feats_normed, self.mod_queries.T)
        attn_scores = attn_scores / self.attn_scale
        attn_weights = torch.softmax(attn_scores, dim=-1)
        attended = torch.matmul(attn_weights, self.mod_queries)
        feats = feats + self.gamma * attended
        return self.classifier(feats)

    def get_attention_weights(self, x):
        with torch.no_grad():
            fused = torch.cat(x, dim=1)
            feats = self.encoder.forward_features(fused)
            feats_normed = self.pre_attn_norm(feats)
            attn_scores = torch.matmul(feats_normed, self.mod_queries.T) / self.attn_scale
            return torch.softmax(attn_scores, dim=-1)
