from _paths import project_path as _project_path
import os, sys, argparse, warnings
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import StratifiedKFold
from sklearn.metrics import accuracy_score, roc_auc_score, f1_score, recall_score
import nibabel as nib
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import get_fusion, get_model, count_params
warnings.filterwarnings('ignore')
ROI_DIR = _project_path('dataset/roi_v4')
MODALITIES = ['T2W', 'DWI', 'T1C', 'T1W']
BATCH_SIZE = 16
NUM_WORKERS = 4

class MRIInferenceDataset(Dataset):

    def __init__(self, root_dir, index_df, task=2):
        self.root_dir = root_dir
        self.df = index_df.reset_index(drop=True)
        self.task = task

    def __len__(self):
        return len(self.df)

    def _load(self, pid, mod):
        fp = os.path.join(self.root_dir, str(pid), f'{mod}.nii.gz')
        img = nib.load(fp)
        data = img.get_fdata().astype(np.float32)
        data = np.transpose(data, (2, 0, 1))
        vmin, vmax = (data.min(), data.max())
        if vmax > vmin:
            data = (data - vmin) / (vmax - vmin)
        return data

    def __getitem__(self, idx):
        row = self.df.iloc[idx]
        pid = str(row['id'])
        vols = [torch.from_numpy(self._load(pid, m)).unsqueeze(0) for m in MODALITIES]
        label = int(row['label']) if self.task == 2 else int(row['state']) - 1
        return {'pid': pid, 'volumes': vols, 'label': label}

def collate_fn(batch):
    n = len(batch[0]['volumes'])
    vols = [torch.stack([b['volumes'][i] for b in batch]) for i in range(n)]
    return {'pid': [b['pid'] for b in batch], 'volumes': vols, 'label': torch.tensor([b['label'] for b in batch], dtype=torch.long)}

@torch.no_grad()
def predict(model, loader, device, use_fusion):
    model.eval()
    probs_list, labels_list = ([], [])
    for batch in loader:
        if use_fusion:
            vols = [v.to(device) for v in batch['volumes']]
            out = model(vols)
        else:
            x = torch.cat(batch['volumes'], dim=1).to(device)
            out = model(x)
        logits = out[0] if isinstance(out, tuple) else out
        probs_list.append(F.softmax(logits, dim=1).cpu().numpy())
        labels_list.append(batch['label'].numpy())
    return (np.concatenate(probs_list), np.concatenate(labels_list))

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--model_dir', type=str, required=True)
    parser.add_argument('--model', type=str, default='convnext3d_tiny')
    parser.add_argument('--task', type=int, default=2)
    parser.add_argument('--fusion', type=str, default='early')
    args = parser.parse_args()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    index = pd.read_csv(os.path.join(ROI_DIR, 'index.csv'))
    nc = args.task
    use_fusion = args.fusion not in (None, '', 'early')
    if args.task == 2:
        split_labels = index['label'].values
    else:
        split_labels = index['state'].values
    skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    oof_probs = np.zeros((len(index), nc), dtype=np.float32)
    oof_labels = np.zeros(len(index), dtype=np.int32)
    for fold_idx, (_, val_idx) in enumerate(skf.split(index, split_labels)):
        ckpt = os.path.join(args.model_dir, f'fold_{fold_idx + 1}', 'best_model.pth')
        if not os.path.exists(ckpt):
            continue
        if use_fusion:
            model = get_fusion(args.fusion, args.model, nc).to(device)
        else:
            model = get_model(args.model, in_chans=4, num_classes=nc).to(device)
        model.load_state_dict(torch.load(ckpt, map_location=device))
        val_df = index.iloc[val_idx]
        val_ds = MRIInferenceDataset(ROI_DIR, val_df, task=args.task)
        val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False, num_workers=NUM_WORKERS, collate_fn=collate_fn)
        probs, labels = predict(model, val_loader, device, use_fusion)
        for i, idx in enumerate(val_idx):
            oof_probs[idx] = probs[i]
            oof_labels[idx] = labels[i]
    preds = oof_probs.argmax(axis=1)
    acc = accuracy_score(oof_labels, preds)
    print(f'OOF Ensemble ({args.task}cls): ACC={acc:.4f}', end='')
    if nc == 2:
        try:
            auc = roc_auc_score(oof_labels, oof_probs[:, 1])
        except ValueError:
            auc = 0
        f1 = f1_score(oof_labels, preds, zero_division=0)
        print(f', AUC={auc:.4f}, F1={f1:.4f}')
    else:
        try:
            auc = roc_auc_score(oof_labels, oof_probs, multi_class='ovr', average='macro')
        except ValueError:
            auc = 0
        f1 = f1_score(oof_labels, preds, average='macro', zero_division=0)
        print(f', AUC={auc:.4f}, F1={f1:.4f}')
if __name__ == '__main__':
    main()
