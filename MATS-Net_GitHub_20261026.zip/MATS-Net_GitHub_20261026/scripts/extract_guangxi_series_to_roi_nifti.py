from __future__ import annotations
import argparse
import csv
import json
import os
import shutil
import sys
import tempfile
import time
import zipfile
from collections import defaultdict
from typing import Dict, Iterable, List, Tuple
import nibabel as nib
import numpy as np
import pandas as pd
import SimpleITK as sitk
from scipy.ndimage import zoom
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from inventory_guangxi_zip_dicoms import decode_zip_name
MOD_OUT_NAMES = {'T2W': 'T2W', 'DWI': 'DWI', 'T1C': 'T1C', 'T1W': 'T1W', 'ADC': 'ADC'}

def safe_instance_number(value: object) -> int:
    try:
        return int(float(str(value or '0').split('\\')[0]))
    except Exception:
        return 0

def truthy(value: object) -> bool:
    return str(value).strip() in {'1', '1.0', 'True', 'true', 'TRUE'}

def build_zip_name_map(zf: zipfile.ZipFile) -> Dict[str, str]:
    mapping = {}
    for info in zf.infolist():
        if info.is_dir():
            continue
        mapping[decode_zip_name(info.filename)] = info.filename
    return mapping

def center_crop_xy(arr: np.ndarray, crop_fraction: float) -> np.ndarray:
    z, y, x = arr.shape
    crop_fraction = float(np.clip(crop_fraction, 0.2, 1.0))
    crop_y = max(8, min(y, int(round(y * crop_fraction))))
    crop_x = max(8, min(x, int(round(x * crop_fraction))))
    y0 = max(0, (y - crop_y) // 2)
    x0 = max(0, (x - crop_x) // 2)
    return arr[:, y0:y0 + crop_y, x0:x0 + crop_x]

def resize_to_training_shape(arr: np.ndarray, target_z: int=16, target_xy: int=64) -> np.ndarray:
    arr = np.asarray(arr, dtype=np.float32)
    if arr.ndim > 3:
        arr = np.squeeze(arr)
    if arr.ndim != 3:
        raise ValueError(f'Expected 3D array after squeeze, got shape={arr.shape}')
    factors = (target_z / arr.shape[0], target_xy / arr.shape[1], target_xy / arr.shape[2])
    resized = zoom(arr, factors, order=1).astype(np.float32)
    return np.transpose(resized, (2, 1, 0))

def read_dicom_series(file_paths: List[str]) -> np.ndarray:
    reader = sitk.ImageSeriesReader()
    reader.SetFileNames(file_paths)
    image = reader.Execute()
    arr = sitk.GetArrayFromImage(image).astype(np.float32)
    return arr

def load_manifest(path: str, only_usable_column: str, modalities: List[str], max_patients: int) -> pd.DataFrame:
    manifest = pd.read_csv(path)
    manifest['patient_id'] = manifest['patient_id'].astype(str).str.upper()
    if only_usable_column:
        manifest = manifest[manifest[only_usable_column].map(truthy)].copy()
    if max_patients and max_patients > 0:
        manifest = manifest.head(max_patients).copy()
    return manifest

def load_file_index(path: str, patient_ids: Iterable[str], modalities: List[str]) -> Dict[Tuple[str, str], List[Dict[str, object]]]:
    patient_set = {str(pid).upper() for pid in patient_ids}
    modality_set = set(modalities)
    grouped: Dict[Tuple[str, str], List[Dict[str, object]]] = defaultdict(list)
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            patient_id = (row.get('patient_id') or '').upper()
            modality = row.get('target_modality') or ''
            if patient_id not in patient_set or modality not in modality_set:
                continue
            grouped[patient_id, modality].append(row)
    for key in list(grouped):
        grouped[key].sort(key=lambda r: (safe_instance_number(r.get('instance_number')), r.get('zip_member') or ''))
    return grouped

def extract_one_series(zf: zipfile.ZipFile, zip_name_map: Dict[str, str], rows: List[Dict[str, object]], temp_dir: str) -> List[str]:
    os.makedirs(temp_dir, exist_ok=True)
    out_files = []
    for idx, row in enumerate(rows):
        decoded = str(row['zip_member'])
        raw = zip_name_map.get(decoded)
        if not raw:
            raise FileNotFoundError(f'ZIP member not found: {decoded}')
        out_path = os.path.join(temp_dir, f'{idx:04d}.dcm')
        with zf.open(raw) as src, open(out_path, 'wb') as dst:
            shutil.copyfileobj(src, dst)
        out_files.append(out_path)
    return out_files

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip-path', required=True)
    parser.add_argument('--file-index', required=True)
    parser.add_argument('--validation-manifest', required=True)
    parser.add_argument('--out-dir', required=True)
    parser.add_argument('--modalities', nargs='+', default=['T2W'])
    parser.add_argument('--only-usable-column', default='can_validate_t_stage_t2')
    parser.add_argument('--max-patients', type=int, default=0)
    parser.add_argument('--crop-fraction', type=float, default=0.65)
    parser.add_argument('--target-xy', type=int, default=64)
    parser.add_argument('--target-z', type=int, default=16)
    parser.add_argument('--keep-temp', action='store_true')
    args = parser.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    started = time.time()
    manifest = load_manifest(args.validation_manifest, args.only_usable_column, args.modalities, args.max_patients)
    patient_ids = manifest['patient_id'].tolist()
    grouped = load_file_index(args.file_index, patient_ids, args.modalities)
    records = []
    failures = []
    with zipfile.ZipFile(args.zip_path) as zf:
        zip_name_map = build_zip_name_map(zf)
        for _, row in manifest.iterrows():
            patient_id = row['patient_id']
            patient_ok = True
            patient_dir = os.path.join(args.out_dir, patient_id)
            os.makedirs(patient_dir, exist_ok=True)
            for modality in args.modalities:
                rows = grouped.get((patient_id, modality), [])
                if not rows:
                    failures.append({'patient_id': patient_id, 'modality': modality, 'error': 'missing_file_index_rows'})
                    patient_ok = False
                    continue
                tmp_parent = tempfile.mkdtemp(prefix=f'{patient_id}_{modality}_')
                try:
                    dicom_files = extract_one_series(zf, zip_name_map, rows, tmp_parent)
                    arr = read_dicom_series(dicom_files)
                    arr = center_crop_xy(arr, args.crop_fraction)
                    data = resize_to_training_shape(arr, target_z=args.target_z, target_xy=args.target_xy)
                    out_name = MOD_OUT_NAMES[modality] + '.nii.gz'
                    nib.save(nib.Nifti1Image(data, np.eye(4)), os.path.join(patient_dir, out_name))
                    records.append({'patient_id': patient_id, 'modality': modality, 'dicom_files': len(rows), 'raw_shape_zyx': 'x'.join((str(v) for v in arr.shape)), 'out_shape_xyz': 'x'.join((str(v) for v in data.shape)), 'out_path': os.path.join(patient_dir, out_name)})
                except Exception as exc:
                    failures.append({'patient_id': patient_id, 'modality': modality, 'error': repr(exc)})
                    patient_ok = False
                finally:
                    if not args.keep_temp:
                        shutil.rmtree(tmp_parent, ignore_errors=True)
            if patient_ok:
                pass
    index_rows = []
    for _, row in manifest.iterrows():
        patient_id = row['patient_id']
        expected = [os.path.join(args.out_dir, patient_id, MOD_OUT_NAMES[m] + '.nii.gz') for m in args.modalities]
        if all((os.path.exists(p) for p in expected)):
            label = int(float(row['path_T_binary']))
            index_rows.append({'id': patient_id, 'state': 3 if label == 1 else 2, 'label': label})
    pd.DataFrame(index_rows).to_csv(os.path.join(args.out_dir, 'index.csv'), index=False)
    pd.DataFrame(records).to_csv(os.path.join(args.out_dir, 'extraction_records.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(failures).to_csv(os.path.join(args.out_dir, 'extraction_failures.csv'), index=False, encoding='utf-8-sig')
    summary = {'zip_path': args.zip_path, 'file_index': args.file_index, 'validation_manifest': args.validation_manifest, 'out_dir': args.out_dir, 'modalities': args.modalities, 'only_usable_column': args.only_usable_column, 'requested_patients': int(len(manifest)), 'successful_patients': int(len(index_rows)), 'extracted_series': int(len(records)), 'failures': int(len(failures)), 'crop_fraction': args.crop_fraction, 'target_shape_xyz': [args.target_xy, args.target_xy, args.target_z], 'elapsed_seconds': round(time.time() - started, 3)}
    with open(os.path.join(args.out_dir, 'extraction_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
