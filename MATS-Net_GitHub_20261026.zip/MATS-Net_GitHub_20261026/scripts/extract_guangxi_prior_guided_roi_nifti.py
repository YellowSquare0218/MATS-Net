from __future__ import annotations
import argparse
import csv
import json
import os
import shutil
import sys
import tempfile
import time
import zipfile
from collections import defaultdict
from typing import Dict, Iterable, List, Optional, Tuple
import nibabel as nib
import numpy as np
import pandas as pd
import SimpleITK as sitk
from scipy.ndimage import gaussian_filter
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from extract_guangxi_auto_roi_nifti import MOD_OUT_NAMES, build_zip_name_map, crop_with_padding, extract_one_series, load_file_index, load_manifest, physical_to_index_or_center, read_series_image, resize_to_training_shape, robust_normalize

def safe_instance_number(value: object) -> int:
    try:
        return int(float(str(value or '0').split('\\')[0]))
    except Exception:
        return 0

def load_selected_rows(path: str, patient_ids: Iterable[str], modalities: Iterable[str]) -> Dict[Tuple[str, str], List[Dict[str, object]]]:
    patient_set = {str(pid).upper() for pid in patient_ids}
    modality_set = set(modalities)
    grouped: Dict[Tuple[str, str], List[Dict[str, object]]] = defaultdict(list)
    with open(path, newline='', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        for row in reader:
            patient_id = (row.get('patient_id') or '').upper()
            modality = row.get('target_modality') or ''
            if patient_id not in patient_set or modality not in modality_set:
                continue
            grouped[patient_id, modality].append(row)
    for key in list(grouped):
        grouped[key].sort(key=lambda r: (safe_instance_number(r.get('instance_number')), r.get('zip_member') or ''))
    return grouped

def crop_bounds(center_xyz: Tuple[float, float, float], spacing_xyz: Tuple[float, float, float], shape_zyx: Tuple[int, int, int], crop_xy_mm: float, crop_z_mm: float) -> Tuple[int, int, int, int, int, int]:
    zdim, ydim, xdim = shape_zyx
    cx, cy, cz = center_xyz
    sx, sy, sz = [max(float(v), 0.001) for v in spacing_xyz]
    half_x = max(8, int(round(crop_xy_mm / (2.0 * sx))))
    half_y = max(8, int(round(crop_xy_mm / (2.0 * sy))))
    half_z = max(2, int(round(crop_z_mm / (2.0 * sz))))
    x0, x1 = (int(round(cx)) - half_x, int(round(cx)) + half_x + 1)
    y0, y1 = (int(round(cy)) - half_y, int(round(cy)) + half_y + 1)
    z0, z1 = (int(round(cz)) - half_z, int(round(cz)) + half_z + 1)
    return (x0, x1, y0, y1, z0, z1)

def padding_fraction(center_xyz: Tuple[float, float, float], spacing_xyz: Tuple[float, float, float], shape_zyx: Tuple[int, int, int], crop_xy_mm: float, crop_z_mm: float) -> float:
    x0, x1, y0, y1, z0, z1 = crop_bounds(center_xyz, spacing_xyz, shape_zyx, crop_xy_mm, crop_z_mm)
    zdim, ydim, xdim = shape_zyx
    total = max(1, (x1 - x0) * (y1 - y0) * (z1 - z0))
    valid = max(0, min(x1, xdim) - max(x0, 0))
    valid *= max(0, min(y1, ydim) - max(y0, 0))
    valid *= max(0, min(z1, zdim) - max(z0, 0))
    return 1.0 - float(valid / total)

def center_prior_score(center_xyz: Tuple[float, float, float], shape_zyx: Tuple[int, int, int]) -> float:
    zdim, ydim, xdim = shape_zyx
    cx, cy, cz = center_xyz
    dx = (cx - (xdim - 1) / 2.0) / max(1.0, xdim * 0.3)
    dy = (cy - (ydim - 1) / 2.0) / max(1.0, ydim * 0.3)
    dz = (cz - (zdim - 1) / 2.0) / max(1.0, zdim * 0.45)
    return float(np.exp(-0.5 * (dx * dx + dy * dy + 0.35 * dz * dz)))

def local_texture_score(norm_zyx: np.ndarray, search_xy_fraction: float) -> np.ndarray:
    norm = np.asarray(norm_zyx, dtype=np.float32)
    zdim, ydim, xdim = norm.shape
    frac = float(np.clip(search_xy_fraction, 0.35, 0.95))
    x_margin = int(round((1.0 - frac) * xdim / 2.0))
    y_margin = int(round((1.0 - frac) * ydim / 2.0))
    z_margin = max(0, int(round(0.03 * zdim)))
    search = np.zeros_like(norm, dtype=bool)
    search[z_margin:zdim - z_margin or zdim, y_margin:ydim - y_margin or ydim, x_margin:xdim - x_margin or xdim] = True
    smooth = gaussian_filter(norm, sigma=(0.35, 1.2, 1.2))
    local_mean = gaussian_filter(norm, sigma=(0.8, 3.0, 3.0))
    local_sq = gaussian_filter(norm * norm, sigma=(0.8, 3.0, 3.0))
    local_std = np.sqrt(np.maximum(local_sq - local_mean * local_mean, 0.0))
    gz, gy, gx = np.gradient(smooth)
    edge = np.sqrt(gx * gx + gy * gy + 0.25 * gz * gz)
    mid_signal = np.exp(-((smooth - 0.42) / 0.24) ** 2)
    fluid_suppression = np.clip((0.82 - smooth) / 0.34, 0.0, 1.0)
    zz, yy, xx = np.indices(norm.shape)
    cx = (xdim - 1) / 2.0
    cy = (ydim - 1) / 2.0
    xy_prior = np.exp(-(((xx - cx) / max(1.0, xdim * 0.3)) ** 2 + ((yy - cy) / max(1.0, ydim * 0.3)) ** 2) / 2.0)
    score = (0.45 * local_std + 0.35 * edge + 0.2 * mid_signal) * xy_prior * (0.2 + 0.8 * fluid_suppression)
    score[~search] = 0
    return gaussian_filter(score.astype(np.float32), sigma=(0.6, 2.0, 2.0))

def top_texture_candidates(image: sitk.Image, max_candidates: int, search_xy_fraction: float, min_distance_mm: float) -> Tuple[List[Dict[str, object]], np.ndarray]:
    arr = sitk.GetArrayFromImage(image).astype(np.float32)
    norm = robust_normalize(arr)
    score = local_texture_score(norm, search_xy_fraction)
    spacing = image.GetSpacing()
    min_dx = max(3, int(round(min_distance_mm / max(spacing[0], 0.001))))
    min_dy = max(3, int(round(min_distance_mm / max(spacing[1], 0.001))))
    min_dz = max(1, int(round(min_distance_mm * 0.5 / max(spacing[2], 0.001))))
    candidates: List[Dict[str, object]] = []
    working = score.copy()
    for rank in range(max_candidates):
        if float(np.max(working)) <= 0:
            break
        z, y, x = [int(v) for v in np.unravel_index(int(np.argmax(working)), working.shape)]
        idx = (float(x), float(y), float(z))
        physical = image.TransformContinuousIndexToPhysicalPoint(idx)
        candidates.append({'source': f't2_texture_{rank + 1}', 'index_xyz': idx, 'physical_xyz': physical, 'raw_score': float(score[z, y, x])})
        z0, z1 = (max(0, z - min_dz), min(working.shape[0], z + min_dz + 1))
        y0, y1 = (max(0, y - min_dy), min(working.shape[1], y + min_dy + 1))
        x0, x1 = (max(0, x - min_dx), min(working.shape[2], x + min_dx + 1))
        working[z0:z1, y0:y1, x0:x1] = 0
    return (candidates, norm)

def dwi_hotspot_candidate(image: sitk.Image, search_xy_fraction: float) -> Optional[Dict[str, object]]:
    arr = sitk.GetArrayFromImage(image).astype(np.float32)
    norm = robust_normalize(arr)
    score = local_texture_score(norm, search_xy_fraction)
    if float(np.max(score)) <= 0:
        return None
    z, y, x = [int(v) for v in np.unravel_index(int(np.argmax(score)), score.shape)]
    idx = (float(x), float(y), float(z))
    return {'source': 'dwi_hotspot', 'index_xyz': idx, 'physical_xyz': image.TransformContinuousIndexToPhysicalPoint(idx), 'raw_score': float(score[z, y, x])}

def fixed_center_candidates(image: sitk.Image) -> List[Dict[str, object]]:
    size = image.GetSize()
    x = (size[0] - 1) / 2.0
    y = (size[1] - 1) / 2.0
    zvals = [(size[2] - 1) / 2.0]
    if size[2] >= 12:
        zvals.extend([(size[2] - 1) * 0.35, (size[2] - 1) * 0.65])
    out = []
    for idx, z in enumerate(zvals, start=1):
        xyz = (float(x), float(y), float(z))
        out.append({'source': f'center_prior_{idx}', 'index_xyz': xyz, 'physical_xyz': image.TransformContinuousIndexToPhysicalPoint(xyz), 'raw_score': 0.0})
    return out

def crop_quality_score(arr_zyx: np.ndarray, norm_zyx: np.ndarray, center_xyz: Tuple[float, float, float], spacing_xyz: Tuple[float, float, float], crop_xy_mm: float, crop_z_mm: float, source: str, dwi_t2_distance_mm: Optional[float]) -> Dict[str, float]:
    crop = crop_with_padding(arr_zyx, center_xyz, spacing_xyz, crop_xy_mm, crop_z_mm)
    crop_norm = robust_normalize(crop)
    foreground = crop_norm > 0.03
    fg_ratio = float(foreground.mean())
    tissue = crop_norm[foreground] if foreground.any() else crop_norm.reshape(-1)
    contrast = float(np.std(tissue))
    p10, p90 = np.percentile(tissue, [10, 90]) if tissue.size else (0.0, 0.0)
    dynamic = float(p90 - p10)
    bright_fraction = float((crop_norm > 0.82).mean())
    very_bright_fraction = float((crop_norm > 0.92).mean())
    pad = padding_fraction(center_xyz, spacing_xyz, arr_zyx.shape, crop_xy_mm, crop_z_mm)
    center_score = center_prior_score(center_xyz, arr_zyx.shape)
    dwi_score = 0.0
    if dwi_t2_distance_mm is not None:
        dwi_score = float(np.exp(-0.5 * (dwi_t2_distance_mm / 35.0) ** 2))
    source_bonus = 0.04 if source.startswith('t2_texture') else 0.0
    if source == 'dwi_hotspot':
        source_bonus = 0.02
    quality = 0.25 * np.clip(fg_ratio / 0.65, 0, 1) + 0.25 * np.clip(contrast / 0.22, 0, 1) + 0.2 * np.clip(dynamic / 0.55, 0, 1) + 0.2 * center_score + 0.1 * dwi_score + source_bonus - 0.45 * pad - 0.35 * np.clip(bright_fraction / 0.18, 0, 1) - 0.25 * np.clip(very_bright_fraction / 0.08, 0, 1)
    return {'quality_score': float(quality), 'foreground_ratio': fg_ratio, 'contrast': contrast, 'dynamic_p10p90': dynamic, 'bright_fraction': bright_fraction, 'very_bright_fraction': very_bright_fraction, 'padding_fraction': float(pad), 'center_prior_score': float(center_score), 'dwi_agreement_score': float(dwi_score)}

def physical_distance_mm(a: Tuple[float, float, float], b: Tuple[float, float, float]) -> float:
    return float(np.linalg.norm(np.asarray(a, dtype=float) - np.asarray(b, dtype=float)))

def select_candidate(t2_image: sitk.Image, dwi_image: Optional[sitk.Image], crop_xy_mm: float, crop_z_mm: float, search_xy_fraction: float, max_texture_candidates: int) -> Tuple[Dict[str, object], List[Dict[str, object]]]:
    t2_arr = sitk.GetArrayFromImage(t2_image).astype(np.float32)
    t2_candidates, t2_norm = top_texture_candidates(t2_image, max_candidates=max_texture_candidates, search_xy_fraction=search_xy_fraction, min_distance_mm=max(18.0, crop_xy_mm * 0.35))
    candidates = fixed_center_candidates(t2_image) + t2_candidates
    dwi_physical = None
    if dwi_image is not None:
        try:
            dwi_candidate = dwi_hotspot_candidate(dwi_image, search_xy_fraction)
            if dwi_candidate is not None:
                dwi_physical = tuple((float(v) for v in dwi_candidate['physical_xyz']))
                dwi_idx_on_t2 = physical_to_index_or_center(t2_image, dwi_physical)
                dwi_candidate['index_xyz'] = dwi_idx_on_t2
                candidates.append(dwi_candidate)
        except Exception:
            dwi_physical = None
    scored: List[Dict[str, object]] = []
    for cand in candidates:
        idx_xyz = tuple((float(v) for v in cand['index_xyz']))
        physical = tuple((float(v) for v in cand['physical_xyz']))
        if cand['source'] == 'dwi_hotspot':
            physical = t2_image.TransformContinuousIndexToPhysicalPoint(idx_xyz)
        dist = physical_distance_mm(physical, dwi_physical) if dwi_physical is not None else None
        metrics = crop_quality_score(t2_arr, t2_norm, idx_xyz, t2_image.GetSpacing(), crop_xy_mm, crop_z_mm, str(cand['source']), dist)
        record = {'source': cand['source'], 'index_x': idx_xyz[0], 'index_y': idx_xyz[1], 'index_z': idx_xyz[2], 'physical_x': physical[0], 'physical_y': physical[1], 'physical_z': physical[2], 'raw_score': float(cand.get('raw_score', 0.0)), 'dwi_distance_mm': dist, **metrics}
        scored.append(record)
    scored.sort(key=lambda r: float(r['quality_score']), reverse=True)
    return (scored[0], scored)

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--zip-path', required=True)
    parser.add_argument('--file-index', required=True)
    parser.add_argument('--validation-manifest', required=True)
    parser.add_argument('--out-dir', required=True)
    parser.add_argument('--modalities', nargs='+', default=['T2W'])
    parser.add_argument('--locator-modality', default='DWI')
    parser.add_argument('--only-usable-column', default='can_validate_t_stage_t2')
    parser.add_argument('--max-patients', type=int, default=0)
    parser.add_argument('--crop-xy-mm', type=float, default=60.0)
    parser.add_argument('--crop-z-mm', type=float, default=44.0)
    parser.add_argument('--target-xy', type=int, default=64)
    parser.add_argument('--target-z', type=int, default=16)
    parser.add_argument('--search-xy-fraction', type=float, default=0.7)
    parser.add_argument('--max-texture-candidates', type=int, default=8)
    parser.add_argument('--keep-temp', action='store_true')
    args = parser.parse_args()
    os.makedirs(args.out_dir, exist_ok=True)
    started = time.time()
    manifest = load_manifest(args.validation_manifest, args.only_usable_column, args.max_patients)
    patient_ids = manifest['patient_id'].astype(str).str.upper().tolist()
    needed_modalities = set(args.modalities) | {'T2W', args.locator_modality}
    grouped = load_selected_rows(args.file_index, patient_ids, needed_modalities)
    records = []
    candidate_records = []
    centers = []
    failures = []
    with zipfile.ZipFile(args.zip_path) as zf:
        zip_name_map = build_zip_name_map(zf)
        for _, row in manifest.iterrows():
            patient_id = str(row['patient_id']).upper()
            t2_rows = grouped.get((patient_id, 'T2W'), [])
            if not t2_rows:
                failures.append({'patient_id': patient_id, 'modality': 'T2W', 'error': 'missing_t2_rows'})
                continue
            patient_dir = os.path.join(args.out_dir, patient_id)
            os.makedirs(patient_dir, exist_ok=True)
            t2_tmp = tempfile.mkdtemp(prefix=f'{patient_id}_T2W_prior_')
            dwi_tmp = None
            try:
                t2_files = extract_one_series(zf, zip_name_map, t2_rows, t2_tmp)
                t2_image = read_series_image(t2_files)
                dwi_image = None
                dwi_rows = grouped.get((patient_id, args.locator_modality), [])
                if dwi_rows:
                    dwi_tmp = tempfile.mkdtemp(prefix=f'{patient_id}_{args.locator_modality}_prior_')
                    dwi_files = extract_one_series(zf, zip_name_map, dwi_rows, dwi_tmp)
                    dwi_image = read_series_image(dwi_files)
                best, scored = select_candidate(t2_image, dwi_image, args.crop_xy_mm, args.crop_z_mm, args.search_xy_fraction, args.max_texture_candidates)
                for rank, cand in enumerate(scored, start=1):
                    candidate_records.append({'patient_id': patient_id, 'rank': rank, **cand})
                center_idx = (float(best['index_x']), float(best['index_y']), float(best['index_z']))
                t2_arr = sitk.GetArrayFromImage(t2_image).astype(np.float32)
                crop = crop_with_padding(t2_arr, center_idx, t2_image.GetSpacing(), args.crop_xy_mm, args.crop_z_mm)
                data = resize_to_training_shape(crop, target_z=args.target_z, target_xy=args.target_xy)
                out_path = os.path.join(patient_dir, 'T2W.nii.gz')
                nib.save(nib.Nifti1Image(data, np.eye(4)), out_path)
                label = int(float(row['path_T_binary']))
                records.append({'id': patient_id, 'state': 3 if label == 1 else 2, 'label': label})
                centers.append({'patient_id': patient_id, 'selected_source': best['source'], 'selected_quality_score': best['quality_score'], 'center_index_xyz': f'{center_idx[0]:.2f}x{center_idx[1]:.2f}x{center_idx[2]:.2f}', 'center_physical_xyz': f"{best['physical_x']:.3f}x{best['physical_y']:.3f}x{best['physical_z']:.3f}", 't2_shape_zyx': 'x'.join((str(v) for v in t2_arr.shape)), 't2_spacing_xyz': 'x'.join((f'{v:.4g}' for v in t2_image.GetSpacing())), 'crop_xy_mm': args.crop_xy_mm, 'crop_z_mm': args.crop_z_mm, 'out_path': out_path})
            except Exception as exc:
                failures.append({'patient_id': patient_id, 'modality': 'T2W', 'error': repr(exc)})
            finally:
                if not args.keep_temp:
                    shutil.rmtree(t2_tmp, ignore_errors=True)
                    if dwi_tmp:
                        shutil.rmtree(dwi_tmp, ignore_errors=True)
    pd.DataFrame(records).to_csv(os.path.join(args.out_dir, 'index.csv'), index=False)
    pd.DataFrame(centers).to_csv(os.path.join(args.out_dir, 'roi_centers.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(candidate_records).to_csv(os.path.join(args.out_dir, 'roi_candidates.csv'), index=False, encoding='utf-8-sig')
    pd.DataFrame(failures).to_csv(os.path.join(args.out_dir, 'extraction_failures.csv'), index=False, encoding='utf-8-sig')
    summary = {'zip_path': args.zip_path, 'file_index': args.file_index, 'validation_manifest': args.validation_manifest, 'out_dir': args.out_dir, 'modalities': args.modalities, 'locator_modality': args.locator_modality, 'only_usable_column': args.only_usable_column, 'requested_patients': int(len(manifest)), 'successful_patients': int(len(records)), 'failures': int(len(failures)), 'crop_xy_mm': args.crop_xy_mm, 'crop_z_mm': args.crop_z_mm, 'target_shape_xyz': [args.target_xy, args.target_xy, args.target_z], 'search_xy_fraction': args.search_xy_fraction, 'max_texture_candidates': args.max_texture_candidates, 'elapsed_seconds': round(time.time() - started, 3)}
    with open(os.path.join(args.out_dir, 'extraction_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
