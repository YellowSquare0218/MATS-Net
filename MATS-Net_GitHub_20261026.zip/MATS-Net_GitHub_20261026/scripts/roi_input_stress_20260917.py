from _paths import project_path as _project_path
import argparse
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn.functional as F
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader
import train as core
import fully_nested_patient_fusion as prep
import counterfactual_image_region_intervention as cie
VARIANTS = [('original', 1.0, 0.0, 0.0, False), ('shift_x_plus5pct', 1.0, 0.1, 0.0, False), ('shift_x_minus5pct', 1.0, -0.1, 0.0, False), ('shift_y_plus5pct', 1.0, 0.0, 0.1, False), ('shift_y_minus5pct', 1.0, 0.0, -0.1, False), ('image_scale090', 0.9, 0.0, 0.0, False), ('image_scale110', 1.1, 0.0, 0.0, False), ('joint_scale090', 0.9, 0.0, 0.0, True), ('joint_scale110', 1.1, 0.0, 0.0, True)]

def transform(volumes, scale, dx, dy):
    if scale == 1 and dx == 0 and (dy == 0):
        return volumes
    out = []
    for v in volumes:
        theta = torch.zeros((len(v), 3, 4), device=v.device, dtype=v.dtype)
        theta[:, 0, 0] = scale
        theta[:, 1, 1] = scale
        theta[:, 2, 2] = 1
        theta[:, 0, 3] = dx
        theta[:, 1, 3] = dy
        grid = F.affine_grid(theta, v.shape, align_corners=False)
        x = F.grid_sample(v, grid, mode='bilinear', padding_mode='border', align_corners=False)
        lo = x.amin((2, 3, 4), keepdim=True)
        hi = x.amax((2, 3, 4), keepdim=True)
        out.append(torch.where(hi > lo, (x - lo) / (hi - lo).clamp_min(1e-12), x))
    return out

def geometry_scale(frame, scale):
    result = frame.copy()
    for mod in core.MODALITIES:
        for axis in ['x', 'y']:
            prefix = f'geo_{mod}_{axis}'
            start, end = (result[prefix + '_start'], result[prefix + '_end'])
            center = (start + end) / 2
            length = result[prefix + '_len'] * scale
            result[prefix + '_start'] = center - (length - 1) / 2
            result[prefix + '_end'] = center + (length - 1) / 2
            result[prefix + '_len'] = length
        result[f'geo_{mod}_xy_area'] = result[f'geo_{mod}_x_len'] * result[f'geo_{mod}_y_len']
        result[f'geo_{mod}_vol_approx'] = result[f'geo_{mod}_xy_area'] * result[f'geo_{mod}_z_len']
    return result

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path(_project_path('')))
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(8)
    modeldir = args.project / 'training_results/convnext_tiny_all_2cls_aug262_gmara_clingeo_node_burden_w004_acc'
    config = json.loads((modeldir / 'config.json').read_text())
    summary = json.loads((modeldir / 'cv_summary.json').read_text())
    cols = summary['tabular_cols']
    core.ROI_DIR = str(args.project / 'dataset/roi_v4')
    core.CLINICAL_FEATURE_COLS = [c.removeprefix('clin_') for c in cols if c.startswith('clin_')]
    base = pd.read_csv(config['index_csv'], dtype={'id': str})
    base.id = base.id.map(core.normalize_id)
    frame, columns, aux, kwargs = prep.prepare_expert_frame(base, config, Path(config['clinical_csv']))
    assert cols == columns and len(base) == 262 and base.id.is_unique
    splits, _ = core.make_cv_splits(base, base.label.to_numpy(), config['split_strategy'], config.get('fold_seed', 42))
    device = torch.device('cuda')
    records = []
    audits = []
    for fold, (it, iv) in enumerate(splits, 1):
        saved = pd.read_csv(modeldir / f'fold_{fold}/predictions.csv', dtype={'pid': str}).set_index('pid')
        val = frame.iloc[iv].copy()
        assert set(saved.index) == set(val.id)
        imp = SimpleImputer(strategy='median')
        scaler = StandardScaler()
        scaler.fit(imp.fit_transform(frame.iloc[it][cols]))
        views = {}
        for scale in [1.0, 0.9, 1.1]:
            raw = val if scale == 1 else geometry_scale(val, scale)
            views[scale] = pd.DataFrame(scaler.transform(imp.transform(raw[cols])).astype(np.float32), index=val.id)
        val['tabular_features'] = list(views[1.0].to_numpy())
        if args.smoke:
            val = val.iloc[:2]
        ds = core.MRIDataset(core.ROI_DIR, val, core.MODALITIES, augment=False, task=2, tabular_col='tabular_features')
        loader = DataLoader(ds, batch_size=8, shuffle=False, num_workers=0, collate_fn=core.collate_fn)
        model = cie.build_model(config, kwargs, device)
        checkpoint = modeldir / f'fold_{fold}/best_model.pth'
        model.load_state_dict(cie.load_state(str(checkpoint), device), strict=True)
        model.eval()
        with torch.no_grad():
            for batch in loader:
                volumes = [v.to(device) for v in batch['volumes']]
                assert all((v.shape[1:] == (1, 16, 64, 64) and torch.isfinite(v).all() for v in volumes))
                pids = batch['pids'] if 'pids' in batch else batch['pid']
                labels = batch['labels'] if 'labels' in batch else batch['label']
                original = None
                for name, scale, dx, dy, joint in VARIANTS:
                    images = transform(volumes, scale, dx, dy)
                    tab = torch.as_tensor(views[scale if joint else 1.0].loc[pids].to_numpy(), device=device)
                    score = cie.positive_probs(cie.forward_model(model, images, tab))
                    assert np.isfinite(score).all()
                    if name == 'original':
                        original = score.copy()
                        expected = saved.loc[pids, 'prob_pos'].to_numpy()
                        error = float(np.max(np.abs(score - expected)))
                        audits.append({'fold': fold, 'max_probability_error': error})
                        if error > 0.0002:
                            raise RuntimeError(f'Baseline prediction mismatch: {error}')
                    for pid, y, p, ref in zip(pids, labels, score, original):
                        records.append(dict(pid=pid, label=int(y), fold=fold, variant=name, prob_pos=float(p), original_prob=float(ref)))
        del model
        torch.cuda.empty_cache()
        print(f'FOLD_COMPLETE {fold} rows={len(records)}', flush=True)
        if args.smoke:
            break
    df = pd.DataFrame(records)
    df.to_csv(args.output / ('smoke_predictions.csv' if args.smoke else 'predictions.csv'), index=False)
    (args.output / 'baseline_audit.json').write_text(json.dumps(audits, indent=2))
    if args.smoke:
        (args.output / 'smoke_passed.json').write_text(json.dumps({'passed': True, 'n_variants': len(VARIANTS)}))
        return
    result = []
    for name, g in df.groupby('variant', sort=False):
        assert len(g) == 262 and g.pid.is_unique
        y = g.label.to_numpy()
        p = g.prob_pos.to_numpy()
        ref = g.original_prob.to_numpy()
        m = cie.binary_metrics(y, p)
        m.update(variant=name, delta_auc=float(roc_auc_score(y, p) - roc_auc_score(y, ref)), mean_abs_probability_change=float(np.mean(np.abs(p - ref))), flip_rate=float(np.mean((p >= 0.5) != (ref >= 0.5))))
        groups = g.pid.str.replace('_\\d+$', '', regex=True).to_numpy()
        blocks = [np.flatnonzero(groups == z) for z in np.unique(groups)]
        rng = np.random.default_rng(20260917)
        delta = []
        for _ in range(2000):
            ix = np.concatenate([blocks[j] for j in rng.integers(len(blocks), size=len(blocks))])
            if len(np.unique(y[ix])) == 2:
                delta.append(roc_auc_score(y[ix], p[ix]) - roc_auc_score(y[ix], ref[ix]))
        m['delta_auc_ci_low'], m['delta_auc_ci_high'] = np.quantile(delta, [0.025, 0.975])
        result.append(m)
    pd.DataFrame(result).to_csv(args.output / 'roi_stress_metrics.csv', index=False)
    (args.output / 'protocol.json').write_text(json.dumps({'model_dir': str(modeldir), 'variants': VARIANTS, 'scope': 'Synthetic normalized ROI input stress, not anatomical resegmentation or recovered outside tissue', 'translation': '5 percent in-plane extent; grid axes, not anatomical left/right', 'image_scaling': 'In-plane coordinate sampling factor 0.9/1.1; trilinear border replication; per-volume minmax normalization', 'geometry': 'image-only conditions keep geometry fixed; joint scale modifies nominal XY box endpoints, lengths, area, volume; Z and max slice unchanged. Synthetic metadata sensitivity, not remeasured anatomy.', 'preprocessing': 'Imputer/scaler reconstructed only on original fold training data; never refit to perturbations', 'threshold': 0.5, 'bootstrap': '2000 paired group draws on fixed predictions; no retraining or selection uncertainty', 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}, indent=2))
    (args.output / 'complete.json').write_text(json.dumps({'n': 262, 'variants': len(VARIANTS), 'completed': True}))
if __name__ == '__main__':
    main()
