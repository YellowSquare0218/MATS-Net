from __future__ import annotations
import argparse
import copy
import json
import os
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.metrics import roc_auc_score
from sklearn.model_selection import StratifiedShuffleSplit
from torch.utils.data import DataLoader
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from net_family_3d import count_params, get_model
from train_external_t2_adaptation import ExternalT2Dataset, add_teacher_predictions, collate, distillation_loss, evaluate, freeze_for_linear_probe, load_state, metrics_from_prob, normalize_id

def list_checkpoints(source_dir: Optional[str]) -> List[Optional[str]]:
    if not source_dir:
        return [None]
    paths = sorted(Path(source_dir).glob('fold_*/best_model.pth'))
    if not paths:
        raise FileNotFoundError(f'No fold_*/best_model.pth under {source_dir}')
    return [str(p) for p in paths]

def split_external(index: pd.DataFrame, adapt_fraction: float, adapt_val_fraction: float, seed: int, adapt_negative_n: Optional[int]=None, adapt_positive_n: Optional[int]=None):
    y = index['label'].astype(int).to_numpy()
    exact_counts_requested = adapt_negative_n is not None or adapt_positive_n is not None
    if exact_counts_requested:
        if adapt_negative_n is None or adapt_positive_n is None:
            raise ValueError('Both --adapt-negative-n and --adapt-positive-n are required')
        negative_idx = np.flatnonzero(y == 0)
        positive_idx = np.flatnonzero(y == 1)
        if adapt_negative_n <= 0 or adapt_negative_n > len(negative_idx):
            raise ValueError(f'Invalid negative adaptation count: {adapt_negative_n}')
        if adapt_positive_n <= 0 or adapt_positive_n > len(positive_idx):
            raise ValueError(f'Invalid positive adaptation count: {adapt_positive_n}')
        rng = np.random.default_rng(seed)
        adapt_idx = np.concatenate([rng.choice(negative_idx, size=adapt_negative_n, replace=False), rng.choice(positive_idx, size=adapt_positive_n, replace=False)])
        rng.shuffle(adapt_idx)
        test_idx = np.setdiff1d(np.arange(len(index)), adapt_idx, assume_unique=True)
    else:
        splitter = StratifiedShuffleSplit(n_splits=1, train_size=adapt_fraction, random_state=seed)
        adapt_idx, test_idx = next(splitter.split(index, y))
    adapt = index.iloc[adapt_idx].reset_index(drop=True)
    test = index.iloc[test_idx].reset_index(drop=True)
    adapt_y = adapt['label'].astype(int).to_numpy()
    val_size = max(1, int(round(len(adapt) * adapt_val_fraction)))
    val_fraction = min(0.5, max(1 / len(adapt), val_size / len(adapt)))
    inner = StratifiedShuffleSplit(n_splits=1, test_size=val_fraction, random_state=seed + 17)
    train_rel, val_rel = next(inner.split(adapt, adapt_y))
    adapt_train = adapt.iloc[train_rel].reset_index(drop=True)
    adapt_val = adapt.iloc[val_rel].reset_index(drop=True)
    return (adapt_train, adapt_val, test)

def train_epoch(model: nn.Module, loader: DataLoader, optimizer: torch.optim.Optimizer, criterion: nn.Module, device: torch.device, teacher_weight: float, teacher_temperature: float) -> Dict[str, float]:
    model.train()
    losses: List[float] = []
    correct = 0
    total = 0
    for batch in loader:
        x = batch['volume'].to(device)
        y = batch['label'].to(device)
        logits = model(x)
        loss = criterion(logits, y)
        if teacher_weight > 0 and 'teacher_prob' in batch:
            loss = loss + teacher_weight * distillation_loss(logits, batch['teacher_prob'], teacher_temperature)
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()
        losses.append(float(loss.detach().cpu()))
        correct += int((logits.argmax(dim=1) == y).sum().detach().cpu())
        total += int(y.numel())
    return {'loss': float(np.mean(losses)), 'acc': correct / max(1, total)}

@torch.no_grad()
def predict_prob(model: nn.Module, loader: DataLoader, device: torch.device) -> np.ndarray:
    model.eval()
    probs: List[float] = []
    for batch in loader:
        logits = model(batch['volume'].to(device))
        prob = torch.softmax(logits, dim=1)[:, 1].detach().cpu().numpy()
        probs.extend(prob.tolist())
    return np.asarray(probs, dtype=np.float32)

def label_counts(frame: pd.DataFrame) -> Dict[str, int]:
    return {str(k): int(v) for k, v in frame['label'].astype(int).value_counts().sort_index().items()}

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--roi-dir', required=True)
    parser.add_argument('--index-csv', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--source-model-dir', default=None)
    parser.add_argument('--teacher-pred-csv', default=None)
    parser.add_argument('--teacher-weight', type=float, default=0.0)
    parser.add_argument('--teacher-temperature', type=float, default=2.0)
    parser.add_argument('--model-name', default='convnext3d_tiny')
    parser.add_argument('--modality', default='T2W')
    parser.add_argument('--adaptation-mode', choices=['scratch', 'finetune', 'linear_probe'], default='finetune')
    parser.add_argument('--intensity-mode', choices=['minmax', 'percentile', 'zscore'], default='minmax')
    parser.add_argument('--adapt-fraction', type=float, default=0.3)
    parser.add_argument('--adapt-negative-n', type=int, default=None)
    parser.add_argument('--adapt-positive-n', type=int, default=None)
    parser.add_argument('--adapt-val-fraction', type=float, default=0.2)
    parser.add_argument('--seed', type=int, default=20260619)
    parser.add_argument('--epochs', type=int, default=35)
    parser.add_argument('--patience', type=int, default=8)
    parser.add_argument('--lr', type=float, default=5e-05)
    parser.add_argument('--weight-decay', type=float, default=0.0001)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--num-workers', type=int, default=2)
    parser.add_argument('--class-balanced', action='store_true')
    parser.add_argument('--eval-full-cohort', action='store_true', help='Also evaluate adapted models on all external cases, including adaptation cases. This is apparent performance, not independent validation.')
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()
    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device if args.device == 'cpu' or torch.cuda.is_available() else 'cpu')
    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    index = pd.read_csv(args.index_csv)
    index['id'] = index['id'].map(normalize_id)
    index['label'] = index['label'].astype(int)
    index, teacher_col = add_teacher_predictions(index, args.teacher_pred_csv)
    adapt_train, adapt_val, test = split_external(index, args.adapt_fraction, args.adapt_val_fraction, args.seed, adapt_negative_n=args.adapt_negative_n, adapt_positive_n=args.adapt_positive_n)
    split_summary = {'n_total': int(len(index)), 'n_adapt_train': int(len(adapt_train)), 'n_adapt_val': int(len(adapt_val)), 'n_final_test': int(len(test)), 'requested_adapt_negative_n': args.adapt_negative_n, 'requested_adapt_positive_n': args.adapt_positive_n, 'total_label_counts': label_counts(index), 'adapt_train_label_counts': label_counts(adapt_train), 'adapt_val_label_counts': label_counts(adapt_val), 'final_test_label_counts': label_counts(test), 'adapt_train_ids': adapt_train['id'].astype(str).tolist(), 'adapt_val_ids': adapt_val['id'].astype(str).tolist(), 'final_test_ids': test['id'].astype(str).tolist()}
    with open(os.path.join(args.output_dir, 'locked_split.json'), 'w', encoding='utf-8') as f:
        json.dump(split_summary, f, ensure_ascii=False, indent=2)
    with open(os.path.join(args.output_dir, 'config.json'), 'w', encoding='utf-8') as f:
        json.dump(vars(args), f, ensure_ascii=False, indent=2)
    train_ds = ExternalT2Dataset(args.roi_dir, adapt_train, args.modality, augment=True, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
    val_ds = ExternalT2Dataset(args.roi_dir, adapt_val, args.modality, augment=False, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
    test_ds = ExternalT2Dataset(args.roi_dir, test, args.modality, augment=False, teacher_col=teacher_col, intensity_mode=args.intensity_mode)
    full_ds = ExternalT2Dataset(args.roi_dir, index, args.modality, augment=False, teacher_col=teacher_col, intensity_mode=args.intensity_mode) if args.eval_full_cohort else None
    train_loader = DataLoader(train_ds, batch_size=min(args.batch_size, len(train_ds)), shuffle=True, num_workers=args.num_workers, collate_fn=collate)
    val_loader = DataLoader(val_ds, batch_size=min(args.batch_size, len(val_ds)), shuffle=False, num_workers=args.num_workers, collate_fn=collate)
    test_loader = DataLoader(test_ds, batch_size=min(args.batch_size, len(test_ds)), shuffle=False, num_workers=args.num_workers, collate_fn=collate)
    full_loader = DataLoader(full_ds, batch_size=min(args.batch_size, len(full_ds)), shuffle=False, num_workers=args.num_workers, collate_fn=collate) if full_ds is not None else None
    y_test = test['label'].astype(int).to_numpy()
    pred_frame = pd.DataFrame({'pid': test['id'].astype(str), 'label': y_test})
    y_full = index['label'].astype(int).to_numpy()
    full_pred_frame = pd.DataFrame({'pid': index['id'].astype(str), 'label': y_full}) if args.eval_full_cohort else None
    checkpoints = list_checkpoints(args.source_model_dir)
    fold_records: List[Dict[str, object]] = []
    full_fold_records: List[Dict[str, object]] = []
    start = time.time()
    for ckpt_idx, ckpt in enumerate(checkpoints, start=1):
        print(f"\n{'=' * 60}\nHoldout adaptation model {ckpt_idx}/{len(checkpoints)}\n{'=' * 60}", flush=True)
        model = get_model(args.model_name, in_chans=1, num_classes=2).to(device)
        if args.adaptation_mode in ('finetune', 'linear_probe') and ckpt:
            model.load_state_dict(load_state(ckpt, device), strict=True)
            print(f'Loaded source checkpoint: {ckpt}', flush=True)
        if args.adaptation_mode == 'linear_probe':
            freeze_for_linear_probe(model)
        trainable = sum((p.numel() for p in model.parameters() if p.requires_grad))
        print(f'Params={count_params(model) / 1000000.0:.2f}M, trainable={trainable / 1000000.0:.2f}M', flush=True)
        if args.class_balanced:
            counts = adapt_train['label'].value_counts().sort_index()
            weights = torch.tensor([len(adapt_train) / (2.0 * counts.get(0, 1)), len(adapt_train) / (2.0 * counts.get(1, 1))], dtype=torch.float32, device=device)
            criterion = nn.CrossEntropyLoss(weight=weights)
        else:
            criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.AdamW([p for p in model.parameters() if p.requires_grad], lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
        best_auc = -np.inf
        best_state = copy.deepcopy(model.state_dict())
        best_epoch = 0
        stale = 0
        for epoch in range(1, args.epochs + 1):
            train_metrics = train_epoch(model, train_loader, optimizer, criterion, device, args.teacher_weight, args.teacher_temperature)
            val_metrics = evaluate(model, val_loader, device)
            scheduler.step()
            val_auc = float(val_metrics['auc'] or 0.0)
            if val_auc > best_auc:
                best_auc = val_auc
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
                stale = 0
            else:
                stale += 1
            if epoch <= 3 or epoch % 5 == 0 or epoch == best_epoch:
                print(f"  Epoch {epoch:03d}: loss={train_metrics['loss']:.4f}, train_acc={train_metrics['acc']:.4f}, val_auc={val_auc:.4f}, best_auc={best_auc:.4f}@{best_epoch}", flush=True)
            if stale >= args.patience:
                print(f'  Early stop at epoch {epoch}', flush=True)
                break
        fold_dir = os.path.join(args.output_dir, f'adapted_model_{ckpt_idx}')
        os.makedirs(fold_dir, exist_ok=True)
        torch.save(best_state, os.path.join(fold_dir, 'best_model.pth'))
        model.load_state_dict(best_state)
        prob = predict_prob(model, test_loader, device)
        pred_frame[f'model_{ckpt_idx}_prob'] = prob
        m = metrics_from_prob(y_test, prob)
        m.update({'model_index': ckpt_idx, 'source_checkpoint': ckpt, 'best_epoch': best_epoch, 'adapt_val_auc': best_auc})
        fold_records.append(m)
        print(f"  Final held-out test AUC={m['auc']:.4f}, ACC={m['accuracy']:.4f}", flush=True)
        if args.eval_full_cohort and full_loader is not None and (full_pred_frame is not None):
            full_prob = predict_prob(model, full_loader, device)
            full_pred_frame[f'model_{ckpt_idx}_prob'] = full_prob
            fm = metrics_from_prob(y_full, full_prob)
            fm.update({'model_index': ckpt_idx, 'source_checkpoint': ckpt, 'best_epoch': best_epoch, 'adapt_val_auc': best_auc})
            full_fold_records.append(fm)
            print(f"  Full-cohort apparent AUC={fm['auc']:.4f}, ACC={fm['accuracy']:.4f}", flush=True)
    prob_cols = [c for c in pred_frame.columns if c.endswith('_prob')]
    pred_frame['ensemble_prob'] = pred_frame[prob_cols].mean(axis=1)
    pred_frame['ensemble_pred_0p5'] = (pred_frame['ensemble_prob'] >= 0.5).astype(int)
    ensemble_metrics = metrics_from_prob(y_test, pred_frame['ensemble_prob'].to_numpy())
    pred_path = os.path.join(args.output_dir, 'final_test_predictions.csv')
    pred_frame.to_csv(pred_path, index=False)
    pd.DataFrame(fold_records).to_csv(os.path.join(args.output_dir, 'adapted_model_metrics.csv'), index=False)
    full_ensemble_metrics = None
    full_pred_path = None
    if args.eval_full_cohort and full_pred_frame is not None:
        full_prob_cols = [c for c in full_pred_frame.columns if c.endswith('_prob')]
        full_pred_frame['ensemble_prob'] = full_pred_frame[full_prob_cols].mean(axis=1)
        full_pred_frame['ensemble_pred_0p5'] = (full_pred_frame['ensemble_prob'] >= 0.5).astype(int)
        full_ensemble_metrics = metrics_from_prob(y_full, full_pred_frame['ensemble_prob'].to_numpy())
        full_pred_path = os.path.join(args.output_dir, 'full_cohort_predictions.csv')
        full_pred_frame.to_csv(full_pred_path, index=False)
        pd.DataFrame(full_fold_records).to_csv(os.path.join(args.output_dir, 'full_cohort_model_metrics.csv'), index=False)
    summary = {'output_dir': args.output_dir, 'roi_dir': args.roi_dir, 'index_csv': args.index_csv, 'source_model_dir': args.source_model_dir, 'teacher_pred_csv': args.teacher_pred_csv, 'teacher_weight': args.teacher_weight, 'adaptation_mode': args.adaptation_mode, 'adapt_fraction': args.adapt_fraction, 'adapt_negative_n': args.adapt_negative_n, 'adapt_positive_n': args.adapt_positive_n, 'adapt_val_fraction': args.adapt_val_fraction, 'seed': args.seed, 'intensity_mode': args.intensity_mode, 'class_balanced': bool(args.class_balanced), 'split_summary': {k: v for k, v in split_summary.items() if not k.endswith('_ids')}, 'checkpoints': checkpoints, 'adapted_model_metrics': fold_records, 'ensemble_metrics': ensemble_metrics, 'eval_full_cohort': bool(args.eval_full_cohort), 'full_cohort_metrics': full_ensemble_metrics, 'full_cohort_model_metrics': full_fold_records, 'predictions_csv': pred_path, 'full_cohort_predictions_csv': full_pred_path, 'elapsed_minutes': (time.time() - start) / 60.0}
    with open(os.path.join(args.output_dir, 'holdout_adaptation_summary.json'), 'w', encoding='utf-8') as f:
        json.dump(summary, f, ensure_ascii=False, indent=2)
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
