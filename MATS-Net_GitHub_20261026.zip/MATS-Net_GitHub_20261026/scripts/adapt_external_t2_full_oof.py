from __future__ import annotations
import argparse
import copy
import json
import os
import sys
import time
from pathlib import Path
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from sklearn.model_selection import StratifiedKFold, StratifiedShuffleSplit
from torch.utils.data import DataLoader
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import adapt_external_holdout_t2 as holdout

def label_counts(frame: pd.DataFrame) -> dict[str, int]:
    return {str(k): int(v) for k, v in frame['label'].value_counts().sort_index().items()}

def freeze_for_head_only(model: nn.Module) -> None:
    for name, parameter in model.named_parameters():
        parameter.requires_grad = name.split('.', 1)[0].lower() in {'head', 'classifier', 'fc'}

def make_loader(roi_dir: str, frame: pd.DataFrame, modality: str, teacher_col: str | None, intensity_mode: str, batch_size: int, num_workers: int, augment: bool, shuffle: bool) -> DataLoader:
    dataset = holdout.ExternalT2Dataset(roi_dir, frame, modality, augment=augment, teacher_col=teacher_col, intensity_mode=intensity_mode)
    return DataLoader(dataset, batch_size=min(batch_size, len(dataset)), shuffle=shuffle, num_workers=num_workers, collate_fn=holdout.collate)

def split_manifest(index: pd.DataFrame, folds: int, val_fraction: float, seed: int):
    y = index['label'].to_numpy(int)
    outer = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
    splits = []
    for fold, (development_idx, test_idx) in enumerate(outer.split(index, y), start=1):
        development = index.iloc[development_idx].reset_index(drop=True)
        development_y = development['label'].to_numpy(int)
        inner = StratifiedShuffleSplit(n_splits=1, test_size=val_fraction, random_state=seed + 100 + fold)
        train_rel, val_rel = next(inner.split(development, development_y))
        train = development.iloc[train_rel].reset_index(drop=True)
        val = development.iloc[val_rel].reset_index(drop=True)
        test = index.iloc[test_idx].reset_index(drop=True)
        splits.append({'fold': fold, 'development_indices': development_idx.tolist(), 'test_indices': test_idx.tolist(), 'train_ids': train['id'].astype(str).tolist(), 'val_ids': val['id'].astype(str).tolist(), 'test_ids': test['id'].astype(str).tolist(), 'n_train': len(train), 'n_val': len(val), 'n_test': len(test), 'train_label_counts': label_counts(train), 'val_label_counts': label_counts(val), 'test_label_counts': label_counts(test)})
    return splits

def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--roi-dir', required=True)
    parser.add_argument('--index-csv', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--source-model-dir', required=True)
    parser.add_argument('--teacher-pred-csv', default=None)
    parser.add_argument('--teacher-weight', type=float, default=0.0)
    parser.add_argument('--teacher-temperature', type=float, default=2.0)
    parser.add_argument('--model-name', default='convnext3d_tiny')
    parser.add_argument('--modality', default='T2W')
    parser.add_argument('--adaptation-mode', choices=['finetune', 'linear_probe', 'head_only'], default='finetune')
    parser.add_argument('--intensity-mode', choices=['minmax', 'percentile', 'zscore'], default='minmax')
    parser.add_argument('--folds', type=int, default=5)
    parser.add_argument('--val-fraction', type=float, default=0.1)
    parser.add_argument('--seed', type=int, default=20260824)
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--patience', type=int, default=20)
    parser.add_argument('--lr', type=float, default=8e-05)
    parser.add_argument('--weight-decay', type=float, default=0.0001)
    parser.add_argument('--batch-size', type=int, default=16)
    parser.add_argument('--num-workers', type=int, default=2)
    parser.add_argument('--class-balanced', action='store_true')
    parser.add_argument('--device', default='cuda' if torch.cuda.is_available() else 'cpu')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    if not 0 < args.val_fraction < 0.5:
        raise ValueError('--val-fraction must be between 0 and 0.5')
    os.makedirs(args.output_dir, exist_ok=True)
    index = pd.read_csv(args.index_csv).reset_index(drop=True)
    index['id'] = index['id'].map(holdout.normalize_id)
    index['label'] = index['label'].astype(int)
    index, teacher_col = holdout.add_teacher_predictions(index, args.teacher_pred_csv)
    checkpoints = holdout.list_checkpoints(args.source_model_dir)
    if len(checkpoints) != args.folds:
        raise ValueError(f'Expected {args.folds} source checkpoints, found {len(checkpoints)}')
    splits = split_manifest(index, args.folds, args.val_fraction, args.seed)
    config = vars(args).copy()
    config['evaluation'] = 'stratified target-site out-of-fold'
    config['each_case_tested_once'] = True
    config['source_checkpoint_mapping'] = checkpoints
    Path(args.output_dir, 'config.json').write_text(json.dumps(config, indent=2), encoding='utf-8')
    Path(args.output_dir, 'locked_cv_splits.json').write_text(json.dumps({'n_total': len(index), 'total_label_counts': label_counts(index), 'folds': splits}, indent=2), encoding='utf-8')
    if args.dry_run:
        print(json.dumps({'n_total': len(index), 'label_counts': label_counts(index), 'folds': splits}, indent=2))
        return 0
    device = torch.device(args.device if args.device == 'cpu' or torch.cuda.is_available() else 'cpu')
    y_all = index['label'].to_numpy(int)
    before_oof = np.full(len(index), np.nan, dtype=np.float32)
    after_oof = np.full(len(index), np.nan, dtype=np.float32)
    fold_assignment = np.zeros(len(index), dtype=int)
    fold_records = []
    start = time.time()
    for split, checkpoint in zip(splits, checkpoints):
        fold = split['fold']
        torch.manual_seed(args.seed + fold)
        np.random.seed(args.seed + fold)
        test_idx = np.asarray(split['test_indices'], dtype=int)
        train_ids = set(split['train_ids'])
        val_ids = set(split['val_ids'])
        train = index[index['id'].isin(train_ids)].reset_index(drop=True)
        val = index[index['id'].isin(val_ids)].reset_index(drop=True)
        test = index.iloc[test_idx].reset_index(drop=True)
        if len(train) != split['n_train'] or len(val) != split['n_val']:
            raise ValueError(f'Fold {fold} ID reconstruction failed')
        print(f"\n{'=' * 64}\nTarget-site OOF fold {fold}/{args.folds}\n{'=' * 64}", flush=True)
        print(f'Train={len(train)} {label_counts(train)}, val={len(val)} {label_counts(val)}, test={len(test)} {label_counts(test)}', flush=True)
        train_loader = make_loader(args.roi_dir, train, args.modality, teacher_col, args.intensity_mode, args.batch_size, args.num_workers, augment=True, shuffle=True)
        val_loader = make_loader(args.roi_dir, val, args.modality, teacher_col, args.intensity_mode, args.batch_size, args.num_workers, augment=False, shuffle=False)
        test_loader = make_loader(args.roi_dir, test, args.modality, teacher_col, args.intensity_mode, args.batch_size, args.num_workers, augment=False, shuffle=False)
        model = holdout.get_model(args.model_name, in_chans=1, num_classes=2).to(device)
        model.load_state_dict(holdout.load_state(checkpoint, device), strict=True)
        before_prob = holdout.predict_prob(model, test_loader, device)
        before_metrics = holdout.metrics_from_prob(test['label'].to_numpy(int), before_prob)
        before_oof[test_idx] = before_prob
        print(f"Source model test AUC={before_metrics['auc']:.4f}", flush=True)
        if args.adaptation_mode == 'linear_probe':
            holdout.freeze_for_linear_probe(model)
        elif args.adaptation_mode == 'head_only':
            freeze_for_head_only(model)
        trainable = sum((parameter.numel() for parameter in model.parameters() if parameter.requires_grad))
        if trainable == 0:
            raise ValueError(f'No trainable parameters for adaptation mode {args.adaptation_mode}')
        print(f'Adaptation mode={args.adaptation_mode}, trainable parameters={trainable:,}', flush=True)
        if args.class_balanced:
            counts = train['label'].value_counts().sort_index()
            weights = torch.tensor([len(train) / (2.0 * counts.get(0, 1)), len(train) / (2.0 * counts.get(1, 1))], dtype=torch.float32, device=device)
            criterion = nn.CrossEntropyLoss(weight=weights)
        else:
            criterion = nn.CrossEntropyLoss()
        optimizer = torch.optim.AdamW([parameter for parameter in model.parameters() if parameter.requires_grad], lr=args.lr, weight_decay=args.weight_decay)
        scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=args.epochs)
        best_auc = -np.inf
        best_state = copy.deepcopy(model.state_dict())
        best_epoch = 0
        stale = 0
        for epoch in range(1, args.epochs + 1):
            train_metrics = holdout.train_epoch(model, train_loader, optimizer, criterion, device, args.teacher_weight, args.teacher_temperature)
            val_metrics = holdout.evaluate(model, val_loader, device)
            scheduler.step()
            val_auc = float(val_metrics['auc'] or 0.0)
            if val_auc > best_auc:
                best_auc = val_auc
                best_epoch = epoch
                best_state = copy.deepcopy(model.state_dict())
                stale = 0
            else:
                stale += 1
            if epoch <= 3 or epoch % 5 == 0 or epoch == best_epoch:
                print(f"  Epoch {epoch:03d}: loss={train_metrics['loss']:.4f}, train_acc={train_metrics['acc']:.4f}, val_auc={val_auc:.4f}, best_auc={best_auc:.4f}@{best_epoch}", flush=True)
            if stale >= args.patience:
                print(f'  Early stop at epoch {epoch}', flush=True)
                break
        fold_dir = Path(args.output_dir, f'fold_{fold}')
        fold_dir.mkdir(parents=True, exist_ok=True)
        torch.save(best_state, fold_dir / 'best_model.pth')
        model.load_state_dict(best_state)
        after_prob = holdout.predict_prob(model, test_loader, device)
        after_metrics = holdout.metrics_from_prob(test['label'].to_numpy(int), after_prob)
        after_oof[test_idx] = after_prob
        fold_assignment[test_idx] = fold
        fold_records.append({'fold': fold, 'source_checkpoint': checkpoint, 'n_train': len(train), 'n_val': len(val), 'n_test': len(test), 'adaptation_mode': args.adaptation_mode, 'trainable_parameters': trainable, 'best_epoch': best_epoch, 'best_val_auc': best_auc, **{f'before_{key}': value for key, value in before_metrics.items()}, **{f'after_{key}': value for key, value in after_metrics.items()}})
        print(f"Fold {fold} test AUC: before={before_metrics['auc']:.4f}, after={after_metrics['auc']:.4f}", flush=True)
    if np.isnan(before_oof).any() or np.isnan(after_oof).any() or (fold_assignment == 0).any():
        raise RuntimeError('OOF predictions are incomplete')
    predictions = pd.DataFrame({'pid': index['id'].astype(str), 'label': y_all, 'fold': fold_assignment, 'before_oof_prob': before_oof, 'after_oof_prob': after_oof, 'before_pred_0p5': (before_oof >= 0.5).astype(int), 'after_pred_0p5': (after_oof >= 0.5).astype(int)})
    predictions.to_csv(Path(args.output_dir, 'external_oof_predictions.csv'), index=False)
    pd.DataFrame(fold_records).to_csv(Path(args.output_dir, 'fold_metrics.csv'), index=False)
    before_metrics = holdout.metrics_from_prob(y_all, before_oof)
    after_metrics = holdout.metrics_from_prob(y_all, after_oof)
    summary = {'evaluation': 'stratified target-site out-of-fold', 'n_total': len(index), 'label_counts': label_counts(index), 'folds': args.folds, 'val_fraction_within_outer_development': args.val_fraction, 'each_case_tested_once': True, 'before_oof_metrics': before_metrics, 'after_oof_metrics': after_metrics, 'fold_metrics': fold_records, 'elapsed_minutes': (time.time() - start) / 60.0}
    Path(args.output_dir, 'full_oof_adaptation_summary.json').write_text(json.dumps(summary, indent=2), encoding='utf-8')
    print(json.dumps(summary, indent=2), flush=True)
    return 0
if __name__ == '__main__':
    raise SystemExit(main())
