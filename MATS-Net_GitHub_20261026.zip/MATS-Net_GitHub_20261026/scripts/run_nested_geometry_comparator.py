from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, roc_auc_score
from sklearn.model_selection import StratifiedGroupKFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
MODALITIES = ('T2W', 'DWI', 'T1C', 'T1W')

def normalize_id(value: object) -> str:
    return re.sub('\\.0$', '', str(value)).strip()

def base_patient_id(value: object) -> str:
    return re.sub('_\\d+$', '', normalize_id(value))

def parse_range(value: object) -> tuple[float, float, float, float]:
    numbers = [float(item) for item in re.findall('-?\\d+(?:\\.\\d+)?', str(value))]
    if len(numbers) < 2:
        return (np.nan, np.nan, np.nan, np.nan)
    start, end = (numbers[0], numbers[1])
    return (start, end, end - start + 1.0, (start + end) / 2.0)

def load_geometry(index_path: Path, patient_index_path: Path) -> pd.DataFrame:
    index = pd.read_csv(index_path)
    index['id'] = index['id'].map(normalize_id)
    index['base_id'] = index['id'].map(base_patient_id)
    if 'label' not in index:
        index['label'] = (index['state'].astype(int) == 3).astype(int)
    required_coordinates = [f'{modality}_{axis}' for modality in MODALITIES for axis in ('x', 'y', 'z')] + [f'{modality}_max' for modality in MODALITIES]
    if all((column in index.columns for column in required_coordinates)):
        merged = index.copy()
    else:
        meta = pd.read_csv(patient_index_path)
        meta['id'] = meta['id'].map(normalize_id)
        meta['base_id'] = meta['id'].map(base_patient_id)
        meta = meta.drop_duplicates(['base_id', 'state'])
        keep = ['base_id', 'state'] + [column for column in required_coordinates if column not in index.columns]
        merged = index.merge(meta[keep], on=['base_id', 'state'], how='left')
    features: dict[str, object] = {'id': merged['id'], 'base_id': merged['base_id'], 'state': merged['state'].astype(int), 'label': merged['label'].astype(int)}
    for modality in MODALITIES:
        features[f'geo_{modality}_max'] = pd.to_numeric(merged.get(f'{modality}_max'), errors='coerce')
        for axis in ('x', 'y', 'z'):
            parsed = [parse_range(value) for value in merged.get(f'{modality}_{axis}')]
            for index_, suffix in enumerate(('start', 'end', 'len', 'center')):
                features[f'geo_{modality}_{axis}_{suffix}'] = [value[index_] for value in parsed]
        features[f'geo_{modality}_xy_area'] = np.asarray(features[f'geo_{modality}_x_len']) * np.asarray(features[f'geo_{modality}_y_len'])
        features[f'geo_{modality}_vol_approx'] = np.asarray(features[f'geo_{modality}_xy_area']) * np.asarray(features[f'geo_{modality}_z_len'])
        features[f'geo_{modality}_aspect_xy'] = np.asarray(features[f'geo_{modality}_x_len']) / np.clip(np.asarray(features[f'geo_{modality}_y_len']), 1e-06, None)
    for suffix in ('max', 'x_len', 'y_len', 'z_len', 'xy_area', 'vol_approx'):
        columns = [f'geo_{modality}_{suffix}' for modality in MODALITIES]
        values = np.vstack([np.asarray(features[column], dtype=float) for column in columns]).T
        features[f'geo_cross_{suffix}_mean'] = np.nanmean(values, axis=1)
        features[f'geo_cross_{suffix}_std'] = np.nanstd(values, axis=1)
        features[f'geo_cross_{suffix}_range'] = np.nanmax(values, axis=1) - np.nanmin(values, axis=1)
    return pd.DataFrame(features)

def model(c_value: float, l1_ratio: float, seed: int) -> Pipeline:
    return Pipeline([('impute', SimpleImputer(strategy='median')), ('scale', StandardScaler()), ('classifier', LogisticRegression(penalty='elasticnet', solver='saga', C=c_value, l1_ratio=l1_ratio, class_weight='balanced', max_iter=10000, random_state=seed))])

def metrics(y: np.ndarray, score: np.ndarray) -> dict[str, float | int]:
    pred = (score >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {'n': int(len(y)), 'auc': float(roc_auc_score(y, score)), 'accuracy': float(accuracy_score(y, pred)), 'sensitivity': float(tp / (tp + fn)), 'specificity': float(tn / (tn + fp)), 'f1': float(f1_score(y, pred)), 'brier': float(brier_score_loss(y, score)), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--index', type=Path, required=True)
    parser.add_argument('--patient-index', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seed', type=int, default=20260808)
    parser.add_argument('--outer-splits', type=int, default=5)
    parser.add_argument('--inner-splits', type=int, default=4)
    parser.add_argument('--n-boot', type=int, default=5000)
    parser.add_argument('--outer-assignment', type=Path, help='Optional CSV containing base_id and outer_fold. When supplied, the comparator exactly reuses a previously generated outer-test assignment.')
    parser.add_argument('--feature-set', choices=('engineered82', 'deep48'), default='engineered82', help='Use the full engineered geometry set or the 48 variables supplied to the deep tabular branch.')
    args = parser.parse_args()
    frame = load_geometry(args.index, args.patient_index)
    features = [column for column in frame if column.startswith('geo_')]
    if args.feature_set == 'deep48':
        features = [column for column in features if not column.startswith('geo_cross_') and (not column.endswith('_center')) and (not column.endswith('_aspect_xy'))]
        if len(features) != 48:
            raise ValueError(f'Expected 48 deep-branch geometry variables, found {len(features)}')
    x = frame[features].to_numpy(dtype=float)
    y = frame['label'].to_numpy(dtype=int)
    groups = frame['base_id'].to_numpy()
    if args.outer_assignment:
        assignment = pd.read_csv(args.outer_assignment)
        if not {'base_id', 'outer_fold'}.issubset(assignment.columns):
            raise ValueError('Outer assignment must contain base_id and outer_fold')
        assignment['base_id'] = assignment['base_id'].map(normalize_id)
        if assignment['base_id'].duplicated().any():
            raise ValueError('Outer assignment contains duplicate base_id values')
        fold_by_id = assignment.set_index('base_id')['outer_fold']
        missing_ids = sorted(set(frame['base_id']) - set(fold_by_id.index))
        extra_ids = sorted(set(fold_by_id.index) - set(frame['base_id']))
        if missing_ids or extra_ids:
            raise ValueError(f'Outer assignment patient mismatch: missing={missing_ids[:5]}, extra={extra_ids[:5]}')
        assigned_folds = frame['base_id'].map(fold_by_id).astype(int).to_numpy()
        observed = sorted(np.unique(assigned_folds).tolist())
        expected = list(range(1, args.outer_splits + 1))
        if observed != expected:
            raise ValueError(f'Expected outer folds {expected}, found {observed}')
        outer_splits = [(np.flatnonzero(assigned_folds != fold), np.flatnonzero(assigned_folds == fold)) for fold in expected]
    else:
        outer = StratifiedGroupKFold(n_splits=args.outer_splits, shuffle=True, random_state=args.seed)
        outer_splits = list(outer.split(x, y, groups))
    candidates = [(c, l1) for c in (0.01, 0.03, 0.1, 0.3, 1.0, 3.0) for l1 in (0.0, 0.25, 0.5, 0.75, 1.0)]
    predictions = []
    selections = []
    for outer_fold, (train_index, test_index) in enumerate(outer_splits, start=1):
        inner = StratifiedGroupKFold(n_splits=args.inner_splits, shuffle=True, random_state=args.seed + 1000 + outer_fold)
        rankings = []
        for c_value, l1_ratio in candidates:
            inner_y = []
            inner_score = []
            for inner_train, inner_val in inner.split(x[train_index], y[train_index], groups[train_index]):
                fitted = model(c_value, l1_ratio, args.seed + outer_fold)
                fitted.fit(x[train_index][inner_train], y[train_index][inner_train])
                inner_y.extend(y[train_index][inner_val])
                inner_score.extend(fitted.predict_proba(x[train_index][inner_val])[:, 1])
            rankings.append({'C': c_value, 'l1_ratio': l1_ratio, 'inner_auc': roc_auc_score(inner_y, inner_score), 'inner_brier': brier_score_loss(inner_y, inner_score)})
        ranking = pd.DataFrame(rankings).sort_values(['inner_auc', 'inner_brier', 'C', 'l1_ratio'], ascending=[False, True, True, True])
        best = ranking.iloc[0]
        fitted = model(float(best.C), float(best.l1_ratio), args.seed + outer_fold)
        fitted.fit(x[train_index], y[train_index])
        score = fitted.predict_proba(x[test_index])[:, 1]
        for local, row_index in enumerate(test_index):
            predictions.append({'base_id': frame.iloc[row_index]['base_id'], 'state': int(frame.iloc[row_index]['state']), 'label': int(y[row_index]), 'outer_fold': outer_fold, 'roi_annotation_geometry': float(score[local])})
        selections.append({'outer_fold': outer_fold, 'selected_C': float(best.C), 'selected_l1_ratio': float(best.l1_ratio), 'inner_auc': float(best.inner_auc), 'inner_brier': float(best.inner_brier)})
    prediction_frame = pd.DataFrame(predictions).sort_values('base_id')
    y_all = prediction_frame['label'].to_numpy(dtype=int)
    score_all = prediction_frame['roi_annotation_geometry'].to_numpy(dtype=float)
    result = metrics(y_all, score_all)
    rng = np.random.default_rng(args.seed)
    aucs = []
    while len(aucs) < args.n_boot:
        sample = rng.integers(0, len(y_all), len(y_all))
        if np.unique(y_all[sample]).size == 2:
            aucs.append(roc_auc_score(y_all[sample], score_all[sample]))
    result['auc_ci_low'], result['auc_ci_high'] = map(float, np.quantile(aucs, (0.025, 0.975)))
    result.update({'outer_seed': args.seed, 'outer_splits': args.outer_splits, 'inner_splits': args.inner_splits, 'feature_n': len(features), 'candidate_n': len(candidates), 'feature_set': args.feature_set, 'outer_assignment': str(args.outer_assignment) if args.outer_assignment else None})
    args.output.mkdir(parents=True, exist_ok=True)
    prediction_frame.to_csv(args.output / 'nested_geometry_predictions.csv', index=False)
    pd.DataFrame(selections).to_csv(args.output / 'nested_geometry_selections.csv', index=False)
    (args.output / 'nested_geometry_metrics.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps(result, indent=2))
if __name__ == '__main__':
    main()
