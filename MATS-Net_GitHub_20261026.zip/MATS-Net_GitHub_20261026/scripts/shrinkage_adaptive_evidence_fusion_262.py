from __future__ import annotations
import argparse
import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, brier_score_loss, confusion_matrix, f1_score, log_loss, roc_auc_score
from sklearn.model_selection import StratifiedKFold
EXPERTS = ['single_T2W', 'single_DWI', 'single_T1C', 'single_T1W', 'gmara_auc', 'gmara_clinical_only', 'geo_lr_c0_3', 'gmara_burden_w004']

def reliability_weights(y: np.ndarray, p: np.ndarray) -> np.ndarray:
    auc = np.asarray([max(roc_auc_score(y, p[:, i]) - 0.5, 0.005) for i in range(p.shape[1])])
    return auc / auc.sum()

def simplex_weights(y: np.ndarray, p: np.ndarray) -> np.ndarray:
    from scipy.optimize import minimize
    k = p.shape[1]
    uniform = np.full(k, 1.0 / k)

    def objective(w: np.ndarray) -> float:
        score = np.clip(p @ w, 1e-06, 1.0 - 1e-06)
        return float(log_loss(y, score, labels=[0, 1]))
    result = minimize(objective, uniform, method='SLSQP', bounds=[(0.0, 1.0)] * k, constraints=[{'type': 'eq', 'fun': lambda w: float(w.sum() - 1.0)}], options={'maxiter': 500, 'ftol': 1e-10})
    if not result.success:
        return uniform
    w = np.clip(result.x, 0.0, 1.0)
    return w / w.sum()

def metric_row(method: str, y: np.ndarray, score: np.ndarray) -> dict[str, float | int | str]:
    pred = (score >= 0.5).astype(int)
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0, 1]).ravel()
    return {'method': method, 'n': int(len(y)), 'auc': float(roc_auc_score(y, score)), 'accuracy': float(accuracy_score(y, pred)), 'sensitivity': float(tp / (tp + fn)), 'specificity': float(tn / (tn + fp)), 'f1': float(f1_score(y, pred, zero_division=0)), 'brier': float(brier_score_loss(y, score)), 'tn': int(tn), 'fp': int(fp), 'fn': int(fn), 'tp': int(tp)}

def bootstrap_auc(y: np.ndarray, score: np.ndarray, n_boot: int, seed: int) -> tuple[float, float]:
    rng = np.random.default_rng(seed)
    values = []
    for _ in range(n_boot):
        idx = rng.integers(0, len(y), len(y))
        if np.unique(y[idx]).size == 2:
            values.append(roc_auc_score(y[idx], score[idx]))
    return (float(np.percentile(values, 2.5)), float(np.percentile(values, 97.5)))

def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--outer-splits', type=int, default=5)
    parser.add_argument('--inner-splits', type=int, default=4)
    parser.add_argument('--seed', type=int, default=20260916)
    parser.add_argument('--n-boot', type=int, default=5000)
    parser.add_argument('--select-metric', choices=['logloss', 'auc'], default='logloss')
    args = parser.parse_args()
    frame = pd.read_csv(args.input, dtype={'pid': str})
    required = ['pid', 'label', *EXPERTS]
    missing = [c for c in required if c not in frame.columns]
    if missing or len(frame) != 262 or frame.pid.duplicated().any():
        raise ValueError(f'Expected 262 unique rows and columns; missing={missing}')
    y = frame.label.to_numpy(dtype=int)
    p = frame[EXPERTS].to_numpy(dtype=float)
    uniform = np.full(len(EXPERTS), 1.0 / len(EXPERTS))
    lambdas = [0.0, 0.05, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0]
    outer = StratifiedKFold(args.outer_splits, shuffle=True, random_state=args.seed)
    predictions = frame[['pid', 'label']].copy()
    predictions['outer_fold'] = 0
    predictions['unweighted_mean'] = np.nan
    predictions['shrinkage_reliability_fusion'] = np.nan
    predictions['shrinkage_simplex_fusion'] = np.nan
    weight_rows, audit_rows, grid_rows = ([], [], [])
    for fold, (train_idx, test_idx) in enumerate(outer.split(p, y), start=1):
        train_y, test_y = (y[train_idx], y[test_idx])
        train_p, test_p = (p[train_idx], p[test_idx])
        inner = StratifiedKFold(args.inner_splits, shuffle=True, random_state=args.seed + fold * 101)
        candidates = []
        for source_name, source_fn in [('reliability', reliability_weights), ('simplex', simplex_weights)]:
            for shrink in lambdas:
                losses, aucs = ([], [])
                for inner_train, inner_val in inner.split(train_p, train_y):
                    source = source_fn(train_y[inner_train], train_p[inner_train])
                    weights = (1.0 - shrink) * uniform + shrink * source
                    score = np.clip(train_p[inner_val] @ weights, 1e-06, 1.0 - 1e-06)
                    losses.append(log_loss(train_y[inner_val], score, labels=[0, 1]))
                    aucs.append(roc_auc_score(train_y[inner_val], score))
                row = {'outer_fold': fold, 'source': source_name, 'shrinkage': shrink, 'mean_log_loss': float(np.mean(losses)), 'mean_auc': float(np.mean(aucs))}
                grid_rows.append(row)
                candidates.append(row)
        selected = {}
        for source_name in ['reliability', 'simplex']:
            subset = [row for row in candidates if row['source'] == source_name]
            if args.select_metric == 'auc':
                selected[source_name] = sorted(subset, key=lambda row: (-row['mean_auc'], row['mean_log_loss'], row['shrinkage']))[0]
            else:
                selected[source_name] = sorted(subset, key=lambda row: (row['mean_log_loss'], -row['mean_auc'], row['shrinkage']))[0]
        rel_source = reliability_weights(train_y, train_p)
        simp_source = simplex_weights(train_y, train_p)
        rel_lambda = float(selected['reliability']['shrinkage'])
        simp_lambda = float(selected['simplex']['shrinkage'])
        rel_weights = (1.0 - rel_lambda) * uniform + rel_lambda * rel_source
        simp_weights = (1.0 - simp_lambda) * uniform + simp_lambda * simp_source
        predictions.loc[test_idx, 'outer_fold'] = fold
        predictions.loc[test_idx, 'unweighted_mean'] = test_p.mean(axis=1)
        predictions.loc[test_idx, 'shrinkage_reliability_fusion'] = test_p @ rel_weights
        predictions.loc[test_idx, 'shrinkage_simplex_fusion'] = test_p @ simp_weights
        for method, weights in [('reliability', rel_weights), ('simplex', simp_weights)]:
            for expert, weight in zip(EXPERTS, weights):
                weight_rows.append({'outer_fold': fold, 'method': method, 'expert': expert, 'weight': float(weight)})
        audit_rows.append({'outer_fold': fold, 'selected_reliability_shrinkage': rel_lambda, 'selected_simplex_shrinkage': simp_lambda, 'reliability_weight_l1_from_uniform': float(np.abs(rel_weights - uniform).sum()), 'simplex_weight_l1_from_uniform': float(np.abs(simp_weights - uniform).sum())})
    metrics = []
    for method in ['unweighted_mean', 'shrinkage_reliability_fusion', 'shrinkage_simplex_fusion']:
        score = predictions[method].to_numpy(dtype=float)
        row = metric_row(method, y, score)
        row['auc_ci_low'], row['auc_ci_high'] = bootstrap_auc(y, score, args.n_boot, args.seed + 9000)
        row['evaluation'] = 'nested score-level outer CV'
        metrics.append(row)
    args.output.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(metrics).to_csv(args.output / 'shrinkage_fusion_metrics_262.csv', index=False)
    predictions.to_csv(args.output / 'shrinkage_fusion_predictions_262.csv', index=False)
    pd.DataFrame(weight_rows).to_csv(args.output / 'shrinkage_fusion_weights_262.csv', index=False)
    pd.DataFrame(audit_rows).to_csv(args.output / 'shrinkage_fusion_outer_audit.csv', index=False)
    pd.DataFrame(grid_rows).to_csv(args.output / 'shrinkage_fusion_inner_grid.csv', index=False)
    (args.output / 'protocol.json').write_text(json.dumps({'n_records': 262, 'experts': EXPERTS, 'outer_splits': args.outer_splits, 'inner_splits': args.inner_splits, 'shrinkage_grid': lambdas, 'method': 'uniformity-regularized reliability/simplex expert pooling', 'selection_metric': args.select_metric, 'outer_test_excluded_from_weight_learning': True}, indent=2), encoding='utf-8')
if __name__ == '__main__':
    main()
