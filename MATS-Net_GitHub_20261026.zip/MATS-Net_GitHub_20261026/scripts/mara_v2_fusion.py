import torch
import torch.nn as nn
import torch.nn.functional as F

class ModalityAttention(nn.Module):

    def __init__(self, dim, num_modalities=4, num_heads=4, gamma_init=0.1):
        super().__init__()
        assert dim % num_heads == 0, f'dim {dim} must be divisible by num_heads {num_heads}'
        self.num_heads = num_heads
        self.head_dim = dim // num_heads
        self.num_modalities = num_modalities
        self.scale = self.head_dim ** (-0.5)
        self.mod_queries = nn.Parameter(torch.randn(num_heads, num_modalities, self.head_dim) * 0.02)
        self.v_proj = nn.Linear(dim, dim)
        self.out_proj = nn.Linear(dim, dim)
        self.gamma = nn.Parameter(torch.full((1,), gamma_init))
        self.norm = nn.LayerNorm(dim)

    def forward(self, x):
        B, C, D, H, W = x.shape
        N = D * H * W
        x_flat = x.permute(0, 2, 3, 4, 1).reshape(B, N, C)
        x_norm = self.norm(x_flat)
        q = x_norm.view(B, N, self.num_heads, self.head_dim)
        k = self.mod_queries.unsqueeze(0)
        attn = torch.einsum('bnhd,bhmd->bhnm', q, k) * self.scale
        attn = torch.softmax(attn, dim=-1)
        v = k
        attended = torch.einsum('bhnm,bhmd->bnhd', attn, v)
        attended = attended.reshape(B, N, C)
        attended = self.out_proj(attended)
        enhanced = x_flat + self.gamma * attended
        enhanced = enhanced.reshape(B, D, H, W, C).permute(0, 4, 1, 2, 3)
        return (enhanced, attn.mean(dim=1))

class MARAv2Fusion(nn.Module):

    def __init__(self, backbone, num_classes=3, backbone_kwargs=None, num_modalities=4, num_heads=4, gamma_init=0.1):
        super().__init__()
        backbone_kwargs = backbone_kwargs or {}
        self.encoder = backbone(in_chans=4, num_classes=num_classes, **backbone_kwargs)
        with torch.no_grad():
            dummy = torch.randn(1, 4, 16, 64, 64)
            features = self.encoder.forward_features(dummy)
            self.final_dim = features.shape[-1]
            stem = self.encoder.stem_conv(dummy)
            s1 = self.encoder.downsample_layers[0](stem)
            s1 = self.encoder.stages[0](s1)
            s2 = self.encoder.downsample_layers[1](s1)
            s2 = self.encoder.stages[1](s2)
            self.dim_s2 = s2.shape[1]
            s3 = self.encoder.downsample_layers[2](s2)
            s3 = self.encoder.stages[2](s3)
            self.dim_s3 = s3.shape[1]
            s4 = self.encoder.downsample_layers[3](s3)
            s4 = self.encoder.stages[3](s4)
            self.dim_s4 = s4.shape[1]
        self.attn_s2 = ModalityAttention(self.dim_s2, num_modalities, num_heads, gamma_init)
        self.attn_s3 = ModalityAttention(self.dim_s3, num_modalities, num_heads, gamma_init)
        self.attn_s4 = ModalityAttention(self.dim_s4, num_modalities, num_heads, gamma_init)
        self.classifier = nn.Sequential(nn.LayerNorm(self.final_dim), nn.Linear(self.final_dim, self.final_dim // 2), nn.GELU(), nn.Dropout(0.3), nn.Linear(self.final_dim // 2, num_classes))

    def forward(self, x):
        fused = torch.cat(x, dim=1)
        out = self.encoder.stem_conv(fused)
        out = self.encoder.downsample_layers[0](out)
        out = self.encoder.stages[0](out)
        out = self.encoder.downsample_layers[1](out)
        out = self.encoder.stages[1](out)
        out, _ = self.attn_s2(out)
        out = self.encoder.downsample_layers[2](out)
        out = self.encoder.stages[2](out)
        out, _ = self.attn_s3(out)
        out = self.encoder.downsample_layers[3](out)
        out = self.encoder.stages[3](out)
        out, _ = self.attn_s4(out)
        out = out.mean(dim=(-3, -2, -1))
        out = self.encoder.norm(out)
        return self.classifier(out)
